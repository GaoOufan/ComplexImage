﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace ComplexImage
{
    public partial class RT_NewTemplate : Form
    {
        bool ToEdit = false;

        public RT_NewTemplate()
        {
            InitializeComponent();
        }

        public RT_NewTemplate(bool a)
        {
            InitializeComponent();
            ToEdit = true;
            TName.ReadOnly = true;
            TName.ForeColor = Color.SaddleBrown;
            TName.BackColor = Color.Tan;
        }

        private void ImgTag_Click(object sender, EventArgs e)
        {
            if (IconLoader.ShowDialog() == DialogResult.OK)
            {
                MemoryStream ms = new MemoryStream(File.ReadAllBytes(IconLoader.FileName));
                ImgTag.BackgroundImage = Image.FromStream(ms);
                Bitmap NB = new Bitmap(120, 120);
                Graphics GR = Graphics.FromImage(NB);
                GR.DrawImage(ImgTag.BackgroundImage, 0, 0, 120, 120);
                ImgTag.BackgroundImage = NB;
            }
        }

        private void LoadCode_Click(object sender, EventArgs e)
        {
            if (CodeFromFile.ShowDialog() == DialogResult.OK)
                TCode.Text = File.ReadAllText(CodeFromFile.FileName);
        }

        private void Reg_Click(object sender, EventArgs e)
        {
            string k = TName.Text.Replace(" ", "_");
            if (TName.Text.Replace(" ", "") == "") { MessageBox.Show("Name is missing!"); return; }
            if (TGroup.Text.Replace(" ", "") == "") { MessageBox.Show("Group is missing!"); return; }
            if (ImgTag.BackgroundImage == null) { MessageBox.Show("Icon is missing!"); return; }
            if (TCode.Text == "") { MessageBox.Show("Code is missing!"); return; }
            string dst = Path.GetDirectoryName(Application.ExecutablePath) + "\\Templates\\" + k + ".cit";
            if (ToEdit == true) 
                File.Delete(Path.GetDirectoryName(Application.ExecutablePath) + "\\Templates\\" + k + ".cit");
            else if (File.Exists(dst) == true)
                if (MessageBox.Show("Template with the same name already exists. Procceed?\nIf yes, existing template will be overwritten!", "Alert", MessageBoxButtons.YesNo) == DialogResult.No)
                    return;
            DialogResult = DialogResult.Yes;
        }

        private void Quit_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.No;
        }
    }
}
