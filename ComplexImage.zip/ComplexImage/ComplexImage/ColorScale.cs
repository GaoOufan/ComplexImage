﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace ComplexImage
{
    public partial class ColorScale : Form
    {
        public RichTextBox rtf = null;

        public ColorScale()
        {
            InitializeComponent();
        }

        private void OK_Click(object sender, EventArgs e)
        {
            if (DstLay.Text == "") { MessageBox.Show("Destination layer is missing!"); return; }
            string res = "ColScl " + DstLay.Text + " ";
            if (RegLay.ForeColor == Color.Black) 
                res = "F " + RegLay.Text + " " + RegLayN.Text + "\n" + res;
            if (RegLayN.Text != "") res += RegLayN.Text;
            else res += "-";
            if (R0.Checked == true) res += " 0";
            else if (RF.Checked == true) res += " F";
            else if (RH.Checked == true) res += " H";
            else res += " R";
            string[] CV = new string[11]{ "X","V","R","G","B","A","W","WA","RG","RB","GB" };
            if (AType.SelectedIndex == -1 || AType.SelectedIndex == 0) res += (" " + ((AVal.Text == "") ? "0" : AVal.Text));
            else res += (" " + CV[AType.SelectedIndex - 1]);
            if (RType.SelectedIndex == -1 || RType.SelectedIndex == 0) res += (" " + ((RVal.Text == "") ? "0" : RVal.Text));
            else res += (" " + CV[RType.SelectedIndex - 1]);
            if (GType.SelectedIndex == -1 || GType.SelectedIndex == 0) res += (" " + ((GVal.Text == "") ? "0" : GVal.Text));
            else res += (" "+CV[GType.SelectedIndex - 1]);
            if (BType.SelectedIndex == -1 || BType.SelectedIndex == 0) res += (" " + ((BVal.Text == "") ? "0" : BVal.Text));
            else res += (" "+CV[BType.SelectedIndex - 1]);
            if (IncBright.Checked == true) res += (" " + Bright.Text);
            rtf.SelectedText = res+"\n"; this.Close();
        }

        private void RegLay_DragDrop(object sender, DragEventArgs e)
        {
            object filename = e.Data.GetData("FileDrop");
            if (filename != null)
            {
                var list = filename as string[];
                if (list != null && !string.IsNullOrWhiteSpace(list[0]))
                {
                    RegLay.Text = list[0];
                    RegLay.ForeColor = Color.Black;
                    RegLayN.Text = Path.GetFileNameWithoutExtension(list[0]);
                }
            }
        }

        private void ColorPreviewing()
        {
            Bitmap PRV = new Bitmap(256, 28);
            // future!
        }

        private void RVal_TextChanged(object sender, EventArgs e)
        {
            ColorPreviewing();
        }

        private void GVal_TextChanged(object sender, EventArgs e)
        {
            ColorPreviewing();
        }

        private void BVal_TextChanged(object sender, EventArgs e)
        {
            ColorPreviewing();
        }

        private void AVal_TextChanged(object sender, EventArgs e)
        {
            ColorPreviewing();
        }

        private void RType_SelectedIndexChanged(object sender, EventArgs e)
        {
            ColorPreviewing();
        }

        private void GType_SelectedIndexChanged(object sender, EventArgs e)
        {
            ColorPreviewing();
        }

        private void BType_SelectedIndexChanged(object sender, EventArgs e)
        {
            ColorPreviewing();
        }

        private void AType_SelectedIndexChanged(object sender, EventArgs e)
        {
            ColorPreviewing();
        }

        private void NO_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void LayDel_Click(object sender, EventArgs e)
        {
            RegLay.Text = "<Drop image file here>";
            RegLay.ForeColor = Color.OrangeRed;
        }

        private void RegLay_DragOver(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
                e.Effect = DragDropEffects.Copy;
            else
                e.Effect = DragDropEffects.None;
        }
    }
}
