﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ComplexImage
{
    public partial class ErrorReporter : Form
    {
        public bool Abort = false;

        public ErrorReporter()
        {
            InitializeComponent();
            Abort = false;
        }

        private void ErrorReporter_Load(object sender, EventArgs e)
        {
            //
        }

        private void CTRLBRK_Click(object sender, EventArgs e)
        {
            Abort = true;
        }
    }
}
