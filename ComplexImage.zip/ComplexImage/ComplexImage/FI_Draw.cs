﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace ComplexImage
{
    public partial class FI_Draw : Form
    {
        Point Lst;
        Graphics GR1,GR2;
        Bitmap RSV,TMP;
        int Stat = 1;

        public FI_Draw()
        {
            InitializeComponent();
        }

        private void PIC_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
                if (PenStat.Visible == true) PenStat.Visible = false;
                else PenStat.Visible = true;
            else if (e.Button == MouseButtons.Left)
            {
                int x = e.X, y = e.Y;
                if (I_Snap.Checked == true)
                {
                    int g;
                    try { g = Int32.Parse(I_Grid.Text); }
                    catch { g = 2; I_Grid.Text = "2"; }
                    x = (x / g) * g; y = (y / g) * g;
                }
                if (PenStat.Visible == true)
                {
                    if (Lst.X < 0) I_Cmd.Items.Add("S > " + x.ToString() + " " + y.ToString());
                    else if (Stat == 1)
                    {
                        I_Cmd.Items.Add("D > " + x.ToString() + " " + y.ToString());
                        GR1.DrawLine(new Pen(Color.Black), Lst, new Point(x, y));
                    }
                    else if (Stat == 2 && x > Lst.X && y > Lst.Y)
                    {
                        I_Cmd.Items.Add("S > " +Lst.X.ToString() + " " + Lst.Y.ToString());
                        I_Cmd.Items.Add("Rect " + (x-Lst.X).ToString() + " " + (y-Lst.Y).ToString());
                        GR1.DrawRectangle(new Pen(Color.Black), Lst.X, Lst.Y, x - Lst.X, y - Lst.Y);
                    }
                    else if (Stat == 3 && x > Lst.X && y > Lst.Y)
                    {
                        I_Cmd.Items.Add("S > " + Lst.X.ToString() + " " + Lst.Y.ToString());
                        I_Cmd.Items.Add("Arc " + (x - Lst.X).ToString() + " " + (y - Lst.Y).ToString()+" 0 PI*2");
                        GR1.DrawArc(new Pen(Color.Black), Lst.X, Lst.Y, x - Lst.X, y - Lst.Y, 0, 360);
                    }
                    GR2.DrawImage(RSV, 0, 0);
                    GR2.DrawArc(new Pen(Color.Red), x - 2, y - 2, 4, 4, 0, 360);
                }
                else
                {
                    GR2.DrawImage(RSV, 0, 0);
                    GR2.DrawArc(new Pen(Color.Red), x - 2, y - 2, 4, 4, 0, 360);
                    I_Cmd.Items.Add("S > " + x.ToString() + " " + y.ToString());
                }
                Lst = new Point(x, y); PIC.Image = RSV;
            }
        }

        private void PIC_MouseMove(object sender, MouseEventArgs e)
        {
            int x = e.X, y = e.Y;
            if (I_Snap.Checked == true)
            {
                int g;
                try { g = Int32.Parse(I_Grid.Text); }
                catch { g = 2; I_Grid.Text = "2"; }
                x = (x / g) * g; y = (y / g) * g;
            }
            I_Pos.Text = x.ToString() + " " + y.ToString();
            GR2.DrawImage(TMP, 0, 0);
            if (PenStat.Visible == true && Lst.X >= 0)
                if (Stat == 1) GR2.DrawLine(new Pen(Color.Gray), Lst, new Point(x, y));
                else if (Stat == 2 && x > Lst.X && y > Lst.Y) GR2.DrawRectangle(new Pen(Color.Gray), Lst.X, Lst.Y, x - Lst.X, y - Lst.Y);
                else if (Stat == 3 && x > Lst.X && y > Lst.Y) GR2.DrawArc(new Pen(Color.Gray), Lst.X, Lst.Y, x - Lst.X, y - Lst.Y, 0, 360);
            GR2.DrawArc(new Pen(Color.LightGreen), x - 2, y - 2, 4, 4, 0, 360);
            PIC.Image = RSV;
        }

        private void OK_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Yes;
        }

        private void Cancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.No;
        }

        private void I_Cmd_KeyDown(object sender, KeyEventArgs e)
        {
            if (I_Cmd.SelectedItem == null) return;
            if (e.KeyCode == Keys.Delete)
            {
                I_Cmd.Items.Remove(I_Cmd.SelectedItem);
                GR1.FillRectangle(new SolidBrush(Color.White), 0, 0, PIC.Width, PIC.Height);
                Lst = new Point(-1, -1);
                foreach (string S in I_Cmd.Items)
                {
                    string[] C = S.Split(' ');
                    if (C[0] == "D" && Lst.X >= 0)
                        GR1.DrawLine(new Pen(Color.Black), Lst, new Point(Int32.Parse(C[2]), Int32.Parse(C[3])));
                    else if (C[0] == "Rect" && Lst.X >= 0)
                        GR1.DrawRectangle(new Pen(Color.Black), Lst.X, Lst.Y, Int32.Parse(C[1]), Int32.Parse(C[2]));
                    else if (C[0] == "Arc" && Lst.X >= 0)
                        GR1.DrawArc(new Pen(Color.Black), Lst.X, Lst.Y, Int32.Parse(C[1]), Int32.Parse(C[2]), 0, 360);
                    if (C[0] == "D" || C[0] == "S") Lst = new Point(Int32.Parse(C[2]), Int32.Parse(C[3]));
                }
                GR2.DrawImage(TMP, 0, 0);
                GR2.DrawArc(new Pen(Color.Red), Lst.X - 2, Lst.Y - 2, 4, 4, 0, 360);
                PIC.Image = RSV;
            }
        }

        private void FI_Draw_Shown(object sender, EventArgs e)
        {
            PIC.Cursor = new System.Windows.Forms.Cursor(new MemoryStream(global::ComplexImage.Properties.Resources.Cursor1));
            Stat = 1;
            RSV = new Bitmap(PIC.Image); // RSV is the dynamic layer
            GR2 = Graphics.FromImage(RSV);
            GR2.FillRectangle(new SolidBrush(Color.White), 0, 0, PIC.Width, PIC.Height);
            TMP = new Bitmap(RSV); GR1 = Graphics.FromImage(TMP); // the final layer
            Lst = new Point(-1, -1);
        }

        private void TT_LineMode_Click(object sender, EventArgs e)
        {
            PIC.Cursor = new System.Windows.Forms.Cursor(new MemoryStream(global::ComplexImage.Properties.Resources.Cursor1));
            Stat = 1;
        }

        private void TT_RectMode_Click(object sender, EventArgs e)
        {
            PIC.Cursor = new System.Windows.Forms.Cursor(new MemoryStream(global::ComplexImage.Properties.Resources.Cursor2));
            Stat = 2;
        }

        private void TT_ArcMode_Click(object sender, EventArgs e)
        {
            PIC.Cursor = new System.Windows.Forms.Cursor(new MemoryStream(global::ComplexImage.Properties.Resources.Cursor3));
            Stat = 3;
        }
    }
}
