﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ComplexImage
{
    public partial class FrameViewer : Form
    {
        public Color Transparent = Color.FromArgb(255, 255, 255);
        public int Fidx = 0;
        public bool NoColor = false;
        public bool ALL = false;

        public FrameViewer()
        {
            InitializeComponent();
        }

        private void OK_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
        }

        private void FrameViewer_Load(object sender, EventArgs e)
        {
            this.Text = "Frame index: " + Fidx.ToString() + ", transparent color: " + Transparent.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            NoColor = true; DialogResult = DialogResult.OK;
        }

        private void All_Click(object sender, EventArgs e)
        {
            ALL = true;
            DialogResult = DialogResult.OK;
        }

        private void FF_MouseClick(object sender, MouseEventArgs e)
        {
            Bitmap BMP = (Bitmap)FF.BackgroundImage;
            try { Transparent = BMP.GetPixel(e.X, e.Y); }
            catch { this.Text = "Error - - - ";  return; }
            this.Text = "Frame index: " + Fidx.ToString() + ", transparent color: " + Transparent.ToString();
        }
    }
}
