﻿namespace ComplexImage
{
    partial class FI_LayerInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FI_LayerInfo));
            this.label1 = new System.Windows.Forms.Label();
            this.I_Nam = new System.Windows.Forms.TextBox();
            this.I_File = new System.Windows.Forms.CheckBox();
            this.I_Path = new System.Windows.Forms.TextBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.I_W = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.I_H = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.OK = new System.Windows.Forms.Button();
            this.Cancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name:";
            // 
            // I_Nam
            // 
            this.I_Nam.Location = new System.Drawing.Point(53, 7);
            this.I_Nam.MaxLength = 32;
            this.I_Nam.Name = "I_Nam";
            this.I_Nam.Size = new System.Drawing.Size(142, 21);
            this.I_Nam.TabIndex = 1;
            // 
            // I_File
            // 
            this.I_File.AutoSize = true;
            this.I_File.Location = new System.Drawing.Point(12, 36);
            this.I_File.Name = "I_File";
            this.I_File.Size = new System.Drawing.Size(84, 16);
            this.I_File.TabIndex = 2;
            this.I_File.Text = "From file:";
            this.I_File.UseVisualStyleBackColor = true;
            this.I_File.CheckedChanged += new System.EventHandler(this.I_File_CheckedChanged);
            // 
            // I_Path
            // 
            this.I_Path.BackColor = System.Drawing.Color.Tan;
            this.I_Path.ForeColor = System.Drawing.Color.SaddleBrown;
            this.I_Path.Location = new System.Drawing.Point(102, 34);
            this.I_Path.Name = "I_Path";
            this.I_Path.ReadOnly = true;
            this.I_Path.Size = new System.Drawing.Size(334, 21);
            this.I_Path.TabIndex = 3;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.Filter = "JPEG|*.jpg|Bitmap|*.bmp|Portable network graphics|*.png|Animated|*.gif";
            // 
            // I_W
            // 
            this.I_W.Location = new System.Drawing.Point(250, 7);
            this.I_W.MaxLength = 5;
            this.I_W.Name = "I_W";
            this.I_W.Size = new System.Drawing.Size(61, 21);
            this.I_W.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(203, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 4;
            this.label2.Text = "Width:";
            // 
            // I_H
            // 
            this.I_H.Location = new System.Drawing.Point(375, 7);
            this.I_H.MaxLength = 5;
            this.I_H.Name = "I_H";
            this.I_H.Size = new System.Drawing.Size(61, 21);
            this.I_H.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(322, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 12);
            this.label3.TabIndex = 6;
            this.label3.Text = "Height:";
            // 
            // OK
            // 
            this.OK.Location = new System.Drawing.Point(12, 63);
            this.OK.Name = "OK";
            this.OK.Size = new System.Drawing.Size(98, 35);
            this.OK.TabIndex = 8;
            this.OK.Text = "OK";
            this.OK.UseVisualStyleBackColor = true;
            this.OK.Click += new System.EventHandler(this.OK_Click);
            // 
            // Cancel
            // 
            this.Cancel.Location = new System.Drawing.Point(338, 63);
            this.Cancel.Name = "Cancel";
            this.Cancel.Size = new System.Drawing.Size(98, 35);
            this.Cancel.TabIndex = 9;
            this.Cancel.Text = "Cancel";
            this.Cancel.UseVisualStyleBackColor = true;
            this.Cancel.Click += new System.EventHandler(this.Cancel_Click);
            // 
            // FI_LayerInfo
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(444, 108);
            this.ControlBox = false;
            this.Controls.Add(this.Cancel);
            this.Controls.Add(this.OK);
            this.Controls.Add(this.I_H);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.I_W);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.I_Path);
            this.Controls.Add(this.I_File);
            this.Controls.Add(this.I_Nam);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FI_LayerInfo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Layer properties";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.TextBox I_Nam;
        public System.Windows.Forms.TextBox I_Path;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        public System.Windows.Forms.TextBox I_W;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.TextBox I_H;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button OK;
        private System.Windows.Forms.Button Cancel;
        private System.Windows.Forms.CheckBox I_File;
    }
}