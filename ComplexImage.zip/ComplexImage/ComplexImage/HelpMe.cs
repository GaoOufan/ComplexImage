﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ComplexImage
{
    public partial class HelpMe : Form
    {
        public HelpMe()
        {
            InitializeComponent();
        }

        private void HT_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (e.Node.Name == "S1E1") HF.Rtf = global::ComplexImage.Properties.Resources.F_S1E1;
            else if (e.Node.Name == "S1E2") HF.Rtf = global::ComplexImage.Properties.Resources.F_S1E2;
            else if (e.Node.Name == "S1E3") HF.Rtf = global::ComplexImage.Properties.Resources.F_S1E3;
            else if (e.Node.Name == "S1E4") HF.Rtf = global::ComplexImage.Properties.Resources.F_S1E4;
            else if (e.Node.Name == "S2E1") HF.Rtf = global::ComplexImage.Properties.Resources.F_S2E1;
            else if (e.Node.Name == "S2E2") HF.Rtf = global::ComplexImage.Properties.Resources.F_S2E2;
            else if (e.Node.Name == "S2E3") HF.Rtf = global::ComplexImage.Properties.Resources.F_S2E3;
            else if (e.Node.Name == "S2E4") HF.Rtf = global::ComplexImage.Properties.Resources.F_S2E4;
            else if (e.Node.Name == "S2E5") HF.Rtf = global::ComplexImage.Properties.Resources.F_S2E5;
        }
    }
}
