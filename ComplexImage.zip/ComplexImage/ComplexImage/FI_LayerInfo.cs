﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace ComplexImage
{
    public partial class FI_LayerInfo : Form
    {
        public FI_LayerInfo()
        {
            InitializeComponent();
        }

        private void I_File_CheckedChanged(object sender, EventArgs e)
        {
            if (I_File.Checked == true && openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                I_Path.Text = openFileDialog1.FileName;
                I_Nam.Text = Path.GetFileNameWithoutExtension(openFileDialog1.FileName);
            }
            else I_Path.Text = "";
        }

        private void OK_Click(object sender, EventArgs e)
        {
            if (I_Nam.Text == "") { MessageBox.Show("Name is missing!"); return; }
            if (I_File.Checked == false) {
                if (I_W.Text == "" || I_H.Text == "")
                {
                    MessageBox.Show("New layer MUST have defined width and height!"); return;
                }
                HLP.MT(I_W.Text); HLP.MT(I_H.Text);
            }
            DialogResult = DialogResult.Yes;
        }

        private void Cancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.No;
        }
    }
}
