﻿namespace ComplexImage
{
    partial class LayerViewer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LayerViewer));
            this.LayLst = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewImageColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Save = new System.Windows.Forms.Button();
            this.InvSel = new System.Windows.Forms.Button();
            this.GIF = new System.Windows.Forms.Button();
            this.Blend = new System.Windows.Forms.Button();
            this.ShiftDown = new System.Windows.Forms.Button();
            this.ShiftUp = new System.Windows.Forms.Button();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.Pick = new System.Windows.Forms.Button();
            this.VW = new System.Windows.Forms.Button();
            this.ICO = new System.Windows.Forms.Button();
            this.SICO = new System.Windows.Forms.SaveFileDialog();
            ((System.ComponentModel.ISupportInitialize)(this.LayLst)).BeginInit();
            this.SuspendLayout();
            // 
            // LayLst
            // 
            this.LayLst.AllowUserToAddRows = false;
            this.LayLst.AllowUserToDeleteRows = false;
            this.LayLst.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.LayLst.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.LayLst.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3});
            this.LayLst.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.LayLst.Location = new System.Drawing.Point(12, 11);
            this.LayLst.Name = "LayLst";
            this.LayLst.ReadOnly = true;
            this.LayLst.RowTemplate.Height = 23;
            this.LayLst.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.LayLst.Size = new System.Drawing.Size(463, 371);
            this.LayLst.TabIndex = 1;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Name";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Layer preview";
            this.Column2.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Zoom;
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 200;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Size";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // Save
            // 
            this.Save.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Save.Location = new System.Drawing.Point(481, 52);
            this.Save.Name = "Save";
            this.Save.Size = new System.Drawing.Size(121, 35);
            this.Save.TabIndex = 2;
            this.Save.Text = "Save selected";
            this.Save.UseVisualStyleBackColor = true;
            this.Save.Click += new System.EventHandler(this.Save_Click);
            // 
            // InvSel
            // 
            this.InvSel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.InvSel.Location = new System.Drawing.Point(481, 11);
            this.InvSel.Name = "InvSel";
            this.InvSel.Size = new System.Drawing.Size(121, 35);
            this.InvSel.TabIndex = 4;
            this.InvSel.Text = "Invert selection";
            this.InvSel.UseVisualStyleBackColor = true;
            this.InvSel.Click += new System.EventHandler(this.InvSel_Click);
            // 
            // GIF
            // 
            this.GIF.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.GIF.Location = new System.Drawing.Point(481, 92);
            this.GIF.Name = "GIF";
            this.GIF.Size = new System.Drawing.Size(121, 35);
            this.GIF.TabIndex = 5;
            this.GIF.Text = "Create GIF";
            this.GIF.UseVisualStyleBackColor = true;
            this.GIF.Click += new System.EventHandler(this.GIF_Click);
            // 
            // Blend
            // 
            this.Blend.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Blend.Location = new System.Drawing.Point(481, 133);
            this.Blend.Name = "Blend";
            this.Blend.Size = new System.Drawing.Size(121, 35);
            this.Blend.TabIndex = 6;
            this.Blend.Text = "Blend selected to single image";
            this.Blend.UseVisualStyleBackColor = true;
            this.Blend.Click += new System.EventHandler(this.Blend_Click);
            // 
            // ShiftDown
            // 
            this.ShiftDown.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ShiftDown.Location = new System.Drawing.Point(481, 347);
            this.ShiftDown.Name = "ShiftDown";
            this.ShiftDown.Size = new System.Drawing.Size(121, 35);
            this.ShiftDown.TabIndex = 7;
            this.ShiftDown.Text = "Shift down";
            this.ShiftDown.UseVisualStyleBackColor = true;
            this.ShiftDown.Click += new System.EventHandler(this.ShiftDown_Click);
            // 
            // ShiftUp
            // 
            this.ShiftUp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ShiftUp.Location = new System.Drawing.Point(481, 306);
            this.ShiftUp.Name = "ShiftUp";
            this.ShiftUp.Size = new System.Drawing.Size(121, 35);
            this.ShiftUp.TabIndex = 8;
            this.ShiftUp.Text = "Shift up";
            this.ShiftUp.UseVisualStyleBackColor = true;
            this.ShiftUp.Click += new System.EventHandler(this.ShiftUp_Click);
            // 
            // Pick
            // 
            this.Pick.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Pick.Location = new System.Drawing.Point(481, 174);
            this.Pick.Name = "Pick";
            this.Pick.Size = new System.Drawing.Size(121, 35);
            this.Pick.TabIndex = 9;
            this.Pick.Text = "Picker...";
            this.Pick.UseVisualStyleBackColor = true;
            this.Pick.Click += new System.EventHandler(this.Pick_Click);
            // 
            // VW
            // 
            this.VW.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.VW.Location = new System.Drawing.Point(481, 215);
            this.VW.Name = "VW";
            this.VW.Size = new System.Drawing.Size(121, 35);
            this.VW.TabIndex = 10;
            this.VW.Text = "Viewer...";
            this.VW.UseVisualStyleBackColor = true;
            this.VW.Click += new System.EventHandler(this.VW_Click);
            // 
            // ICO
            // 
            this.ICO.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ICO.Location = new System.Drawing.Point(481, 256);
            this.ICO.Name = "ICO";
            this.ICO.Size = new System.Drawing.Size(121, 35);
            this.ICO.TabIndex = 11;
            this.ICO.Text = "Create Icon";
            this.ICO.UseVisualStyleBackColor = true;
            this.ICO.Click += new System.EventHandler(this.ICO_Click);
            // 
            // SICO
            // 
            this.SICO.Filter = "Icon|*.ico";
            // 
            // LayerViewer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(622, 403);
            this.Controls.Add(this.ICO);
            this.Controls.Add(this.VW);
            this.Controls.Add(this.Pick);
            this.Controls.Add(this.ShiftUp);
            this.Controls.Add(this.ShiftDown);
            this.Controls.Add(this.Blend);
            this.Controls.Add(this.GIF);
            this.Controls.Add(this.InvSel);
            this.Controls.Add(this.Save);
            this.Controls.Add(this.LayLst);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(630, 338);
            this.Name = "LayerViewer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "LayerViewer";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.LayerViewer_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.LayLst)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.DataGridView LayLst;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewImageColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.Button Save;
        private System.Windows.Forms.Button InvSel;
        private System.Windows.Forms.Button GIF;
        private System.Windows.Forms.Button Blend;
        private System.Windows.Forms.Button ShiftDown;
        private System.Windows.Forms.Button ShiftUp;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Button Pick;
        private System.Windows.Forms.Button VW;
        private System.Windows.Forms.Button ICO;
        private System.Windows.Forms.SaveFileDialog SICO;
    }
}