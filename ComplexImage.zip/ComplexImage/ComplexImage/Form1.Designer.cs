﻿namespace ComplexImage
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Prog = new System.Windows.Forms.RichTextBox();
            this.Watcher = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ME_Project = new System.Windows.Forms.ToolStripMenuItem();
            this.ME_Load = new System.Windows.Forms.ToolStripMenuItem();
            this.ME_LoadOld = new System.Windows.Forms.ToolStripMenuItem();
            this.ME_Save = new System.Windows.Forms.ToolStripMenuItem();
            this.ME_SaveAs = new System.Windows.Forms.ToolStripMenuItem();
            this.ME_MakeIt = new System.Windows.Forms.ToolStripMenuItem();
            this.ME_Edit = new System.Windows.Forms.ToolStripMenuItem();
            this.ME_Copy = new System.Windows.Forms.ToolStripMenuItem();
            this.ME_Cut = new System.Windows.Forms.ToolStripMenuItem();
            this.ME_Paste = new System.Windows.Forms.ToolStripMenuItem();
            this.ME_Tools = new System.Windows.Forms.ToolStripMenuItem();
            this.ME_Fonts = new System.Windows.Forms.ToolStripMenuItem();
            this.ME_ColScl = new System.Windows.Forms.ToolStripMenuItem();
            this.ME_ColReg = new System.Windows.Forms.ToolStripMenuItem();
            this.ME_Templates = new System.Windows.Forms.ToolStripMenuItem();
            this.ME_MegPaint = new System.Windows.Forms.ToolStripMenuItem();
            this.ME_Help = new System.Windows.Forms.ToolStripMenuItem();
            this.ME_IDX = new System.Windows.Forms.ToolStripMenuItem();
            this.ME_About = new System.Windows.Forms.ToolStripMenuItem();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.STLL = new System.Windows.Forms.ToolStripStatusLabel();
            this.STLT = new System.Windows.Forms.ToolStripStatusLabel();
            this.STCC = new System.Windows.Forms.ToolStripStatusLabel();
            this.STTS = new System.Windows.Forms.ToolStripStatusLabel();
            this.MBAR = new System.Windows.Forms.MenuStrip();
            this.BasisCmd = new System.Windows.Forms.ToolStrip();
            this.TB_Loop = new System.Windows.Forms.ToolStripButton();
            this.TB_Condition = new System.Windows.Forms.ToolStripButton();
            this.TB_Break = new System.Windows.Forms.ToolStripButton();
            this.TB_Continue = new System.Windows.Forms.ToolStripButton();
            this.TB_Label = new System.Windows.Forms.ToolStripButton();
            this.TB_Jump = new System.Windows.Forms.ToolStripButton();
            this.TB_Param = new System.Windows.Forms.ToolStripButton();
            this.TB_RemPar = new System.Windows.Forms.ToolStripButton();
            this.TB_Watch = new System.Windows.Forms.ToolStripButton();
            this.LayerOperations = new System.Windows.Forms.ToolStrip();
            this.TB_InsertLayer = new System.Windows.Forms.ToolStripButton();
            this.TB_ActiveLayer = new System.Windows.Forms.ToolStripButton();
            this.TB_SetColor = new System.Windows.Forms.ToolStripButton();
            this.TB_LineTo = new System.Windows.Forms.ToolStripButton();
            this.TB_RegFill = new System.Windows.Forms.ToolStripButton();
            this.TB_Text = new System.Windows.Forms.ToolStripButton();
            this.TB_GetPixel = new System.Windows.Forms.ToolStripButton();
            this.TB_SetPixel = new System.Windows.Forms.ToolStripButton();
            this.TB_PixelRegion = new System.Windows.Forms.ToolStripButton();
            this.TB_PutPixelRegion = new System.Windows.Forms.ToolStripButton();
            this.TB_ResizeLayer = new System.Windows.Forms.ToolStripButton();
            this.TB_UseLayerSize = new System.Windows.Forms.ToolStripButton();
            this.TB_ColorMap = new System.Windows.Forms.ToolStripButton();
            this.TB_DelLayer = new System.Windows.Forms.ToolStripButton();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.RunAlrt = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.BRK = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.FilePanel = new System.Windows.Forms.RichTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.Watcher)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.MBAR.SuspendLayout();
            this.BasisCmd.SuspendLayout();
            this.LayerOperations.SuspendLayout();
            this.RunAlrt.SuspendLayout();
            this.SuspendLayout();
            // 
            // Prog
            // 
            this.Prog.AcceptsTab = true;
            resources.ApplyResources(this.Prog, "Prog");
            this.Prog.DetectUrls = false;
            this.Prog.Name = "Prog";
            this.Prog.TextChanged += new System.EventHandler(this.Prog_TextChanged);
            this.Prog.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Prog_KeyDown);
            this.Prog.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Prog_MouseMove);
            // 
            // Watcher
            // 
            this.Watcher.AllowUserToAddRows = false;
            this.Watcher.AllowUserToDeleteRows = false;
            resources.ApplyResources(this.Watcher, "Watcher");
            this.Watcher.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Watcher.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2});
            this.Watcher.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.Watcher.MultiSelect = false;
            this.Watcher.Name = "Watcher";
            this.Watcher.ReadOnly = true;
            this.Watcher.RowHeadersVisible = false;
            this.Watcher.RowTemplate.Height = 23;
            // 
            // Column1
            // 
            resources.ApplyResources(this.Column1, "Column1");
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column2
            // 
            resources.ApplyResources(this.Column2, "Column2");
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // ME_Project
            // 
            this.ME_Project.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ME_Load,
            this.ME_LoadOld,
            this.ME_Save,
            this.ME_SaveAs,
            this.ME_MakeIt});
            this.ME_Project.Name = "ME_Project";
            resources.ApplyResources(this.ME_Project, "ME_Project");
            // 
            // ME_Load
            // 
            this.ME_Load.Name = "ME_Load";
            resources.ApplyResources(this.ME_Load, "ME_Load");
            this.ME_Load.Click += new System.EventHandler(this.ME_Load_Click);
            // 
            // ME_LoadOld
            // 
            this.ME_LoadOld.Name = "ME_LoadOld";
            resources.ApplyResources(this.ME_LoadOld, "ME_LoadOld");
            this.ME_LoadOld.Click += new System.EventHandler(this.ME_LoadOld_Click);
            // 
            // ME_Save
            // 
            this.ME_Save.Name = "ME_Save";
            resources.ApplyResources(this.ME_Save, "ME_Save");
            this.ME_Save.Click += new System.EventHandler(this.ME_Save_Click);
            // 
            // ME_SaveAs
            // 
            this.ME_SaveAs.Name = "ME_SaveAs";
            resources.ApplyResources(this.ME_SaveAs, "ME_SaveAs");
            this.ME_SaveAs.Click += new System.EventHandler(this.ME_SaveAs_Click);
            // 
            // ME_MakeIt
            // 
            this.ME_MakeIt.Name = "ME_MakeIt";
            resources.ApplyResources(this.ME_MakeIt, "ME_MakeIt");
            this.ME_MakeIt.Click += new System.EventHandler(this.ME_MakeIt_Click);
            // 
            // ME_Edit
            // 
            this.ME_Edit.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ME_Copy,
            this.ME_Cut,
            this.ME_Paste});
            this.ME_Edit.Name = "ME_Edit";
            resources.ApplyResources(this.ME_Edit, "ME_Edit");
            // 
            // ME_Copy
            // 
            this.ME_Copy.Name = "ME_Copy";
            resources.ApplyResources(this.ME_Copy, "ME_Copy");
            this.ME_Copy.Click += new System.EventHandler(this.ME_Copy_Click);
            // 
            // ME_Cut
            // 
            this.ME_Cut.Name = "ME_Cut";
            resources.ApplyResources(this.ME_Cut, "ME_Cut");
            this.ME_Cut.Click += new System.EventHandler(this.ME_Cut_Click);
            // 
            // ME_Paste
            // 
            this.ME_Paste.Name = "ME_Paste";
            resources.ApplyResources(this.ME_Paste, "ME_Paste");
            this.ME_Paste.Click += new System.EventHandler(this.ME_Paste_Click);
            // 
            // ME_Tools
            // 
            this.ME_Tools.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ME_Fonts,
            this.ME_ColScl,
            this.ME_ColReg,
            this.ME_Templates,
            this.ME_MegPaint});
            this.ME_Tools.Name = "ME_Tools";
            resources.ApplyResources(this.ME_Tools, "ME_Tools");
            // 
            // ME_Fonts
            // 
            this.ME_Fonts.Name = "ME_Fonts";
            resources.ApplyResources(this.ME_Fonts, "ME_Fonts");
            this.ME_Fonts.Click += new System.EventHandler(this.ME_Fonts_Click);
            // 
            // ME_ColScl
            // 
            this.ME_ColScl.Name = "ME_ColScl";
            resources.ApplyResources(this.ME_ColScl, "ME_ColScl");
            this.ME_ColScl.Click += new System.EventHandler(this.ME_ColScl_Click);
            // 
            // ME_ColReg
            // 
            this.ME_ColReg.Name = "ME_ColReg";
            resources.ApplyResources(this.ME_ColReg, "ME_ColReg");
            this.ME_ColReg.Click += new System.EventHandler(this.ME_ColReg_Click);
            // 
            // ME_Templates
            // 
            this.ME_Templates.Name = "ME_Templates";
            resources.ApplyResources(this.ME_Templates, "ME_Templates");
            this.ME_Templates.Click += new System.EventHandler(this.ME_Templates_Click);
            // 
            // ME_MegPaint
            // 
            this.ME_MegPaint.Name = "ME_MegPaint";
            resources.ApplyResources(this.ME_MegPaint, "ME_MegPaint");
            this.ME_MegPaint.Click += new System.EventHandler(this.ME_MegPaint_Click);
            // 
            // ME_Help
            // 
            this.ME_Help.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ME_IDX,
            this.ME_About});
            this.ME_Help.Name = "ME_Help";
            resources.ApplyResources(this.ME_Help, "ME_Help");
            // 
            // ME_IDX
            // 
            this.ME_IDX.Name = "ME_IDX";
            resources.ApplyResources(this.ME_IDX, "ME_IDX");
            this.ME_IDX.Click += new System.EventHandler(this.ME_IDX_Click);
            // 
            // ME_About
            // 
            this.ME_About.Name = "ME_About";
            resources.ApplyResources(this.ME_About, "ME_About");
            this.ME_About.Click += new System.EventHandler(this.ME_About_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            resources.ApplyResources(this.openFileDialog1, "openFileDialog1");
            // 
            // saveFileDialog1
            // 
            resources.ApplyResources(this.saveFileDialog1, "saveFileDialog1");
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.STLL,
            this.STLT,
            this.STCC,
            this.STTS});
            resources.ApplyResources(this.statusStrip1, "statusStrip1");
            this.statusStrip1.Name = "statusStrip1";
            // 
            // STLL
            // 
            this.STLL.Name = "STLL";
            resources.ApplyResources(this.STLL, "STLL");
            // 
            // STLT
            // 
            this.STLT.Name = "STLT";
            resources.ApplyResources(this.STLT, "STLT");
            // 
            // STCC
            // 
            this.STCC.Name = "STCC";
            resources.ApplyResources(this.STCC, "STCC");
            // 
            // STTS
            // 
            this.STTS.Name = "STTS";
            resources.ApplyResources(this.STTS, "STTS");
            // 
            // MBAR
            // 
            this.MBAR.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ME_Project,
            this.ME_Edit,
            this.ME_Tools,
            this.ME_Help});
            resources.ApplyResources(this.MBAR, "MBAR");
            this.MBAR.Name = "MBAR";
            this.MBAR.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            // 
            // BasisCmd
            // 
            this.BasisCmd.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.BasisCmd.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.BasisCmd.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TB_Loop,
            this.TB_Condition,
            this.TB_Break,
            this.TB_Continue,
            this.TB_Label,
            this.TB_Jump,
            this.TB_Param,
            this.TB_RemPar,
            this.TB_Watch});
            resources.ApplyResources(this.BasisCmd, "BasisCmd");
            this.BasisCmd.Name = "BasisCmd";
            this.BasisCmd.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            // 
            // TB_Loop
            // 
            this.TB_Loop.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            resources.ApplyResources(this.TB_Loop, "TB_Loop");
            this.TB_Loop.Name = "TB_Loop";
            this.TB_Loop.Click += new System.EventHandler(this.TB_Loop_Click);
            // 
            // TB_Condition
            // 
            this.TB_Condition.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            resources.ApplyResources(this.TB_Condition, "TB_Condition");
            this.TB_Condition.Name = "TB_Condition";
            this.TB_Condition.Click += new System.EventHandler(this.TB_Condition_Click);
            // 
            // TB_Break
            // 
            this.TB_Break.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            resources.ApplyResources(this.TB_Break, "TB_Break");
            this.TB_Break.Name = "TB_Break";
            this.TB_Break.Click += new System.EventHandler(this.TB_Break_Click);
            // 
            // TB_Continue
            // 
            this.TB_Continue.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            resources.ApplyResources(this.TB_Continue, "TB_Continue");
            this.TB_Continue.Name = "TB_Continue";
            this.TB_Continue.Click += new System.EventHandler(this.TB_Continue_Click);
            // 
            // TB_Label
            // 
            this.TB_Label.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            resources.ApplyResources(this.TB_Label, "TB_Label");
            this.TB_Label.Name = "TB_Label";
            this.TB_Label.Click += new System.EventHandler(this.TB_Label_Click);
            // 
            // TB_Jump
            // 
            this.TB_Jump.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            resources.ApplyResources(this.TB_Jump, "TB_Jump");
            this.TB_Jump.Name = "TB_Jump";
            this.TB_Jump.Click += new System.EventHandler(this.TB_Jump_Click);
            // 
            // TB_Param
            // 
            this.TB_Param.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            resources.ApplyResources(this.TB_Param, "TB_Param");
            this.TB_Param.Name = "TB_Param";
            this.TB_Param.Click += new System.EventHandler(this.TB_Param_Click);
            // 
            // TB_RemPar
            // 
            this.TB_RemPar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            resources.ApplyResources(this.TB_RemPar, "TB_RemPar");
            this.TB_RemPar.Name = "TB_RemPar";
            this.TB_RemPar.Click += new System.EventHandler(this.TB_RemPar_Click);
            // 
            // TB_Watch
            // 
            this.TB_Watch.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            resources.ApplyResources(this.TB_Watch, "TB_Watch");
            this.TB_Watch.Name = "TB_Watch";
            this.TB_Watch.Click += new System.EventHandler(this.TB_Watch_Click);
            // 
            // LayerOperations
            // 
            this.LayerOperations.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.LayerOperations.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.LayerOperations.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TB_InsertLayer,
            this.TB_ActiveLayer,
            this.TB_SetColor,
            this.TB_LineTo,
            this.TB_RegFill,
            this.TB_Text,
            this.TB_GetPixel,
            this.TB_SetPixel,
            this.TB_PixelRegion,
            this.TB_PutPixelRegion,
            this.TB_ResizeLayer,
            this.TB_UseLayerSize,
            this.TB_ColorMap,
            this.TB_DelLayer});
            resources.ApplyResources(this.LayerOperations, "LayerOperations");
            this.LayerOperations.Name = "LayerOperations";
            this.LayerOperations.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            // 
            // TB_InsertLayer
            // 
            this.TB_InsertLayer.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            resources.ApplyResources(this.TB_InsertLayer, "TB_InsertLayer");
            this.TB_InsertLayer.Name = "TB_InsertLayer";
            this.TB_InsertLayer.Click += new System.EventHandler(this.TB_InsertLayer_Click);
            // 
            // TB_ActiveLayer
            // 
            this.TB_ActiveLayer.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            resources.ApplyResources(this.TB_ActiveLayer, "TB_ActiveLayer");
            this.TB_ActiveLayer.Name = "TB_ActiveLayer";
            this.TB_ActiveLayer.Click += new System.EventHandler(this.TB_ActiveLayer_Click);
            // 
            // TB_SetColor
            // 
            this.TB_SetColor.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            resources.ApplyResources(this.TB_SetColor, "TB_SetColor");
            this.TB_SetColor.Name = "TB_SetColor";
            this.TB_SetColor.Click += new System.EventHandler(this.TB_SetColor_Click);
            // 
            // TB_LineTo
            // 
            this.TB_LineTo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            resources.ApplyResources(this.TB_LineTo, "TB_LineTo");
            this.TB_LineTo.Name = "TB_LineTo";
            this.TB_LineTo.Click += new System.EventHandler(this.TB_LineTo_Click);
            // 
            // TB_RegFill
            // 
            this.TB_RegFill.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            resources.ApplyResources(this.TB_RegFill, "TB_RegFill");
            this.TB_RegFill.Name = "TB_RegFill";
            this.TB_RegFill.Click += new System.EventHandler(this.TB_RegFill_Click);
            // 
            // TB_Text
            // 
            this.TB_Text.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            resources.ApplyResources(this.TB_Text, "TB_Text");
            this.TB_Text.Name = "TB_Text";
            this.TB_Text.Click += new System.EventHandler(this.TB_Text_Click);
            // 
            // TB_GetPixel
            // 
            this.TB_GetPixel.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            resources.ApplyResources(this.TB_GetPixel, "TB_GetPixel");
            this.TB_GetPixel.Name = "TB_GetPixel";
            this.TB_GetPixel.Click += new System.EventHandler(this.TB_GetPixel_Click);
            // 
            // TB_SetPixel
            // 
            this.TB_SetPixel.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            resources.ApplyResources(this.TB_SetPixel, "TB_SetPixel");
            this.TB_SetPixel.Name = "TB_SetPixel";
            this.TB_SetPixel.Click += new System.EventHandler(this.TB_SetPixel_Click);
            // 
            // TB_PixelRegion
            // 
            this.TB_PixelRegion.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            resources.ApplyResources(this.TB_PixelRegion, "TB_PixelRegion");
            this.TB_PixelRegion.Name = "TB_PixelRegion";
            this.TB_PixelRegion.Click += new System.EventHandler(this.TB_PixelRegion_Click);
            // 
            // TB_PutPixelRegion
            // 
            this.TB_PutPixelRegion.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            resources.ApplyResources(this.TB_PutPixelRegion, "TB_PutPixelRegion");
            this.TB_PutPixelRegion.Name = "TB_PutPixelRegion";
            this.TB_PutPixelRegion.Click += new System.EventHandler(this.TB_PutPixelRegion_Click);
            // 
            // TB_ResizeLayer
            // 
            this.TB_ResizeLayer.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            resources.ApplyResources(this.TB_ResizeLayer, "TB_ResizeLayer");
            this.TB_ResizeLayer.Name = "TB_ResizeLayer";
            this.TB_ResizeLayer.Click += new System.EventHandler(this.TB_ResizeLayer_Click);
            // 
            // TB_UseLayerSize
            // 
            this.TB_UseLayerSize.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            resources.ApplyResources(this.TB_UseLayerSize, "TB_UseLayerSize");
            this.TB_UseLayerSize.Name = "TB_UseLayerSize";
            this.TB_UseLayerSize.Click += new System.EventHandler(this.TB_UseLayerSize_Click);
            // 
            // TB_ColorMap
            // 
            this.TB_ColorMap.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            resources.ApplyResources(this.TB_ColorMap, "TB_ColorMap");
            this.TB_ColorMap.Name = "TB_ColorMap";
            this.TB_ColorMap.Click += new System.EventHandler(this.TB_ColorMap_Click);
            // 
            // TB_DelLayer
            // 
            this.TB_DelLayer.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            resources.ApplyResources(this.TB_DelLayer, "TB_DelLayer");
            this.TB_DelLayer.Name = "TB_DelLayer";
            this.TB_DelLayer.Click += new System.EventHandler(this.TB_DelLayer_Click);
            // 
            // colorDialog1
            // 
            this.colorDialog1.AnyColor = true;
            // 
            // RunAlrt
            // 
            resources.ApplyResources(this.RunAlrt, "RunAlrt");
            this.RunAlrt.BackColor = System.Drawing.Color.Yellow;
            this.RunAlrt.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.RunAlrt.Controls.Add(this.label2);
            this.RunAlrt.Controls.Add(this.BRK);
            this.RunAlrt.Controls.Add(this.label1);
            this.RunAlrt.ForeColor = System.Drawing.Color.OrangeRed;
            this.RunAlrt.Name = "RunAlrt";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // BRK
            // 
            this.BRK.BackColor = System.Drawing.Color.Red;
            this.BRK.ForeColor = System.Drawing.Color.Yellow;
            resources.ApplyResources(this.BRK, "BRK");
            this.BRK.Name = "BRK";
            this.BRK.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // FilePanel
            // 
            resources.ApplyResources(this.FilePanel, "FilePanel");
            this.FilePanel.BackColor = System.Drawing.Color.LightGray;
            this.FilePanel.ForeColor = System.Drawing.Color.Red;
            this.FilePanel.Name = "FilePanel";
            // 
            // Form1
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.RunAlrt);
            this.Controls.Add(this.LayerOperations);
            this.Controls.Add(this.BasisCmd);
            this.Controls.Add(this.MBAR);
            this.Controls.Add(this.Prog);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.Watcher);
            this.Controls.Add(this.FilePanel);
            this.Name = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Watcher)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.MBAR.ResumeLayout(false);
            this.MBAR.PerformLayout();
            this.BasisCmd.ResumeLayout(false);
            this.BasisCmd.PerformLayout();
            this.LayerOperations.ResumeLayout(false);
            this.LayerOperations.PerformLayout();
            this.RunAlrt.ResumeLayout(false);
            this.RunAlrt.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView Watcher;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.ToolStripMenuItem ME_Project;
        private System.Windows.Forms.ToolStripMenuItem ME_Load;
        private System.Windows.Forms.ToolStripMenuItem ME_Save;
        private System.Windows.Forms.ToolStripMenuItem ME_MakeIt;
        private System.Windows.Forms.ToolStripMenuItem ME_Tools;
        private System.Windows.Forms.ToolStripMenuItem ME_Fonts;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.ToolStripMenuItem ME_Help;
        public System.Windows.Forms.RichTextBox Prog;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel STLL;
        private System.Windows.Forms.ToolStripStatusLabel STTS;
        private System.Windows.Forms.ToolStripStatusLabel STLT;
        private System.Windows.Forms.ToolStripStatusLabel STCC;
        private System.Windows.Forms.ToolStripMenuItem ME_SaveAs;
        private System.Windows.Forms.ToolStripMenuItem ME_Edit;
        private System.Windows.Forms.ToolStripMenuItem ME_Copy;
        private System.Windows.Forms.ToolStripMenuItem ME_Cut;
        private System.Windows.Forms.ToolStripMenuItem ME_Paste;
        private System.Windows.Forms.ToolStripMenuItem ME_LoadOld;
        private System.Windows.Forms.ToolStripMenuItem ME_ColScl;
        private System.Windows.Forms.ToolStripMenuItem ME_ColReg;
        private System.Windows.Forms.MenuStrip MBAR;
        private System.Windows.Forms.ToolStripMenuItem ME_Templates;
        private System.Windows.Forms.ToolStrip BasisCmd;
        private System.Windows.Forms.ToolStripButton TB_Break;
        private System.Windows.Forms.ToolStripButton TB_Condition;
        private System.Windows.Forms.ToolStripButton TB_Continue;
        private System.Windows.Forms.ToolStripButton TB_Jump;
        private System.Windows.Forms.ToolStripButton TB_Label;
        private System.Windows.Forms.ToolStripButton TB_Loop;
        private System.Windows.Forms.ToolStripButton TB_Param;
        private System.Windows.Forms.ToolStripButton TB_RemPar;
        private System.Windows.Forms.ToolStripButton TB_Watch;
        private System.Windows.Forms.ToolStrip LayerOperations;
        private System.Windows.Forms.ToolStripButton TB_LineTo;
        private System.Windows.Forms.ToolStripButton TB_SetColor;
        private System.Windows.Forms.ToolStripButton TB_RegFill;
        private System.Windows.Forms.ToolStripButton TB_InsertLayer;
        private System.Windows.Forms.ToolStripButton TB_ActiveLayer;
        private System.Windows.Forms.ToolStripButton TB_GetPixel;
        private System.Windows.Forms.ToolStripButton TB_SetPixel;
        private System.Windows.Forms.ToolStripButton TB_DelLayer;
        private System.Windows.Forms.ToolStripButton TB_PixelRegion;
        private System.Windows.Forms.ToolStripButton TB_PutPixelRegion;
        private System.Windows.Forms.ToolStripButton TB_Text;
        private System.Windows.Forms.ToolStripButton TB_ResizeLayer;
        private System.Windows.Forms.ToolStripButton TB_UseLayerSize;
        private System.Windows.Forms.ToolStripButton TB_ColorMap;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.Panel RunAlrt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button BRK;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox FilePanel;
        private System.Windows.Forms.ToolStripMenuItem ME_IDX;
        private System.Windows.Forms.ToolStripMenuItem ME_About;
        private System.Windows.Forms.ToolStripMenuItem ME_MegPaint;
    }
}

