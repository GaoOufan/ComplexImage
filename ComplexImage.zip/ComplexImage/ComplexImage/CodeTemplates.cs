﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace ComplexImage
{
    public partial class CodeTemplates : Form
    {
        public RichTextBox rtf;
        RT_NewTemplate tinfo = new RT_NewTemplate();
        RT_NewTemplate tedit = new RT_NewTemplate(true);

        public CodeTemplates()
        {
            InitializeComponent();
            string src = Path.GetDirectoryName(Application.ExecutablePath) + "\\Templates";
            if (Directory.Exists(src) == false)
            {
                Directory.CreateDirectory(src);
                // Check if have built-in *.citf file - install it as beginner.
            }
            string[] F = Directory.GetFiles(src);
            bool FPI=false;
            foreach (string f in F)
            {
                if (Path.GetExtension(f) != ".cit") continue;
                try
                {
                    FileStream fs = new FileStream(f, FileMode.Open);
                    BinaryReader br = new BinaryReader(fs);
                    string TemplateName = br.ReadString();
                    string TemplateGroup = br.ReadString();
                    Bitmap TBMP = new Bitmap(120, 120);
                    for (int y = 0; y < 120; y++)
                        for (int x = 0; x < 120; x++)
                            TBMP.SetPixel(x, y, Color.FromArgb(br.ReadByte(), br.ReadByte(), br.ReadByte(), br.ReadByte()));
                    br.Close(); fs.Close();
                    int d = 0;
                    while (d < LSV.Groups.Count)
                    {
                        if (LSV.Groups[d].Header == TemplateGroup) break;
                        d++;
                    }
                    if (d == LSV.Groups.Count) LSV.Groups.Add(new ListViewGroup(TemplateGroup));
                    int m = imageList1.Images.Count;
                    imageList1.Images.Add((Image)TBMP.Clone(), Color.Transparent);
                    string k = TemplateName.Replace(" ", "_");
                    LSV.Items.Add(k,TemplateName, m);
                    LSV.Items[LSV.Items.IndexOfKey(k)].Group = LSV.Groups[d];
                }
                catch {
                    if(FPI==false) {
                        MessageBox.Show("Problematic file encountered - it's extention will be renamed to *.citx");
                        FPI=true;
                    }
                    File.Move(f, f + "x");
                }
            }
        }

        private void LSV_ItemActivate(object sender, EventArgs e)
        {
            FileStream fs = new FileStream(Path.GetDirectoryName(Application.ExecutablePath)+ "\\Templates\\"+LSV.SelectedItems[0].Text.Replace(" ","_")+".cit", FileMode.Open);
            BinaryReader br = new BinaryReader(fs);
            br.ReadString(); br.ReadString(); fs.Seek(57600, SeekOrigin.Current);
            rtf.SelectedText = br.ReadString();
            br.Close();
            fs.Close();
            this.Close();
        }

        private void RT_I_Reg_Click(object sender, EventArgs e)
        {
            for (int d = 0; d < LSV.Groups.Count; d++) tinfo.TGroup.Items.Add(LSV.Groups[d].Header);
            if (tinfo.ShowDialog() == DialogResult.Yes)
            {
                int g=0;
                while (g < LSV.Groups.Count)
                {
                    if (tinfo.TGroup.Text == LSV.Groups[g].Header) break;
                    g++;
                }
                if (g == LSV.Groups.Count) LSV.Groups.Add(new ListViewGroup(tinfo.TGroup.Text));
                string k = tinfo.TName.Text.Replace(" ", "_");
                imageList1.Images.Add(tinfo.ImgTag.BackgroundImage, Color.Transparent);
                LSV.Items.Add(k,tinfo.TName.Text, imageList1.Images.Count - 1);
                int b = LSV.Items.IndexOfKey(k);
                LSV.Items[b].Group = LSV.Groups[g];

                string dst = Path.GetDirectoryName(Application.ExecutablePath) + "\\Templates\\" + k + ".cit";
                FileStream fs = new FileStream(dst, FileMode.CreateNew);
                BinaryWriter bw = new BinaryWriter(fs);
                bw.Write(tinfo.TName.Text);
                bw.Write(tinfo.TGroup.Text);
                Bitmap BN = (Bitmap)tinfo.ImgTag.BackgroundImage;
                for(int y=0 ; y<120 ; y++)
                    for (int x = 0; x < 120; x++)
                    {
                        Color C = BN.GetPixel(x, y);
                        bw.Write(C.A); bw.Write(C.R); bw.Write(C.G); bw.Write(C.B);
                    }
                bw.Write(tinfo.TCode.Text);
                //<> A help file rtf string can really help
                bw.Close();
                fs.Close();
            }
        }

        private void RT_I_Edt_Click(object sender, EventArgs e)
        {
            if (LSV.SelectedItems.Count == 0) return;
            for (int d = 0; d < LSV.Groups.Count; d++) tedit.TGroup.Items.Add(LSV.Groups[d].Header);
            tedit.Text = "Edit properties of template "+LSV.SelectedItems[0].Text;
            tedit.TName.Text = LSV.SelectedItems[0].Text;
            tedit.TGroup.Text = LSV.SelectedItems[0].Group.Header;
            tedit.ImgTag.BackgroundImage = new Bitmap(imageList1.Images[LSV.SelectedItems[0].ImageIndex]);
            FileStream fs = new FileStream(Path.GetDirectoryName(Application.ExecutablePath) + "\\Templates\\" + LSV.SelectedItems[0].Text.Replace(" ", "_") + ".cit", FileMode.Open);
            BinaryReader br = new BinaryReader(fs);
            br.ReadString(); br.ReadString(); fs.Seek(57600, SeekOrigin.Current);
            tedit.TCode.Text = br.ReadString();
            br.Close();
            fs.Close();
            if (tedit.ShowDialog() == DialogResult.Yes)
            {
                int g = 0;
                while (g < LSV.Groups.Count)
                {
                    if (tedit.TGroup.Text == LSV.Groups[g].Header) break;
                    g++;
                }
                if (g == LSV.Groups.Count) LSV.Groups.Add(new ListViewGroup(tedit.TGroup.Text));
                string k = tedit.TName.Text.Replace(" ", "_");
                imageList1.Images.Add(tedit.ImgTag.BackgroundImage, Color.Transparent);
                LSV.Items.Add(k, tedit.TName.Text, imageList1.Images.Count - 1);
                int b = LSV.Items.IndexOfKey(k);
                LSV.Items[b].Group = LSV.Groups[g];

                string dst = Path.GetDirectoryName(Application.ExecutablePath) + "\\Templates\\" + k + ".cit";
                fs = new FileStream(dst, FileMode.CreateNew);
                BinaryWriter bw = new BinaryWriter(fs);
                bw.Write(tedit.TName.Text);
                bw.Write(tedit.TGroup.Text);
                Bitmap BN = (Bitmap)tedit.ImgTag.BackgroundImage;
                for (int y = 0; y < 120; y++)
                    for (int x = 0; x < 120; x++)
                    {
                        Color C = BN.GetPixel(x, y);
                        bw.Write(C.A); bw.Write(C.R); bw.Write(C.G); bw.Write(C.B);
                    }
                bw.Write(tedit.TCode.Text);
                //<> A help file rtf string can really help
                bw.Close();
                fs.Close();
            }
        }

        private void RT_I_Mov_Click(object sender, EventArgs e)
        {
            // delete template file! Confirmation required!
        }

        private void RT_T_Import_Click(object sender, EventArgs e)
        {
            //
        }

        private void RT_T_Export_Click(object sender, EventArgs e)
        {
            //
        }
    }
}
