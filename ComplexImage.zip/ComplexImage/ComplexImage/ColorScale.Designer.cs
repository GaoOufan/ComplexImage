﻿namespace ComplexImage
{
    partial class ColorScale
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ColorScale));
            this.NO = new System.Windows.Forms.Button();
            this.OK = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.DstLay = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.RegLay = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.RR = new System.Windows.Forms.RadioButton();
            this.RH = new System.Windows.Forms.RadioButton();
            this.RF = new System.Windows.Forms.RadioButton();
            this.R0 = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.RType = new System.Windows.Forms.ComboBox();
            this.GType = new System.Windows.Forms.ComboBox();
            this.BType = new System.Windows.Forms.ComboBox();
            this.AType = new System.Windows.Forms.ComboBox();
            this.RVal = new System.Windows.Forms.TextBox();
            this.GVal = new System.Windows.Forms.TextBox();
            this.BVal = new System.Windows.Forms.TextBox();
            this.AVal = new System.Windows.Forms.TextBox();
            this.Bright = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.IncBright = new System.Windows.Forms.CheckBox();
            this.label9 = new System.Windows.Forms.Label();
            this.ColPrev = new System.Windows.Forms.PictureBox();
            this.RegLayN = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.LayDel = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ColPrev)).BeginInit();
            this.SuspendLayout();
            // 
            // NO
            // 
            this.NO.Location = new System.Drawing.Point(331, 203);
            this.NO.Name = "NO";
            this.NO.Size = new System.Drawing.Size(139, 28);
            this.NO.TabIndex = 0;
            this.NO.Text = "Cancel";
            this.NO.UseVisualStyleBackColor = true;
            this.NO.Click += new System.EventHandler(this.NO_Click);
            // 
            // OK
            // 
            this.OK.Location = new System.Drawing.Point(331, 171);
            this.OK.Name = "OK";
            this.OK.Size = new System.Drawing.Size(139, 28);
            this.OK.TabIndex = 1;
            this.OK.Text = "OK";
            this.OK.UseVisualStyleBackColor = true;
            this.OK.Click += new System.EventHandler(this.OK_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(143, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "Destination layer name:";
            // 
            // DstLay
            // 
            this.DstLay.Location = new System.Drawing.Point(12, 63);
            this.DstLay.MaxLength = 16;
            this.DstLay.Name = "DstLay";
            this.DstLay.Size = new System.Drawing.Size(155, 21);
            this.DstLay.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(143, 12);
            this.label2.TabIndex = 4;
            this.label2.Text = "Regional dividor layer:";
            // 
            // RegLay
            // 
            this.RegLay.AllowDrop = true;
            this.RegLay.BackColor = System.Drawing.Color.White;
            this.RegLay.ForeColor = System.Drawing.Color.OrangeRed;
            this.RegLay.Location = new System.Drawing.Point(12, 26);
            this.RegLay.MaxLength = 252;
            this.RegLay.Name = "RegLay";
            this.RegLay.ReadOnly = true;
            this.RegLay.Size = new System.Drawing.Size(288, 21);
            this.RegLay.TabIndex = 5;
            this.RegLay.Text = "<Drop image file here>";
            this.RegLay.DragDrop += new System.Windows.Forms.DragEventHandler(this.RegLay_DragDrop);
            this.RegLay.DragOver += new System.Windows.Forms.DragEventHandler(this.RegLay_DragOver);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.RR);
            this.panel1.Controls.Add(this.RH);
            this.panel1.Controls.Add(this.RF);
            this.panel1.Controls.Add(this.R0);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Location = new System.Drawing.Point(331, 9);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(139, 107);
            this.panel1.TabIndex = 6;
            // 
            // RR
            // 
            this.RR.AutoSize = true;
            this.RR.Checked = true;
            this.RR.Location = new System.Drawing.Point(5, 84);
            this.RR.Name = "RR";
            this.RR.Size = new System.Drawing.Size(77, 16);
            this.RR.TabIndex = 4;
            this.RR.TabStop = true;
            this.RR.Text = "No effect";
            this.RR.UseVisualStyleBackColor = true;
            // 
            // RH
            // 
            this.RH.AutoSize = true;
            this.RH.Location = new System.Drawing.Point(5, 62);
            this.RH.Name = "RH";
            this.RH.Size = new System.Drawing.Size(125, 16);
            this.RH.TabIndex = 3;
            this.RH.Text = "Black-Color-White";
            this.RH.UseVisualStyleBackColor = true;
            // 
            // RF
            // 
            this.RF.AutoSize = true;
            this.RF.Location = new System.Drawing.Point(5, 40);
            this.RF.Name = "RF";
            this.RF.Size = new System.Drawing.Size(107, 16);
            this.RF.TabIndex = 2;
            this.RF.Text = "Color to white";
            this.RF.UseVisualStyleBackColor = true;
            // 
            // R0
            // 
            this.R0.AutoSize = true;
            this.R0.Location = new System.Drawing.Point(5, 18);
            this.R0.Name = "R0";
            this.R0.Size = new System.Drawing.Size(107, 16);
            this.R0.TabIndex = 1;
            this.R0.Text = "Color to black";
            this.R0.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 3);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 12);
            this.label3.TabIndex = 0;
            this.label3.Text = "Scaling mode:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 93);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(107, 12);
            this.label4.TabIndex = 0;
            this.label4.Text = "Basis color mode:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(10, 111);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(11, 12);
            this.label5.TabIndex = 7;
            this.label5.Text = "R";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 133);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(11, 12);
            this.label6.TabIndex = 8;
            this.label6.Text = "G";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(10, 156);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(11, 12);
            this.label7.TabIndex = 9;
            this.label7.Text = "B";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(10, 179);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(11, 12);
            this.label8.TabIndex = 10;
            this.label8.Text = "A";
            // 
            // RType
            // 
            this.RType.FormattingEnabled = true;
            this.RType.Items.AddRange(new object[] {
            "Regular 0-255:",
            "Preserve original value",
            "Invert value",
            "Preserve Red",
            "Preserve Green",
            "Preserve Blue",
            "Preserve Alpha",
            "Average R-G-B",
            "Average R-G-B-A",
            "Average R-G",
            "Average R-B",
            "Average G-B"});
            this.RType.Location = new System.Drawing.Point(27, 108);
            this.RType.Name = "RType";
            this.RType.Size = new System.Drawing.Size(261, 20);
            this.RType.TabIndex = 11;
            this.RType.SelectedIndexChanged += new System.EventHandler(this.RType_SelectedIndexChanged);
            // 
            // GType
            // 
            this.GType.FormattingEnabled = true;
            this.GType.Items.AddRange(new object[] {
            "Regular 0-255:",
            "Preserve original value",
            "Invert value",
            "Preserve Red",
            "Preserve Green",
            "Preserve Blue",
            "Preserve Alpha",
            "Average R-G-B",
            "Average R-G-B-A",
            "Average R-G",
            "Average R-B",
            "Average G-B"});
            this.GType.Location = new System.Drawing.Point(27, 130);
            this.GType.Name = "GType";
            this.GType.Size = new System.Drawing.Size(261, 20);
            this.GType.TabIndex = 12;
            this.GType.SelectedIndexChanged += new System.EventHandler(this.GType_SelectedIndexChanged);
            // 
            // BType
            // 
            this.BType.FormattingEnabled = true;
            this.BType.Items.AddRange(new object[] {
            "Regular 0-255:",
            "Preserve original value",
            "Invert value",
            "Preserve Red",
            "Preserve Green",
            "Preserve Blue",
            "Preserve Alpha",
            "Average R-G-B",
            "Average R-G-B-A",
            "Average R-G",
            "Average R-B",
            "Average G-B"});
            this.BType.Location = new System.Drawing.Point(27, 153);
            this.BType.Name = "BType";
            this.BType.Size = new System.Drawing.Size(261, 20);
            this.BType.TabIndex = 13;
            this.BType.SelectedIndexChanged += new System.EventHandler(this.BType_SelectedIndexChanged);
            // 
            // AType
            // 
            this.AType.FormattingEnabled = true;
            this.AType.Items.AddRange(new object[] {
            "Regular 0-255:",
            "Preserve original value",
            "Invert value",
            "Preserve Red",
            "Preserve Green",
            "Preserve Blue",
            "Preserve Alpha",
            "Average R-G-B",
            "Average R-G-B-A",
            "Average R-G",
            "Average R-B",
            "Average G-B"});
            this.AType.Location = new System.Drawing.Point(27, 176);
            this.AType.Name = "AType";
            this.AType.Size = new System.Drawing.Size(261, 20);
            this.AType.TabIndex = 14;
            this.AType.SelectedIndexChanged += new System.EventHandler(this.AType_SelectedIndexChanged);
            // 
            // RVal
            // 
            this.RVal.Font = new System.Drawing.Font("SimSun", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.RVal.Location = new System.Drawing.Point(294, 107);
            this.RVal.MaxLength = 3;
            this.RVal.Name = "RVal";
            this.RVal.Size = new System.Drawing.Size(31, 21);
            this.RVal.TabIndex = 15;
            this.RVal.Text = "255";
            this.RVal.TextChanged += new System.EventHandler(this.RVal_TextChanged);
            // 
            // GVal
            // 
            this.GVal.Font = new System.Drawing.Font("SimSun", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.GVal.Location = new System.Drawing.Point(294, 130);
            this.GVal.MaxLength = 3;
            this.GVal.Name = "GVal";
            this.GVal.Size = new System.Drawing.Size(31, 21);
            this.GVal.TabIndex = 16;
            this.GVal.Text = "255";
            this.GVal.TextChanged += new System.EventHandler(this.GVal_TextChanged);
            // 
            // BVal
            // 
            this.BVal.Font = new System.Drawing.Font("SimSun", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.BVal.Location = new System.Drawing.Point(294, 153);
            this.BVal.MaxLength = 3;
            this.BVal.Name = "BVal";
            this.BVal.Size = new System.Drawing.Size(31, 21);
            this.BVal.TabIndex = 17;
            this.BVal.Text = "255";
            this.BVal.TextChanged += new System.EventHandler(this.BVal_TextChanged);
            // 
            // AVal
            // 
            this.AVal.Font = new System.Drawing.Font("SimSun", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.AVal.Location = new System.Drawing.Point(294, 176);
            this.AVal.MaxLength = 3;
            this.AVal.Name = "AVal";
            this.AVal.Size = new System.Drawing.Size(31, 21);
            this.AVal.TabIndex = 18;
            this.AVal.Text = "255";
            this.AVal.TextChanged += new System.EventHandler(this.AVal_TextChanged);
            // 
            // Bright
            // 
            this.Bright.Font = new System.Drawing.Font("SimSun", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Bright.Location = new System.Drawing.Point(331, 133);
            this.Bright.MaxLength = 8;
            this.Bright.Name = "Bright";
            this.Bright.Size = new System.Drawing.Size(74, 21);
            this.Bright.TabIndex = 20;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(411, 136);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(59, 12);
            this.label10.TabIndex = 21;
            this.label10.Text = "Value 0-1";
            // 
            // IncBright
            // 
            this.IncBright.AutoSize = true;
            this.IncBright.Location = new System.Drawing.Point(331, 116);
            this.IncBright.Name = "IncBright";
            this.IncBright.Size = new System.Drawing.Size(132, 16);
            this.IncBright.TabIndex = 22;
            this.IncBright.Text = "Brightness degree:";
            this.IncBright.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(10, 203);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 28);
            this.label9.TabIndex = 23;
            this.label9.Text = "Color preview:";
            // 
            // ColPrev
            // 
            this.ColPrev.BackColor = System.Drawing.Color.White;
            this.ColPrev.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ColPrev.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ColPrev.Location = new System.Drawing.Point(69, 203);
            this.ColPrev.Name = "ColPrev";
            this.ColPrev.Size = new System.Drawing.Size(256, 28);
            this.ColPrev.TabIndex = 24;
            this.ColPrev.TabStop = false;
            // 
            // RegLayN
            // 
            this.RegLayN.Location = new System.Drawing.Point(173, 63);
            this.RegLayN.MaxLength = 16;
            this.RegLayN.Name = "RegLayN";
            this.RegLayN.Size = new System.Drawing.Size(152, 21);
            this.RegLayN.TabIndex = 25;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(171, 48);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(119, 12);
            this.label11.TabIndex = 26;
            this.label11.Text = "Dividor layer name:";
            // 
            // LayDel
            // 
            this.LayDel.ForeColor = System.Drawing.Color.Red;
            this.LayDel.Location = new System.Drawing.Point(306, 26);
            this.LayDel.Name = "LayDel";
            this.LayDel.Size = new System.Drawing.Size(19, 21);
            this.LayDel.TabIndex = 27;
            this.LayDel.Text = "X";
            this.LayDel.UseVisualStyleBackColor = true;
            this.LayDel.Click += new System.EventHandler(this.LayDel_Click);
            // 
            // ColorScale
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(478, 229);
            this.Controls.Add(this.LayDel);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.RegLayN);
            this.Controls.Add(this.ColPrev);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.IncBright);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.Bright);
            this.Controls.Add(this.AVal);
            this.Controls.Add(this.BVal);
            this.Controls.Add(this.GVal);
            this.Controls.Add(this.RVal);
            this.Controls.Add(this.AType);
            this.Controls.Add(this.BType);
            this.Controls.Add(this.GType);
            this.Controls.Add(this.RType);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.RegLay);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.DstLay);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.OK);
            this.Controls.Add(this.NO);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(484, 262);
            this.MinimumSize = new System.Drawing.Size(484, 262);
            this.Name = "ColorScale";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Color Scale";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ColPrev)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button NO;
        private System.Windows.Forms.Button OK;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox DstLay;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox RegLay;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton RR;
        private System.Windows.Forms.RadioButton RH;
        private System.Windows.Forms.RadioButton RF;
        private System.Windows.Forms.RadioButton R0;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox RType;
        private System.Windows.Forms.ComboBox GType;
        private System.Windows.Forms.ComboBox BType;
        private System.Windows.Forms.ComboBox AType;
        private System.Windows.Forms.TextBox RVal;
        private System.Windows.Forms.TextBox GVal;
        private System.Windows.Forms.TextBox BVal;
        private System.Windows.Forms.TextBox AVal;
        private System.Windows.Forms.TextBox Bright;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.CheckBox IncBright;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.PictureBox ColPrev;
        private System.Windows.Forms.TextBox RegLayN;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button LayDel;
    }
}