﻿namespace ComplexImage
{
    partial class ColorListSelector
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ColorListSelector));
            this.ColorList = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OK = new System.Windows.Forms.Button();
            this.NO = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.ColorList)).BeginInit();
            this.SuspendLayout();
            // 
            // ColorList
            // 
            this.ColorList.AllowUserToAddRows = false;
            this.ColorList.AllowUserToDeleteRows = false;
            this.ColorList.AllowUserToResizeColumns = false;
            this.ColorList.AllowUserToResizeRows = false;
            this.ColorList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.ColorList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ColorList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5});
            this.ColorList.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.ColorList.Location = new System.Drawing.Point(0, 0);
            this.ColorList.Name = "ColorList";
            this.ColorList.ReadOnly = true;
            this.ColorList.RowHeadersVisible = false;
            this.ColorList.RowTemplate.Height = 23;
            this.ColorList.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ColorList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.ColorList.Size = new System.Drawing.Size(192, 228);
            this.ColorList.TabIndex = 1;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Color";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column1.Width = 50;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "A";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 30;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "R";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.Width = 30;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "G";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.Width = 30;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "B";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            this.Column5.Width = 30;
            // 
            // OK
            // 
            this.OK.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.OK.Location = new System.Drawing.Point(102, 234);
            this.OK.Name = "OK";
            this.OK.Size = new System.Drawing.Size(90, 36);
            this.OK.TabIndex = 2;
            this.OK.Text = "Accept";
            this.OK.UseVisualStyleBackColor = true;
            this.OK.Click += new System.EventHandler(this.OK_Click);
            // 
            // NO
            // 
            this.NO.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.NO.Location = new System.Drawing.Point(0, 234);
            this.NO.Name = "NO";
            this.NO.Size = new System.Drawing.Size(90, 36);
            this.NO.TabIndex = 3;
            this.NO.Text = "Cancel";
            this.NO.UseVisualStyleBackColor = true;
            this.NO.Click += new System.EventHandler(this.NO_Click);
            // 
            // ColorListSelector
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(192, 273);
            this.ControlBox = false;
            this.Controls.Add(this.NO);
            this.Controls.Add(this.OK);
            this.Controls.Add(this.ColorList);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(200, 800);
            this.MinimumSize = new System.Drawing.Size(200, 200);
            this.Name = "ColorListSelector";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Select colors to be taken";
            ((System.ComponentModel.ISupportInitialize)(this.ColorList)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.DataGridView ColorList;
        private System.Windows.Forms.Button OK;
        private System.Windows.Forms.Button NO;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
    }
}