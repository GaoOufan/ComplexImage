﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ComplexImage
{
    public partial class FI_Text : Form
    {
        public FI_Text()
        {
            InitializeComponent();
        }

        private void OK_Click(object sender, EventArgs e)
        {
            if (TX.Text == "") { MessageBox.Show("Text string is missing!"); return; }
            if (FF.Text == "") { MessageBox.Show("Font is not selected!"); return; }
            DialogResult = DialogResult.Yes;
        }

        private void Cancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.No;
        }

        private void FNT_Click(object sender, EventArgs e)
        {
            if (fontDialog1.ShowDialog() == DialogResult.OK)
            {
                FF.Text = fontDialog1.Font.FontFamily.Name.ToString();
                FS.Text = fontDialog1.Font.Size.ToString();
                FM.Text = ((fontDialog1.Font.Bold == true) ? "B" : "") + ((fontDialog1.Font.Italic == true) ? "I" : "") + ((fontDialog1.Font.Strikeout == true) ? "X" : "") + ((fontDialog1.Font.Underline == true) ? "U" : "");
            }
        }
    }
}
