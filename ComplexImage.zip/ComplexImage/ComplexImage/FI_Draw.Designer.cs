﻿namespace ComplexImage
{
    partial class FI_Draw
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FI_Draw));
            this.OK = new System.Windows.Forms.Button();
            this.Cancel = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.PIC = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.I_Pos = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.PenStat = new System.Windows.Forms.Label();
            this.I_Snap = new System.Windows.Forms.CheckBox();
            this.I_Grid = new System.Windows.Forms.TextBox();
            this.I_Cmd = new System.Windows.Forms.ListBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.TT_LineMode = new System.Windows.Forms.ToolStripButton();
            this.TT_RectMode = new System.Windows.Forms.ToolStripButton();
            this.TT_ArcMode = new System.Windows.Forms.ToolStripButton();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PIC)).BeginInit();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // OK
            // 
            this.OK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.OK.Location = new System.Drawing.Point(366, 254);
            this.OK.Name = "OK";
            this.OK.Size = new System.Drawing.Size(74, 23);
            this.OK.TabIndex = 0;
            this.OK.Text = "Finish";
            this.OK.UseVisualStyleBackColor = true;
            this.OK.Click += new System.EventHandler(this.OK_Click);
            // 
            // Cancel
            // 
            this.Cancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.Cancel.Location = new System.Drawing.Point(446, 254);
            this.Cancel.Name = "Cancel";
            this.Cancel.Size = new System.Drawing.Size(75, 23);
            this.Cancel.TabIndex = 1;
            this.Cancel.Text = "Cancel";
            this.Cancel.UseVisualStyleBackColor = true;
            this.Cancel.Click += new System.EventHandler(this.Cancel_Click);
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.AutoScroll = true;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.PIC);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(348, 192);
            this.panel1.TabIndex = 2;
            // 
            // PIC
            // 
            this.PIC.BackColor = System.Drawing.Color.White;
            this.PIC.Cursor = System.Windows.Forms.Cursors.Cross;
            this.PIC.Location = new System.Drawing.Point(0, 0);
            this.PIC.MinimumSize = new System.Drawing.Size(1, 1);
            this.PIC.Name = "PIC";
            this.PIC.Size = new System.Drawing.Size(16, 16);
            this.PIC.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.PIC.TabIndex = 0;
            this.PIC.TabStop = false;
            this.PIC.MouseClick += new System.Windows.Forms.MouseEventHandler(this.PIC_MouseClick);
            this.PIC.MouseMove += new System.Windows.Forms.MouseEventHandler(this.PIC_MouseMove);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 259);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 3;
            this.label1.Text = "Position";
            // 
            // I_Pos
            // 
            this.I_Pos.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.I_Pos.BackColor = System.Drawing.Color.Tan;
            this.I_Pos.ForeColor = System.Drawing.Color.SaddleBrown;
            this.I_Pos.Location = new System.Drawing.Point(71, 256);
            this.I_Pos.Name = "I_Pos";
            this.I_Pos.ReadOnly = true;
            this.I_Pos.Size = new System.Drawing.Size(96, 21);
            this.I_Pos.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.BackColor = System.Drawing.Color.Yellow;
            this.label2.ForeColor = System.Drawing.Color.OrangeRed;
            this.label2.Location = new System.Drawing.Point(10, 207);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(350, 44);
            this.label2.TabIndex = 5;
            this.label2.Text = "Useful note:\r\nLeft mouse click = Move to\r\nRight mouse click = Toggle pen (up / do" +
                "wn)";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PenStat
            // 
            this.PenStat.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.PenStat.BackColor = System.Drawing.Color.PaleGreen;
            this.PenStat.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PenStat.Font = new System.Drawing.Font("SimSun", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.PenStat.ForeColor = System.Drawing.Color.Green;
            this.PenStat.Location = new System.Drawing.Point(288, 256);
            this.PenStat.Name = "PenStat";
            this.PenStat.Size = new System.Drawing.Size(72, 21);
            this.PenStat.TabIndex = 6;
            this.PenStat.Text = "Pen down";
            this.PenStat.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // I_Snap
            // 
            this.I_Snap.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.I_Snap.AutoSize = true;
            this.I_Snap.Location = new System.Drawing.Point(173, 258);
            this.I_Snap.Name = "I_Snap";
            this.I_Snap.Size = new System.Drawing.Size(54, 16);
            this.I_Snap.TabIndex = 7;
            this.I_Snap.Text = "Grid:";
            this.I_Snap.UseVisualStyleBackColor = true;
            // 
            // I_Grid
            // 
            this.I_Grid.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.I_Grid.Location = new System.Drawing.Point(233, 256);
            this.I_Grid.MaxLength = 3;
            this.I_Grid.Name = "I_Grid";
            this.I_Grid.Size = new System.Drawing.Size(49, 21);
            this.I_Grid.TabIndex = 8;
            // 
            // I_Cmd
            // 
            this.I_Cmd.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.I_Cmd.FormattingEnabled = true;
            this.I_Cmd.ItemHeight = 12;
            this.I_Cmd.Location = new System.Drawing.Point(366, 12);
            this.I_Cmd.Name = "I_Cmd";
            this.I_Cmd.Size = new System.Drawing.Size(155, 232);
            this.I_Cmd.TabIndex = 9;
            this.I_Cmd.KeyDown += new System.Windows.Forms.KeyEventHandler(this.I_Cmd_KeyDown);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.Right;
            this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TT_LineMode,
            this.TT_RectMode,
            this.TT_ArcMode});
            this.toolStrip1.Location = new System.Drawing.Point(526, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.toolStrip1.Size = new System.Drawing.Size(37, 283);
            this.toolStrip1.TabIndex = 10;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // TT_LineMode
            // 
            this.TT_LineMode.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TT_LineMode.Image = ((System.Drawing.Image)(resources.GetObject("TT_LineMode.Image")));
            this.TT_LineMode.ImageTransparentColor = System.Drawing.Color.White;
            this.TT_LineMode.Name = "TT_LineMode";
            this.TT_LineMode.Size = new System.Drawing.Size(34, 36);
            this.TT_LineMode.Text = "Line mode";
            this.TT_LineMode.Click += new System.EventHandler(this.TT_LineMode_Click);
            // 
            // TT_RectMode
            // 
            this.TT_RectMode.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TT_RectMode.Image = ((System.Drawing.Image)(resources.GetObject("TT_RectMode.Image")));
            this.TT_RectMode.ImageTransparentColor = System.Drawing.Color.White;
            this.TT_RectMode.Name = "TT_RectMode";
            this.TT_RectMode.Size = new System.Drawing.Size(34, 36);
            this.TT_RectMode.Text = "Rectangle mode";
            this.TT_RectMode.Click += new System.EventHandler(this.TT_RectMode_Click);
            // 
            // TT_ArcMode
            // 
            this.TT_ArcMode.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TT_ArcMode.Image = ((System.Drawing.Image)(resources.GetObject("TT_ArcMode.Image")));
            this.TT_ArcMode.ImageTransparentColor = System.Drawing.Color.White;
            this.TT_ArcMode.Name = "TT_ArcMode";
            this.TT_ArcMode.Size = new System.Drawing.Size(34, 36);
            this.TT_ArcMode.Text = "Arc mode";
            this.TT_ArcMode.Click += new System.EventHandler(this.TT_ArcMode_Click);
            // 
            // FI_Draw
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(563, 283);
            this.ControlBox = false;
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.I_Cmd);
            this.Controls.Add(this.I_Grid);
            this.Controls.Add(this.I_Snap);
            this.Controls.Add(this.PenStat);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.I_Pos);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Cancel);
            this.Controls.Add(this.OK);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(536, 138);
            this.Name = "FI_Draw";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Draw mode";
            this.Shown += new System.EventHandler(this.FI_Draw_Shown);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PIC)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button OK;
        private System.Windows.Forms.Button Cancel;
        private System.Windows.Forms.Panel panel1;
        public System.Windows.Forms.PictureBox PIC;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox I_Pos;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label PenStat;
        private System.Windows.Forms.CheckBox I_Snap;
        private System.Windows.Forms.TextBox I_Grid;
        public System.Windows.Forms.ListBox I_Cmd;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton TT_LineMode;
        private System.Windows.Forms.ToolStripButton TT_RectMode;
        private System.Windows.Forms.ToolStripButton TT_ArcMode;
    }
}