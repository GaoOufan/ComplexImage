﻿namespace ComplexImage
{
    partial class LayPreview
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LayPreview));
            this.LV = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.LV)).BeginInit();
            this.SuspendLayout();
            // 
            // LV
            // 
            this.LV.BackColor = System.Drawing.Color.White;
            this.LV.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.LV.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.LV.Location = new System.Drawing.Point(0, 0);
            this.LV.Name = "LV";
            this.LV.Size = new System.Drawing.Size(292, 266);
            this.LV.TabIndex = 0;
            this.LV.TabStop = false;
            // 
            // LayPreview
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(292, 266);
            this.Controls.Add(this.LV);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "LayPreview";
            this.Text = "Previewer";
            ((System.ComponentModel.ISupportInitialize)(this.LV)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.PictureBox LV;

    }
}