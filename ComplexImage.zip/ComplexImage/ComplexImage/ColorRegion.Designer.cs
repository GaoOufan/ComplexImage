﻿namespace ComplexImage
{
    partial class ColorRegion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ColorRegion));
            this.label11 = new System.Windows.Forms.Label();
            this.RegLayN = new System.Windows.Forms.TextBox();
            this.RegLay = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.DstLay = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.OK = new System.Windows.Forms.Button();
            this.NO = new System.Windows.Forms.Button();
            this.RR = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.RM = new System.Windows.Forms.RadioButton();
            this.RE = new System.Windows.Forms.RadioButton();
            this.RH = new System.Windows.Forms.RadioButton();
            this.RS = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(151, 48);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(71, 12);
            this.label11.TabIndex = 32;
            this.label11.Text = "Layer name:";
            // 
            // RegLayN
            // 
            this.RegLayN.Location = new System.Drawing.Point(151, 63);
            this.RegLayN.MaxLength = 32;
            this.RegLayN.Name = "RegLayN";
            this.RegLayN.Size = new System.Drawing.Size(166, 21);
            this.RegLayN.TabIndex = 31;
            // 
            // RegLay
            // 
            this.RegLay.AllowDrop = true;
            this.RegLay.BackColor = System.Drawing.Color.White;
            this.RegLay.ForeColor = System.Drawing.Color.OrangeRed;
            this.RegLay.Location = new System.Drawing.Point(4, 63);
            this.RegLay.MaxLength = 32;
            this.RegLay.Name = "RegLay";
            this.RegLay.ReadOnly = true;
            this.RegLay.Size = new System.Drawing.Size(141, 21);
            this.RegLay.TabIndex = 30;
            this.RegLay.Text = "<Drop image file here>";
            this.RegLay.DragDrop += new System.Windows.Forms.DragEventHandler(this.RegLay_DragDrop);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(2, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(143, 12);
            this.label2.TabIndex = 29;
            this.label2.Text = "Regional dividor layer:";
            // 
            // DstLay
            // 
            this.DstLay.Location = new System.Drawing.Point(4, 24);
            this.DstLay.MaxLength = 32;
            this.DstLay.Name = "DstLay";
            this.DstLay.Size = new System.Drawing.Size(313, 21);
            this.DstLay.TabIndex = 28;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(2, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(143, 12);
            this.label1.TabIndex = 27;
            this.label1.Text = "Destination layer name:";
            // 
            // OK
            // 
            this.OK.Location = new System.Drawing.Point(178, 154);
            this.OK.Name = "OK";
            this.OK.Size = new System.Drawing.Size(139, 28);
            this.OK.TabIndex = 34;
            this.OK.Text = "OK";
            this.OK.UseVisualStyleBackColor = true;
            this.OK.Click += new System.EventHandler(this.OK_Click);
            // 
            // NO
            // 
            this.NO.Location = new System.Drawing.Point(178, 188);
            this.NO.Name = "NO";
            this.NO.Size = new System.Drawing.Size(139, 28);
            this.NO.TabIndex = 33;
            this.NO.Text = "Cancel";
            this.NO.UseVisualStyleBackColor = true;
            this.NO.Click += new System.EventHandler(this.NO_Click);
            // 
            // RR
            // 
            this.RR.AutoSize = true;
            this.RR.Checked = true;
            this.RR.Location = new System.Drawing.Point(4, 112);
            this.RR.Name = "RR";
            this.RR.Size = new System.Drawing.Size(131, 16);
            this.RR.TabIndex = 35;
            this.RR.TabStop = true;
            this.RR.Text = "27 regions (3x3x3)";
            this.RR.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(2, 97);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(185, 12);
            this.label3.TabIndex = 36;
            this.label3.Text = "Regional division palette type";
            // 
            // RM
            // 
            this.RM.AutoSize = true;
            this.RM.Location = new System.Drawing.Point(4, 134);
            this.RM.Name = "RM";
            this.RM.Size = new System.Drawing.Size(131, 16);
            this.RM.TabIndex = 37;
            this.RM.Text = "64 regions (4x4x4)";
            this.RM.UseVisualStyleBackColor = true;
            // 
            // RE
            // 
            this.RE.AutoSize = true;
            this.RE.Location = new System.Drawing.Point(4, 156);
            this.RE.Name = "RE";
            this.RE.Size = new System.Drawing.Size(137, 16);
            this.RE.TabIndex = 38;
            this.RE.Text = "125 regions (5x5x5)";
            this.RE.UseVisualStyleBackColor = true;
            // 
            // RH
            // 
            this.RH.AutoSize = true;
            this.RH.Location = new System.Drawing.Point(4, 178);
            this.RH.Name = "RH";
            this.RH.Size = new System.Drawing.Size(137, 16);
            this.RH.TabIndex = 39;
            this.RH.Text = "216 regions (6x6x6)";
            this.RH.UseVisualStyleBackColor = true;
            // 
            // RS
            // 
            this.RS.AutoSize = true;
            this.RS.Location = new System.Drawing.Point(4, 200);
            this.RS.Name = "RS";
            this.RS.Size = new System.Drawing.Size(137, 16);
            this.RS.TabIndex = 40;
            this.RS.Text = "729 regions (9x9x9)";
            this.RS.UseVisualStyleBackColor = true;
            // 
            // ColorRegion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(326, 214);
            this.Controls.Add(this.RS);
            this.Controls.Add(this.RH);
            this.Controls.Add(this.RE);
            this.Controls.Add(this.RM);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.RR);
            this.Controls.Add(this.OK);
            this.Controls.Add(this.NO);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.RegLayN);
            this.Controls.Add(this.RegLay);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.DstLay);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(334, 249);
            this.MinimumSize = new System.Drawing.Size(334, 249);
            this.Name = "ColorRegion";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Color Region dividor";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox RegLayN;
        private System.Windows.Forms.TextBox RegLay;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox DstLay;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button OK;
        private System.Windows.Forms.Button NO;
        private System.Windows.Forms.RadioButton RR;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton RM;
        private System.Windows.Forms.RadioButton RE;
        private System.Windows.Forms.RadioButton RH;
        private System.Windows.Forms.RadioButton RS;
    }
}