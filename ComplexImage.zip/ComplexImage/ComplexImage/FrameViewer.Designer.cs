﻿namespace ComplexImage
{
    partial class FrameViewer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrameViewer));
            this.FF = new System.Windows.Forms.PictureBox();
            this.OK = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.All = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.FF)).BeginInit();
            this.SuspendLayout();
            // 
            // FF
            // 
            this.FF.BackColor = System.Drawing.Color.White;
            this.FF.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.FF.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FF.Location = new System.Drawing.Point(0, 0);
            this.FF.Name = "FF";
            this.FF.Size = new System.Drawing.Size(349, 271);
            this.FF.TabIndex = 0;
            this.FF.TabStop = false;
            this.FF.MouseClick += new System.Windows.Forms.MouseEventHandler(this.FF_MouseClick);
            // 
            // OK
            // 
            this.OK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.OK.Location = new System.Drawing.Point(328, 250);
            this.OK.Name = "OK";
            this.OK.Size = new System.Drawing.Size(21, 21);
            this.OK.TabIndex = 1;
            this.OK.Text = "X";
            this.OK.UseVisualStyleBackColor = true;
            this.OK.Click += new System.EventHandler(this.OK_Click);
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button1.Location = new System.Drawing.Point(0, 250);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(62, 21);
            this.button1.TabIndex = 2;
            this.button1.Text = "No color";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // All
            // 
            this.All.Location = new System.Drawing.Point(0, 0);
            this.All.Name = "All";
            this.All.Size = new System.Drawing.Size(62, 21);
            this.All.TabIndex = 3;
            this.All.Text = "For all";
            this.All.UseVisualStyleBackColor = true;
            this.All.Click += new System.EventHandler(this.All_Click);
            // 
            // FrameViewer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(349, 271);
            this.ControlBox = false;
            this.Controls.Add(this.All);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.OK);
            this.Controls.Add(this.FF);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrameViewer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Frame index: XXX, Transparent color: 255,255,255";
            this.Load += new System.EventHandler(this.FrameViewer_Load);
            ((System.ComponentModel.ISupportInitialize)(this.FF)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.PictureBox FF;
        private System.Windows.Forms.Button OK;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button All;

    }
}