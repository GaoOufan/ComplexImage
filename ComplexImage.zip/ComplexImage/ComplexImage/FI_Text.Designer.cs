﻿namespace ComplexImage
{
    partial class FI_Text
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FI_Text));
            this.label1 = new System.Windows.Forms.Label();
            this.TX = new System.Windows.Forms.TextBox();
            this.fontDialog1 = new System.Windows.Forms.FontDialog();
            this.FF = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.FS = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.FM = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.OK = new System.Windows.Forms.Button();
            this.Cancel = new System.Windows.Forms.Button();
            this.FNT = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Text string:";
            // 
            // TX
            // 
            this.TX.Location = new System.Drawing.Point(89, 6);
            this.TX.MaxLength = 500;
            this.TX.Name = "TX";
            this.TX.Size = new System.Drawing.Size(446, 22);
            this.TX.TabIndex = 1;
            // 
            // fontDialog1
            // 
            this.fontDialog1.FontMustExist = true;
            // 
            // FF
            // 
            this.FF.BackColor = System.Drawing.Color.Tan;
            this.FF.ForeColor = System.Drawing.Color.SaddleBrown;
            this.FF.Location = new System.Drawing.Point(92, 32);
            this.FF.MaxLength = 32;
            this.FF.Name = "FF";
            this.FF.ReadOnly = true;
            this.FF.Size = new System.Drawing.Size(266, 22);
            this.FF.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Font family:";
            // 
            // FS
            // 
            this.FS.BackColor = System.Drawing.Color.Tan;
            this.FS.ForeColor = System.Drawing.Color.SaddleBrown;
            this.FS.Location = new System.Drawing.Point(400, 32);
            this.FS.MaxLength = 4;
            this.FS.Name = "FS";
            this.FS.ReadOnly = true;
            this.FS.Size = new System.Drawing.Size(42, 22);
            this.FS.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(364, 35);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "Size:";
            // 
            // FM
            // 
            this.FM.BackColor = System.Drawing.Color.Tan;
            this.FM.ForeColor = System.Drawing.Color.SaddleBrown;
            this.FM.Location = new System.Drawing.Point(487, 32);
            this.FM.MaxLength = 4;
            this.FM.Name = "FM";
            this.FM.ReadOnly = true;
            this.FM.Size = new System.Drawing.Size(48, 22);
            this.FM.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(448, 35);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 16);
            this.label4.TabIndex = 6;
            this.label4.Text = "Style:";
            // 
            // OK
            // 
            this.OK.Location = new System.Drawing.Point(12, 58);
            this.OK.Name = "OK";
            this.OK.Size = new System.Drawing.Size(97, 27);
            this.OK.TabIndex = 8;
            this.OK.Text = "OK";
            this.OK.UseVisualStyleBackColor = true;
            this.OK.Click += new System.EventHandler(this.OK_Click);
            // 
            // Cancel
            // 
            this.Cancel.Location = new System.Drawing.Point(438, 58);
            this.Cancel.Name = "Cancel";
            this.Cancel.Size = new System.Drawing.Size(97, 27);
            this.Cancel.TabIndex = 9;
            this.Cancel.Text = "Cancel";
            this.Cancel.UseVisualStyleBackColor = true;
            this.Cancel.Click += new System.EventHandler(this.Cancel_Click);
            // 
            // FNT
            // 
            this.FNT.Location = new System.Drawing.Point(224, 58);
            this.FNT.Name = "FNT";
            this.FNT.Size = new System.Drawing.Size(97, 27);
            this.FNT.TabIndex = 10;
            this.FNT.Text = "Font...";
            this.FNT.UseVisualStyleBackColor = true;
            this.FNT.Click += new System.EventHandler(this.FNT_Click);
            // 
            // FI_Text
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(546, 97);
            this.ControlBox = false;
            this.Controls.Add(this.FNT);
            this.Controls.Add(this.Cancel);
            this.Controls.Add(this.OK);
            this.Controls.Add(this.FM);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.FS);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.FF);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.TX);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FI_Text";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Insert text";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.TextBox TX;
        private System.Windows.Forms.FontDialog fontDialog1;
        public System.Windows.Forms.TextBox FF;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.TextBox FS;
        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.TextBox FM;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button OK;
        private System.Windows.Forms.Button Cancel;
        private System.Windows.Forms.Button FNT;
    }
}