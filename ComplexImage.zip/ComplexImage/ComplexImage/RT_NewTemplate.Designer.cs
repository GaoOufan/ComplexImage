﻿namespace ComplexImage
{
    partial class RT_NewTemplate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RT_NewTemplate));
            this.ImgTag = new System.Windows.Forms.PictureBox();
            this.Quit = new System.Windows.Forms.Button();
            this.Reg = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.TName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.TGroup = new System.Windows.Forms.ComboBox();
            this.TCode = new System.Windows.Forms.RichTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.LoadCode = new System.Windows.Forms.Button();
            this.CodeFromFile = new System.Windows.Forms.OpenFileDialog();
            this.IconLoader = new System.Windows.Forms.OpenFileDialog();
            ((System.ComponentModel.ISupportInitialize)(this.ImgTag)).BeginInit();
            this.SuspendLayout();
            // 
            // ImgTag
            // 
            this.ImgTag.BackColor = System.Drawing.Color.White;
            this.ImgTag.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ImgTag.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ImgTag.Location = new System.Drawing.Point(338, 32);
            this.ImgTag.Margin = new System.Windows.Forms.Padding(4);
            this.ImgTag.Name = "ImgTag";
            this.ImgTag.Size = new System.Drawing.Size(123, 123);
            this.ImgTag.TabIndex = 0;
            this.ImgTag.TabStop = false;
            this.ImgTag.Click += new System.EventHandler(this.ImgTag_Click);
            // 
            // Quit
            // 
            this.Quit.Location = new System.Drawing.Point(338, 331);
            this.Quit.Margin = new System.Windows.Forms.Padding(4);
            this.Quit.Name = "Quit";
            this.Quit.Size = new System.Drawing.Size(123, 36);
            this.Quit.TabIndex = 1;
            this.Quit.Text = "Cancel";
            this.Quit.UseVisualStyleBackColor = true;
            this.Quit.Click += new System.EventHandler(this.Quit_Click);
            // 
            // Reg
            // 
            this.Reg.Location = new System.Drawing.Point(338, 286);
            this.Reg.Margin = new System.Windows.Forms.Padding(4);
            this.Reg.Name = "Reg";
            this.Reg.Size = new System.Drawing.Size(123, 36);
            this.Reg.TabIndex = 2;
            this.Reg.Text = "Register";
            this.Reg.UseVisualStyleBackColor = true;
            this.Reg.Click += new System.EventHandler(this.Reg_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(335, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 16);
            this.label1.TabIndex = 3;
            this.label1.Text = "Icon";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 9);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 16);
            this.label2.TabIndex = 4;
            this.label2.Text = "Template name";
            // 
            // TName
            // 
            this.TName.Location = new System.Drawing.Point(16, 32);
            this.TName.MaxLength = 32;
            this.TName.Name = "TName";
            this.TName.Size = new System.Drawing.Size(315, 22);
            this.TName.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 57);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(104, 16);
            this.label3.TabIndex = 6;
            this.label3.Text = "Template group";
            // 
            // TGroup
            // 
            this.TGroup.FormattingEnabled = true;
            this.TGroup.Location = new System.Drawing.Point(16, 76);
            this.TGroup.MaxLength = 32;
            this.TGroup.Name = "TGroup";
            this.TGroup.Size = new System.Drawing.Size(315, 24);
            this.TGroup.TabIndex = 7;
            // 
            // TCode
            // 
            this.TCode.AcceptsTab = true;
            this.TCode.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TCode.Location = new System.Drawing.Point(13, 122);
            this.TCode.MaxLength = 65536;
            this.TCode.Name = "TCode";
            this.TCode.Size = new System.Drawing.Size(318, 245);
            this.TCode.TabIndex = 8;
            this.TCode.Text = "";
            this.TCode.WordWrap = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 103);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 16);
            this.label4.TabIndex = 9;
            this.label4.Text = "Template code";
            // 
            // LoadCode
            // 
            this.LoadCode.Location = new System.Drawing.Point(338, 163);
            this.LoadCode.Margin = new System.Windows.Forms.Padding(4);
            this.LoadCode.Name = "LoadCode";
            this.LoadCode.Size = new System.Drawing.Size(123, 36);
            this.LoadCode.TabIndex = 10;
            this.LoadCode.Text = "From file...";
            this.LoadCode.UseVisualStyleBackColor = true;
            this.LoadCode.Click += new System.EventHandler(this.LoadCode_Click);
            // 
            // CodeFromFile
            // 
            this.CodeFromFile.FileName = "openFileDialog1";
            this.CodeFromFile.Filter = "Complex Image code file|*.ci";
            // 
            // IconLoader
            // 
            this.IconLoader.FileName = "openFileDialog2";
            this.IconLoader.Filter = "Bitmap|*.bmp|Jpeg|*.jpg|Portable network graphics|*.png";
            // 
            // RT_NewTemplate
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(469, 379);
            this.ControlBox = false;
            this.Controls.Add(this.LoadCode);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.TCode);
            this.Controls.Add(this.TGroup);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.TName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Reg);
            this.Controls.Add(this.Quit);
            this.Controls.Add(this.ImgTag);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "RT_NewTemplate";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "RT_NewTemplate";
            ((System.ComponentModel.ISupportInitialize)(this.ImgTag)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Quit;
        private System.Windows.Forms.Button Reg;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.ComboBox TGroup;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button LoadCode;
        private System.Windows.Forms.OpenFileDialog CodeFromFile;
        private System.Windows.Forms.OpenFileDialog IconLoader;
        public System.Windows.Forms.PictureBox ImgTag;
        public System.Windows.Forms.TextBox TName;
        public System.Windows.Forms.RichTextBox TCode;
    }
}