﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace ComplexImage
{
    public partial class RegionOperation : Form
    {
        public RichTextBox rtf = null;

        public RegionOperation()
        {
            InitializeComponent();
        }

        private void OK_Click(object sender, EventArgs e)
        {
            string res = "RegOpr ";
            if (RegLay.Text != "") res = "F " + RegLay.Text + " " + RegLayN.Text + "\n" + res;
            if (RegLayN.Text != "") res += RegLayN.Text;
            else { MessageBox.Show("Region layer is needed!"); return; }




            rtf.SelectedText = res + "\n"; this.Close();
        }

        private void RegLay_DragDrop(object sender, DragEventArgs e)
        {
            object filename = e.Data.GetData("FileDrop");
            if (filename != null)
            {
                var list = filename as string[];
                if (list != null && !string.IsNullOrWhiteSpace(list[0]))
                {
                    RegLay.Text = list[0];
                    RegLayN.Text = Path.GetFileNameWithoutExtension(list[0]);
                }
            }
        }

        private void NO_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
