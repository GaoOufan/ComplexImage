﻿namespace ComplexImage
{
    partial class ErrorReporter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ErrorReporter));
            this.ErrorsList = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CTRLBRK = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.ErrorsList)).BeginInit();
            this.SuspendLayout();
            // 
            // ErrorsList
            // 
            this.ErrorsList.AllowUserToAddRows = false;
            this.ErrorsList.AllowUserToDeleteRows = false;
            this.ErrorsList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.ErrorsList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ErrorsList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ErrorsList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2});
            this.ErrorsList.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.ErrorsList.Location = new System.Drawing.Point(0, 0);
            this.ErrorsList.MultiSelect = false;
            this.ErrorsList.Name = "ErrorsList";
            this.ErrorsList.ReadOnly = true;
            this.ErrorsList.RowHeadersVisible = false;
            this.ErrorsList.RowTemplate.Height = 23;
            this.ErrorsList.Size = new System.Drawing.Size(481, 142);
            this.ErrorsList.TabIndex = 0;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Line";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 80;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Error";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 400;
            // 
            // CTRLBRK
            // 
            this.CTRLBRK.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.CTRLBRK.BackColor = System.Drawing.Color.MistyRose;
            this.CTRLBRK.Font = new System.Drawing.Font("SimSun", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CTRLBRK.ForeColor = System.Drawing.Color.Red;
            this.CTRLBRK.Location = new System.Drawing.Point(0, 148);
            this.CTRLBRK.Name = "CTRLBRK";
            this.CTRLBRK.Size = new System.Drawing.Size(481, 31);
            this.CTRLBRK.TabIndex = 1;
            this.CTRLBRK.Text = "Break off";
            this.CTRLBRK.UseVisualStyleBackColor = false;
            this.CTRLBRK.Click += new System.EventHandler(this.CTRLBRK_Click);
            // 
            // ErrorReporter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(482, 179);
            this.Controls.Add(this.CTRLBRK);
            this.Controls.Add(this.ErrorsList);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ErrorReporter";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Debugger";
            this.Load += new System.EventHandler(this.ErrorReporter_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ErrorsList)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.DataGridView ErrorsList;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.Button CTRLBRK;
    }
}