﻿namespace ComplexImage
{
    partial class Picker
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Picker));
            this.PicBox = new System.Windows.Forms.PictureBox();
            this.PK_Color = new System.Windows.Forms.CheckBox();
            this.PK_Pos = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SelCol = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SelPos = new System.Windows.Forms.Label();
            this.PK_Alpha = new System.Windows.Forms.CheckBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.ColCol = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.MaxCol = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Tol = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.CMD = new System.Windows.Forms.TextBox();
            this.ITRB = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.PicBox)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // PicBox
            // 
            this.PicBox.BackColor = System.Drawing.Color.White;
            this.PicBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.PicBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.PicBox.Location = new System.Drawing.Point(3, 3);
            this.PicBox.Name = "PicBox";
            this.PicBox.Size = new System.Drawing.Size(102, 88);
            this.PicBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.PicBox.TabIndex = 0;
            this.PicBox.TabStop = false;
            this.PicBox.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.PicBox_MouseDoubleClick);
            this.PicBox.MouseDown += new System.Windows.Forms.MouseEventHandler(this.PicBox_MouseDown);
            this.PicBox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.PicBox_MouseMove);
            this.PicBox.MouseUp += new System.Windows.Forms.MouseEventHandler(this.PicBox_MouseUp);
            // 
            // PK_Color
            // 
            this.PK_Color.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.PK_Color.AutoSize = true;
            this.PK_Color.Checked = true;
            this.PK_Color.CheckState = System.Windows.Forms.CheckState.Checked;
            this.PK_Color.Location = new System.Drawing.Point(278, 7);
            this.PK_Color.Name = "PK_Color";
            this.PK_Color.Size = new System.Drawing.Size(84, 16);
            this.PK_Color.TabIndex = 1;
            this.PK_Color.Text = "Pick color";
            this.PK_Color.UseVisualStyleBackColor = true;
            // 
            // PK_Pos
            // 
            this.PK_Pos.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.PK_Pos.AutoSize = true;
            this.PK_Pos.Location = new System.Drawing.Point(278, 50);
            this.PK_Pos.Name = "PK_Pos";
            this.PK_Pos.Size = new System.Drawing.Size(102, 16);
            this.PK_Pos.TabIndex = 1;
            this.PK_Pos.Text = "Pick position";
            this.PK_Pos.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.BackColor = System.Drawing.Color.Yellow;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Font = new System.Drawing.Font("SimSun", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.ForeColor = System.Drawing.Color.OrangeRed;
            this.label1.Location = new System.Drawing.Point(280, 75);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 56);
            this.label1.TabIndex = 4;
            this.label1.Text = "Double click for capturing";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(278, 140);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 5;
            this.label2.Text = "Color:";
            // 
            // SelCol
            // 
            this.SelCol.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.SelCol.BackColor = System.Drawing.Color.White;
            this.SelCol.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SelCol.ForeColor = System.Drawing.Color.Black;
            this.SelCol.Location = new System.Drawing.Point(280, 152);
            this.SelCol.Name = "SelCol";
            this.SelCol.Size = new System.Drawing.Size(126, 19);
            this.SelCol.TabIndex = 6;
            this.SelCol.Text = "255, 255, 255, 255";
            this.SelCol.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(278, 181);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 12);
            this.label4.TabIndex = 7;
            this.label4.Text = "Position:";
            // 
            // SelPos
            // 
            this.SelPos.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.SelPos.BackColor = System.Drawing.Color.White;
            this.SelPos.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SelPos.ForeColor = System.Drawing.Color.Black;
            this.SelPos.Location = new System.Drawing.Point(280, 193);
            this.SelPos.Name = "SelPos";
            this.SelPos.Size = new System.Drawing.Size(126, 19);
            this.SelPos.TabIndex = 8;
            this.SelPos.Text = "0, 0";
            this.SelPos.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PK_Alpha
            // 
            this.PK_Alpha.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.PK_Alpha.AutoSize = true;
            this.PK_Alpha.Checked = true;
            this.PK_Alpha.CheckState = System.Windows.Forms.CheckState.Checked;
            this.PK_Alpha.Location = new System.Drawing.Point(278, 28);
            this.PK_Alpha.Name = "PK_Alpha";
            this.PK_Alpha.Size = new System.Drawing.Size(114, 16);
            this.PK_Alpha.TabIndex = 9;
            this.PK_Alpha.Text = "Including alpha";
            this.PK_Alpha.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.PicBox);
            this.panel1.Location = new System.Drawing.Point(12, 7);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(260, 391);
            this.panel1.TabIndex = 10;
            // 
            // ColCol
            // 
            this.ColCol.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ColCol.BackColor = System.Drawing.SystemColors.Control;
            this.ColCol.Location = new System.Drawing.Point(280, 223);
            this.ColCol.Name = "ColCol";
            this.ColCol.Size = new System.Drawing.Size(126, 38);
            this.ColCol.TabIndex = 11;
            this.ColCol.Text = "Collect colors from region";
            this.ColCol.UseVisualStyleBackColor = false;
            this.ColCol.Click += new System.EventHandler(this.ColCol_Click);
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.Location = new System.Drawing.Point(278, 264);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 26);
            this.label3.TabIndex = 12;
            this.label3.Text = "Max. color count:";
            // 
            // MaxCol
            // 
            this.MaxCol.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.MaxCol.Font = new System.Drawing.Font("SimSun", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.MaxCol.Location = new System.Drawing.Point(367, 269);
            this.MaxCol.MaxLength = 3;
            this.MaxCol.Name = "MaxCol";
            this.MaxCol.Size = new System.Drawing.Size(39, 21);
            this.MaxCol.TabIndex = 13;
            this.MaxCol.Text = "100";
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.Location = new System.Drawing.Point(278, 318);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 26);
            this.label5.TabIndex = 14;
            this.label5.Text = "Tolerance degree:";
            // 
            // Tol
            // 
            this.Tol.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Tol.Font = new System.Drawing.Font("SimSun", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Tol.Location = new System.Drawing.Point(367, 323);
            this.Tol.MaxLength = 2;
            this.Tol.Name = "Tol";
            this.Tol.Size = new System.Drawing.Size(39, 21);
            this.Tol.TabIndex = 15;
            this.Tol.Text = "16";
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 407);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(101, 12);
            this.label6.TabIndex = 16;
            this.label6.Text = "General command:";
            // 
            // CMD
            // 
            this.CMD.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.CMD.Location = new System.Drawing.Point(119, 404);
            this.CMD.Name = "CMD";
            this.CMD.Size = new System.Drawing.Size(287, 21);
            this.CMD.TabIndex = 17;
            // 
            // ITRB
            // 
            this.ITRB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ITRB.Font = new System.Drawing.Font("SimSun", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ITRB.Location = new System.Drawing.Point(367, 296);
            this.ITRB.MaxLength = 4;
            this.ITRB.Name = "ITRB";
            this.ITRB.Size = new System.Drawing.Size(39, 21);
            this.ITRB.TabIndex = 19;
            this.ITRB.Text = "1";
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.Location = new System.Drawing.Point(278, 291);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(79, 26);
            this.label7.TabIndex = 18;
            this.label7.Text = "Iteration start number";
            // 
            // Picker
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(414, 430);
            this.Controls.Add(this.ITRB);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.CMD);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Tol);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.MaxCol);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.ColCol);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.PK_Alpha);
            this.Controls.Add(this.SelPos);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.PK_Color);
            this.Controls.Add(this.SelCol);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.PK_Pos);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(272, 405);
            this.Name = "Picker";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Picker";
            ((System.ComponentModel.ISupportInitialize)(this.PicBox)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox PK_Color;
        private System.Windows.Forms.CheckBox PK_Pos;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label SelCol;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label SelPos;
        public System.Windows.Forms.PictureBox PicBox;
        private System.Windows.Forms.CheckBox PK_Alpha;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button ColCol;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox MaxCol;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox Tol;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox CMD;
        private System.Windows.Forms.TextBox ITRB;
        private System.Windows.Forms.Label label7;
    }
}