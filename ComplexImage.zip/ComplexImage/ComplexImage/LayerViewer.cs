﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Gif.Components;
using System.IO;
using System.Collections;

namespace ComplexImage
{
    public partial class LayerViewer : Form
    {
        public GIFProp gif = null;
        public FrameViewer fv = null;
        public Picker pk = null;
        public RichTextBox brtf;
        public Form1 ffref;
        public LayPreview LV = null;

        public LayerViewer()
        {
            InitializeComponent();
        }

        private void InvSel_Click(object sender, EventArgs e)
        {
            for (int I = 0; I < LayLst.Rows.Count; I++)
                if (LayLst.Rows[I].Selected == true) LayLst.Rows[I].Selected = false;
                else LayLst.Rows[I].Selected = true;
        }

        private void Save_Click(object sender, EventArgs e)
        {
            if(folderBrowserDialog1.ShowDialog()==DialogResult.OK)
                for (int I = 0; I < LayLst.Rows.Count; I++)
                {
                    if (LayLst.Rows[I].Selected == false) continue;
                    Image IMG = (Image)LayLst.Rows[I].Cells[1].Value;
                    IMG.Save(folderBrowserDialog1.SelectedPath + "/" + LayLst.Rows[I].Cells[0].Value.ToString()+".png");
                }
        }

        private void GIF_Click(object sender, EventArgs e)
        {
            if (gif == null || gif.IsDisposed == true) gif = new GIFProp();
            saveFileDialog1.Filter = "GIF image|*.gif";
            if (gif.ShowDialog() == DialogResult.OK)
            {
                if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    AnimatedGifEncoder ani = new AnimatedGifEncoder();
                    ani.Start(saveFileDialog1.FileName);
                    ani.SetDelay(Int32.Parse(gif.Delay.Text));
                    ani.SetFrameRate(float.Parse(gif.Speed.Text));
                    ani.SetQuality(gif.IQual.Value);
                    if (gif.Repeat.Checked == true) ani.SetRepeat(0);
                    else
                    {
                        int R = Int32.Parse(gif.RepeatQTY.Text);
                        if (R == 0) R = -1; ani.SetRepeat(R);
                    }
                    for (int I = 0; I < LayLst.Rows.Count; I++)
                    {
                        Bitmap IMG = (Bitmap)LayLst.Rows[I].Cells[1].Value;
                        ani.SetSize(IMG.Width, IMG.Height);
                        ani.AddFrame(IMG);
                        if (fv == null || fv.IsDisposed == true) fv = new FrameViewer();
                        else if (fv.ALL == false)
                        {
                            fv.FF.BackgroundImage = IMG;
                            fv.Fidx = I; fv.ShowDialog();
                        }
                        if (fv.NoColor == false) ani.SetTransparent(fv.Transparent);
                    }
                    ani.Finish();
                    MessageBox.Show("Operation completed!", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    fv.Dispose();
                }
            }
        }

        private void Blend_Click(object sender, EventArgs e)
        {
            //
        }

        private void ShiftUp_Click(object sender, EventArgs e)
        {
            if (LayLst.SelectedRows.Count == 0) return; 
            for (int i = 0; i < LayLst.SelectedRows.Count; i++)
            {
                var RI = LayLst.SelectedRows[i];
                if (RI.Index > 0)
                {
                    int A = RI.Index;
                    LayLst.Rows.Remove(RI);
                    LayLst.Rows.Insert(A - 1, RI);
                    RI.Selected = true;
                }
            }
        }

        private void ShiftDown_Click(object sender, EventArgs e)
        {
            if (LayLst.SelectedRows.Count == 0) return;
            for (int i = 0; i < LayLst.SelectedRows.Count; i++)
            {
                var RI = LayLst.SelectedRows[i];
                if (RI.Index < LayLst.Rows.Count - 1)
                {
                    int A = RI.Index;
                    LayLst.Rows.Remove(RI);
                    LayLst.Rows.Insert(A + 1, RI);
                    RI.Selected = true;
                }
            }
        }

        private void Pick_Click(object sender, EventArgs e)
        {
            if (LayLst.SelectedRows.Count == 0)
            {
                MessageBox.Show("No layer been selected!", "Error", MessageBoxButtons.OK); return;
            }
            if (pk != null && pk.IsDisposed == false) pk.Close();
            pk = new Picker();
            pk.PicBox.Image = (Image)LayLst.SelectedRows[0].Cells[1].Value;
            pk.brtf = brtf; pk.ffref = ffref;
            pk.Text = LayLst.SelectedRows[0].Cells[0].Value.ToString();
            pk.Show();
        }

        private void LayerViewer_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (pk != null && pk.IsDisposed == false) pk.Close();
        }

        private void VW_Click(object sender, EventArgs e)
        {
            if (LayLst.SelectedRows.Count == 0)
            {
                MessageBox.Show("No layer been selected!", "Error", MessageBoxButtons.OK); return;
            }
            if (LV == null || LV.IsDisposed == true) { LV = new LayPreview(); LV.Show(); }
            else LV.Focus();
            LV.LV.BackgroundImage = (Image)LayLst.SelectedRows[0].Cells[1].Value;
            LV.Text = LayLst.SelectedRows[0].Cells[0].Value.ToString();
        }

        private void ICO_Click(object sender, EventArgs e)
        {
            // Shall pick selected layer and automatically create icon based on *.ico file format in: http://www.daubnet.com/en/file-format-ico and existing icon file for reference. 

            if (LayLst.SelectedRows.Count == 0) return;
            if (SICO.ShowDialog() != DialogResult.OK) return;

            Bitmap SRC = (Bitmap)LayLst.SelectedRows[0].Cells[1].Value;
            FileStream FS = new FileStream(SICO.FileName, FileMode.Create);
            BinaryWriter BW = new BinaryWriter(FS);

            // 开头：
            BW.Write((short)0);
            BW.Write((short)1);
            BW.Write((short)1);

            // 尺寸：
            int X=SRC.Width, Y=SRC.Height;
            if (X > Y) X = (X < 24) ? 16 : ((X < 48) ? 32 : 64);
            else X = (Y < 24) ? 16 : ((Y < 48) ? 32 : 64);
            SRC = new Bitmap(SRC, new Size(X, X));
            BW.Write((byte)X);
            BW.Write((byte)X);

            // 颜色表：
            Hashtable CI = new Hashtable();
            int CC = 256;

            for(int y=0 ; y<SRC.Height ; y++)
                for (int x = 0; x < SRC.Width; x++)
                {
                    Color C=SRC.GetPixel(x, y);
                    if (CI.ContainsKey(C.ToString()) == false) CI.Add(C.ToString(), C);
                }
            if (CI.Keys.Count < 16) { CC = 16; BW.Write((byte)16); }
            else if (CI.Keys.Count < 256) BW.Write((byte)0);
            else
            {
                BW.Write((byte)0);
                CI.Clear();
                for(int y=0 ; y<SRC.Height ; y++)
                    for (int x = 0; x < SRC.Width; x++)
                    {
                        Color C = SRC.GetPixel(x, y);
                        C = Color.FromArgb(C.R / 16, C.G / 16, C.B / 16);
                        C = Color.FromArgb(C.R * 16, C.G * 16, C.B * 16);
                        SRC.SetPixel(x, y, C);
                        if (CI.ContainsKey(C.ToString()) == false) CI.Add(C.ToString(), C);
                    }
                if (CI.Keys.Count > 255)
                {
                    // 试试再减少
                }
            }
            BW.Write((byte)0);
            BW.Write((short)1);
            BW.Write((short)0); // 多少bit/点 - ((CC == 16) ? 4 : 8)

            if (CC == 16) BW.Write((int)(40+(4*CC)+(X * X / 2) + (X * X / 8)));
            else BW.Write((int)(40 + (4 * CC) + X * X + (X * X / 8)));
            BW.Write((int)22);

            // 图片开头：
            BW.Write((int)40);
            BW.Write((int)X);
            BW.Write((int)(2 * X));
            BW.Write((short)1);
            BW.Write((short)((CC == 16) ? 4 : 8));
            BW.Write((int)0);
            BW.Write((int)((CC == 16) ? (X * X / 2) + (X * X / 8) : X * X + (X * X / 8))); // 大小 = 0 意思没有压缩
            BW.Write((int)0);
            BW.Write((int)0);
            BW.Write((int)0);
            BW.Write((int)0);

            // 色板
            List<Color> r = new List<Color>();
            foreach (DictionaryEntry C in CI) r.Add((Color)C.Value);
            for(int i=0 ; i<CC ; i++)
            {
                if (i >= CI.Keys.Count) { r.Add(Color.Black); BW.Write((int)0); continue; }
                BW.Write(r[i].B);
                BW.Write(r[i].G);
                BW.Write(r[i].R);
                BW.Write((byte)0);
            }

            // 图片内容：
            for (int y = X - 1; y >= 0; y--)
                for (int x = 0; x < X; x++)
                {
                    byte V = 0;
                    Color C = SRC.GetPixel(x, y);
                    for (int i = 0; i < r.Count; i++) if (r[i].ToString() == C.ToString()) { V = (byte)((CC == 16) ? (i << 4) : i); break; }
                    if (CC == 256) BW.Write(V);
                    else
                    {
                        x++; C = SRC.GetPixel(x, y);
                        for (int i = 0; i < r.Count; i++) if (r[i].ToString() == C.ToString()) { V += (byte)i; break; }
                        BW.Write(V);
                    }
                }

            // 2进制图 - 是不是为了透明???
            for (int y = X - 1; y >= 0; y--)
                for (int x = 0; x < X; x+=8)
                {
                    byte V = 0;
                    for (int j = 0; j < 8; j++)
                        if (SRC.GetPixel(x+j, y).A < 128) V += (byte)(1 << (7 - j));
                    BW.Write((byte)V);
                }

            FS.Close();
            BW.Close();
        }
    }
}
