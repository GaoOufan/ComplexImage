﻿namespace ComplexImage
{
    partial class CodeTemplates
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CodeTemplates));
            this.LSV = new System.Windows.Forms.ListView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.RT_Item = new System.Windows.Forms.ToolStripMenuItem();
            this.RT_I_Reg = new System.Windows.Forms.ToolStripMenuItem();
            this.RT_I_Edt = new System.Windows.Forms.ToolStripMenuItem();
            this.RT_I_Mov = new System.Windows.Forms.ToolStripMenuItem();
            this.RT_TFile = new System.Windows.Forms.ToolStripMenuItem();
            this.RT_T_Import = new System.Windows.Forms.ToolStripMenuItem();
            this.RT_T_Export = new System.Windows.Forms.ToolStripMenuItem();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // LSV
            // 
            this.LSV.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.LSV.Cursor = System.Windows.Forms.Cursors.Hand;
            this.LSV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.LSV.HoverSelection = true;
            this.LSV.LargeImageList = this.imageList1;
            this.LSV.Location = new System.Drawing.Point(0, 24);
            this.LSV.MultiSelect = false;
            this.LSV.Name = "LSV";
            this.LSV.Size = new System.Drawing.Size(488, 287);
            this.LSV.Sorting = System.Windows.Forms.SortOrder.Ascending;
            this.LSV.TabIndex = 0;
            this.LSV.TileSize = new System.Drawing.Size(120, 120);
            this.LSV.UseCompatibleStateImageBehavior = false;
            this.LSV.ItemActivate += new System.EventHandler(this.LSV_ItemActivate);
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(80, 80);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.RT_Item,
            this.RT_TFile});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.menuStrip1.Size = new System.Drawing.Size(488, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // RT_Item
            // 
            this.RT_Item.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.RT_I_Reg,
            this.RT_I_Edt,
            this.RT_I_Mov});
            this.RT_Item.Name = "RT_Item";
            this.RT_Item.Size = new System.Drawing.Size(41, 20);
            this.RT_Item.Text = "Item";
            // 
            // RT_I_Reg
            // 
            this.RT_I_Reg.Name = "RT_I_Reg";
            this.RT_I_Reg.Size = new System.Drawing.Size(160, 22);
            this.RT_I_Reg.Text = "Register new";
            this.RT_I_Reg.Click += new System.EventHandler(this.RT_I_Reg_Click);
            // 
            // RT_I_Edt
            // 
            this.RT_I_Edt.Name = "RT_I_Edt";
            this.RT_I_Edt.Size = new System.Drawing.Size(160, 22);
            this.RT_I_Edt.Text = "Edit properties";
            this.RT_I_Edt.Click += new System.EventHandler(this.RT_I_Edt_Click);
            // 
            // RT_I_Mov
            // 
            this.RT_I_Mov.Name = "RT_I_Mov";
            this.RT_I_Mov.Size = new System.Drawing.Size(160, 22);
            this.RT_I_Mov.Text = "Delete";
            this.RT_I_Mov.Click += new System.EventHandler(this.RT_I_Mov_Click);
            // 
            // RT_TFile
            // 
            this.RT_TFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.RT_T_Import,
            this.RT_T_Export});
            this.RT_TFile.Name = "RT_TFile";
            this.RT_TFile.Size = new System.Drawing.Size(107, 20);
            this.RT_TFile.Text = "Import / Export";
            // 
            // RT_T_Import
            // 
            this.RT_T_Import.Name = "RT_T_Import";
            this.RT_T_Import.Size = new System.Drawing.Size(208, 22);
            this.RT_T_Import.Text = "Import templates file";
            this.RT_T_Import.Click += new System.EventHandler(this.RT_T_Import_Click);
            // 
            // RT_T_Export
            // 
            this.RT_T_Export.Name = "RT_T_Export";
            this.RT_T_Export.Size = new System.Drawing.Size(208, 22);
            this.RT_T_Export.Text = "Export to template file";
            this.RT_T_Export.Click += new System.EventHandler(this.RT_T_Export_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.Filter = "Template installer|*.citf";
            // 
            // CodeTemplates
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(488, 311);
            this.Controls.Add(this.LSV);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "CodeTemplates";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Predefined Templates Selector";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ImageList imageList1;
        public System.Windows.Forms.ListView LSV;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem RT_Item;
        private System.Windows.Forms.ToolStripMenuItem RT_I_Reg;
        private System.Windows.Forms.ToolStripMenuItem RT_I_Edt;
        private System.Windows.Forms.ToolStripMenuItem RT_I_Mov;
        private System.Windows.Forms.ToolStripMenuItem RT_TFile;
        private System.Windows.Forms.ToolStripMenuItem RT_T_Import;
        private System.Windows.Forms.ToolStripMenuItem RT_T_Export;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;


    }
}