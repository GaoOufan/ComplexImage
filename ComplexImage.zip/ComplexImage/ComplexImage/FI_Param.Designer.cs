﻿namespace ComplexImage
{
    partial class FI_Param
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FI_Param));
            this.label1 = new System.Windows.Forms.Label();
            this.I_Nam = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.I_Typ = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.I_Val = new System.Windows.Forms.TextBox();
            this.I_ParLst = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OK = new System.Windows.Forms.Button();
            this.Cancel = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.I_ParLst)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name:";
            // 
            // I_Nam
            // 
            this.I_Nam.Location = new System.Drawing.Point(51, 7);
            this.I_Nam.MaxLength = 32;
            this.I_Nam.Name = "I_Nam";
            this.I_Nam.Size = new System.Drawing.Size(224, 21);
            this.I_Nam.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(281, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "Value type:";
            // 
            // I_Typ
            // 
            this.I_Typ.FormattingEnabled = true;
            this.I_Typ.Items.AddRange(new object[] {
            "Numeric",
            "String",
            "Color"});
            this.I_Typ.Location = new System.Drawing.Point(358, 7);
            this.I_Typ.Name = "I_Typ";
            this.I_Typ.Size = new System.Drawing.Size(145, 20);
            this.I_Typ.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 38);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 4;
            this.label3.Text = "Value:";
            // 
            // I_Val
            // 
            this.I_Val.Location = new System.Drawing.Point(57, 35);
            this.I_Val.MaxLength = 256;
            this.I_Val.Name = "I_Val";
            this.I_Val.Size = new System.Drawing.Size(446, 21);
            this.I_Val.TabIndex = 5;
            // 
            // I_ParLst
            // 
            this.I_ParLst.AllowUserToAddRows = false;
            this.I_ParLst.AllowUserToDeleteRows = false;
            this.I_ParLst.AllowUserToResizeRows = false;
            this.I_ParLst.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.I_ParLst.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4});
            this.I_ParLst.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.I_ParLst.Location = new System.Drawing.Point(12, 64);
            this.I_ParLst.Name = "I_ParLst";
            this.I_ParLst.ReadOnly = true;
            this.I_ParLst.RowHeadersVisible = false;
            this.I_ParLst.RowTemplate.Height = 23;
            this.I_ParLst.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.I_ParLst.Size = new System.Drawing.Size(491, 355);
            this.I_ParLst.TabIndex = 6;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Parameter name";
            this.Column1.MaxInputLength = 32;
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 200;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Type";
            this.Column2.MaxInputLength = 4;
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column2.Width = 50;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Init. value:";
            this.Column3.MaxInputLength = 256;
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.Width = 180;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Line";
            this.Column4.MaxInputLength = 5;
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.Width = 40;
            // 
            // OK
            // 
            this.OK.Location = new System.Drawing.Point(12, 426);
            this.OK.Name = "OK";
            this.OK.Size = new System.Drawing.Size(96, 29);
            this.OK.TabIndex = 7;
            this.OK.Text = "OK";
            this.OK.UseVisualStyleBackColor = true;
            this.OK.Click += new System.EventHandler(this.OK_Click);
            // 
            // Cancel
            // 
            this.Cancel.Location = new System.Drawing.Point(407, 426);
            this.Cancel.Name = "Cancel";
            this.Cancel.Size = new System.Drawing.Size(96, 29);
            this.Cancel.TabIndex = 8;
            this.Cancel.Text = "Cancel";
            this.Cancel.UseVisualStyleBackColor = true;
            this.Cancel.Click += new System.EventHandler(this.Cancel_Click);
            // 
            // FI_Param
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(515, 467);
            this.ControlBox = false;
            this.Controls.Add(this.Cancel);
            this.Controls.Add(this.OK);
            this.Controls.Add(this.I_ParLst);
            this.Controls.Add(this.I_Val);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.I_Typ);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.I_Nam);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FI_Param";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "New parameter";
            ((System.ComponentModel.ISupportInitialize)(this.I_ParLst)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.ComboBox I_Typ;
        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.TextBox I_Val;
        public System.Windows.Forms.DataGridView I_ParLst;
        private System.Windows.Forms.Button OK;
        private System.Windows.Forms.Button Cancel;
        public System.Windows.Forms.TextBox I_Nam;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
    }
}