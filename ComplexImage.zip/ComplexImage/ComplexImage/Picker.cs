﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;

namespace ComplexImage
{
    public partial class Picker : Form
    {
        private Bitmap BMP = null;
        public RichTextBox brtf;
        private int RegCut = 0;
        private Graphics GR = null;
        Bitmap ST = null;
        private Point HitPoint = new Point(0,0);
        private Pen QP = null;
        ColorListSelector CMP = null;
        public Form1 ffref;

        public Picker()
        {
            InitializeComponent();
        }

        private void PicBox_MouseMove(object sender, MouseEventArgs e)
        {
            if (PicBox.Image == null || e.X < 0 || e.Y < 0 || e.X >= PicBox.Image.Width || e.Y >= PicBox.Image.Height) return;
            if(BMP==null) BMP = new Bitmap(PicBox.Image);
            SelPos.Text = e.X.ToString()+", "+e.Y.ToString();
            Color C = BMP.GetPixel(e.X,e.Y);
            SelCol.Text = C.A.ToString()+", "+C.R.ToString() + ", " + C.G.ToString() + ", " + C.B.ToString();
            SelCol.BackColor = C;
            SelCol.ForeColor = (((C.R + C.G + C.B) / 3) > 128) ? Color.Black : Color.White;
            if (RegCut == 2)
            {
                if (GR == null)
                {
                    ST = new Bitmap(BMP);
                    GR = Graphics.FromImage(ST);
                    QP = new Pen(Color.Black);
                }
                else
                {
                    GR.DrawImage(BMP, 0, 0);
                    if (QP.Color == Color.Black) QP = new Pen(Color.White);
                    else QP = new Pen(Color.Black);
                }
                GR.DrawRectangle(QP, HitPoint.X, HitPoint.Y, e.X - HitPoint.X, e.Y - HitPoint.Y);
                PicBox.Image = ST;
            }
        }

        private void PicBox_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (RegCut != 0 || PicBox.Image == null) return;
            if (BMP == null) BMP = (Bitmap)PicBox.Image;
            if (PK_Pos.Checked == true)
                if (CMD.Text != "" && CMD.Text.IndexOf("%p") != -1) brtf.SelectedText = CMD.Text.Replace("%p", e.X.ToString() + " " + e.Y.ToString());
                else brtf.SelectedText = "S > " + e.X.ToString() + " " + e.Y.ToString()+"\n";
            if (PK_Color.Checked == true)
            {
                Color C = BMP.GetPixel(e.X, e.Y);
                if (CMD.Text != "")
                {
                    if (CMD.Text.IndexOf("%n") != -1)
                    {
                        try { Int32.Parse(ITRB.Text); }
                        catch { ITRB.Text = "1"; Application.DoEvents(); }
                        brtf.SelectedText = CMD.Text.Replace("%n", ITRB.Text);
                        ITRB.Text = (Int32.Parse(ITRB.Text) + 1).ToString();
                    }
                    if (CMD.Text.IndexOf("%c") != -1) brtf.SelectedText = CMD.Text.Replace("%c", ((PK_Alpha.Checked == true) ? (C.A.ToString() + " ") : "") + C.R.ToString() + " " + C.G.ToString() + " " + C.B.ToString());
                    else CMD.Text += " " + ((PK_Alpha.Checked == true) ? (C.A.ToString() + " ") : "") + C.R.ToString() + " " + C.G.ToString() + " " + C.B.ToString();
                }
                else brtf.SelectedText = ((PK_Alpha.Checked==true) ? (C.A.ToString()+" ") : "")+C.R.ToString() + " " + C.G.ToString() + " " + C.B.ToString();
                ffref.Focus();
            }
        }

        private void ColCol_Click(object sender, EventArgs e)
        {
            if (RegCut == 0)
            {
                PicBox.Cursor = Cursors.Cross;
                ColCol.ForeColor = Color.Green;
                RegCut = 1;
            }
            else
            {
                PicBox.Cursor = Cursors.Default;
                ColCol.ForeColor = Color.Black;
                RegCut = 0;
            }
        }

        void PicBox_MouseUp(object sender, MouseEventArgs e)
        {
            if (RegCut != 2) return;
            this.Cursor = Cursors.WaitCursor; Application.DoEvents();
            Hashtable CT = new Hashtable();
            int T = 16, CMax = 100;
            try { T = Int32.Parse(Tol.Text); }
            catch { Tol.Text = "16"; Application.DoEvents(); }
            try { CMax = Int32.Parse(MaxCol.Text); }
            catch { MaxCol.Text = "100"; Application.DoEvents(); }
            if (CMax < 1) { CMax = 1; MaxCol.Text = "1"; Application.DoEvents(); }
            if (T < 1) { T = 1; Tol.Text = "1"; Application.DoEvents(); }
            for (int Y = HitPoint.Y; Y < e.Y; Y++)
                for (int X = HitPoint.X; X < e.X; X++)
                {
                    Color C = BMP.GetPixel(X, Y);
                    int A = (int)Math.Round((double)C.A / (double)T) * T;
                    int R = (int)Math.Round((double)C.R / (double)T) * T;
                    int G = (int)Math.Round((double)C.G / (double)T) * T;
                    int B = (int)Math.Round((double)C.B / (double)T) * T;
                    if (A > 255) A = 255;
                    if (R > 255) R = 255;
                    if (G > 255) G = 255;
                    if (B > 255) B = 255;
                    string CN = Color.FromArgb(A, R, G, B).Name;
                    if (CT.ContainsKey(CN)) continue;
                    CT.Add(CN, Color.FromArgb(A, R, G, B));
                    if (CT.Count == CMax) goto finish;
                }
        finish: { }
            CMP = new ColorListSelector();
            int EE = 0;
            foreach (DictionaryEntry ET in CT)
            {
                Color C = (Color)ET.Value;
                CMP.ColorList.Rows.Add();
                CMP.ColorList.Rows[EE].Cells[0].Style.BackColor = C;
                CMP.ColorList.Rows[EE].Cells[1].Value = C.A;
                CMP.ColorList.Rows[EE].Cells[2].Value = C.R;
                CMP.ColorList.Rows[EE].Cells[3].Value = C.G;
                CMP.ColorList.Rows[EE].Cells[4].Value = C.B;
                CMP.ColorList.Rows[EE].Selected = true;
                EE++;
            }
            if (CMP.ShowDialog() == DialogResult.Yes)
            {
                string FinStr = "";
                int beg = 1;
                try { beg = Int32.Parse(ITRB.Text); }
                catch { ITRB.Text = "1"; Application.DoEvents(); }
                if (beg < 0) { beg = 0; ITRB.Text = "0"; Application.DoEvents(); }
                for (int i = 0; i < CMP.ColorList.Rows.Count; i++)
                {
                    if (CMP.ColorList.Rows[i].Selected==false) continue;
                    Color C = CMP.ColorList.Rows[i].Cells[0].Style.BackColor;
                    FinStr += CMD.Text.Replace("%n", (i + beg).ToString()).Replace("%c", ((PK_Alpha.Checked == true) ? (C.A + " ") : "") + C.R + " " + C.G + " " + C.B) + "\n";
                }
                brtf.SelectedText = FinStr;
                ITRB.Text = (beg + CMP.ColorList.Rows.Count).ToString();
            }
            CMP.Dispose();
            PicBox.Image = BMP; GR.Dispose(); GR = null; ST.Dispose();
            PicBox.Cursor = Cursors.Default;
            ColCol.ForeColor = Color.Black;
            RegCut = 0;
            this.Cursor = Cursors.Default;
            ffref.Focus();
        }

        void PicBox_MouseDown(object sender, MouseEventArgs e)
        {
            if (RegCut == 0) return;
            RegCut = 2;
            HitPoint = new Point(e.X, e.Y);
        }
    }
}
