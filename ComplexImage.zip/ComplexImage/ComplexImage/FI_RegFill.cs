﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ComplexImage
{
    public partial class FI_RegFill : Form
    {
        public FI_RegFill()
        {
            InitializeComponent();
        }

        private void trackBar1_ValueChanged(object sender, EventArgs e)
        {
            I_Tol.Text = trackBar1.Value.ToString();
        }

        private void OK_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Yes;
        }

        private void Cancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.No;
        }
    }
}
