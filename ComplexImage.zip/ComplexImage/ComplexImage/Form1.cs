﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.IO;
using System.Collections;
using NCalc;
using Gif.Components;

namespace ComplexImage
{
    public partial class Form1 : Form
    {
        Position pos = new Position(0, 0);
        Direction dir = new Direction(0);
        Color color = Color.FromArgb(255, 0, 0, 0);
        Hashtable layer = new Hashtable();
        Graphics GR = null;
        float width = 1;
        string CurrentLayer = "", SavePath = "";
        bool Saved = true, Abort = false;
        Hashtable Loop = new Hashtable();
        LayerViewer LV = null;
        Hashtable WatchPar = null;
        Hashtable CMap = null;
        SystemFontsViewer SFV = null;
        ColorScale CSL = null;
        ColorRegion CRG = null;
        CodeTemplates CTT = null;
        HelpMe hlp = null;
        AboutBox1 abt = new AboutBox1();
        FI_Loop floop = new FI_Loop();
        FI_Cond flcond = new FI_Cond();
        FI_JumpTo fljump = new FI_JumpTo();
        FI_Param flparam = new FI_Param();
        FI_ParSel flparem = new FI_ParSel();
        FI_LayerInfo flay = new FI_LayerInfo();
        FI_Draw fldraw = new FI_Draw();
        FI_Text fltext = new FI_Text();
        FI_RegFill flregf = new FI_RegFill();

        public Form1()
        {
            InitializeComponent();
            Prog.AllowDrop = true;
            Prog.DragDrop += new DragEventHandler(Prog_DragDrop);
            FilePanel.AllowDrop = true;
            FilePanel.DragDrop+=new DragEventHandler(FilePanel_DragDrop);
        }

        private void Prog_DragDrop(object sender, DragEventArgs e)
        {
            object filename = e.Data.GetData("FileDrop");
            if (filename != null)
            {
                var list = filename as string[];
                if (list != null && !string.IsNullOrWhiteSpace(list[0]))
                {
                    if (Path.GetExtension(list[0]) != ".ci") { MessageBox.Show("Must be *.ci file to drag here!"); return; }
                    Prog.Clear();
                    Prog.LoadFile(list[0], RichTextBoxStreamType.PlainText);
                    this.Text = Path.GetFileNameWithoutExtension(list[0]);
                    SavePath = list[0]; Saved = true;
                }
            }
        }

        private void Prog_TextChanged(object sender, EventArgs e)
        {
            if (Saved == true) this.Text += " (*)";
            Saved = false;
            STLT.Text = "of " + Prog.Lines.Length.ToString();
            STTS.Text = "Size: " + Prog.Text.Length.ToString();
        }

        private void Prog_MouseMove(object sender, MouseEventArgs e)
        {
            int L = Prog.GetLineFromCharIndex(Prog.GetCharIndexFromPosition(e.Location));
            STLL.Text = "Line: "+L.ToString();
            STCC.Text = "Column: " + (Prog.GetCharIndexFromPosition(e.Location) - Prog.GetFirstCharIndexFromLine(L));
        }

        private void ME_Load_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                if (Saved == false && MessageBox.Show("File not saved! Shall save it now?", "ATTENTION!!!!", MessageBoxButtons.OKCancel) == DialogResult.Yes)
                {
                    ME_Save_Click(null, null);
                }
                SavePath = openFileDialog1.FileName;
                Prog.LoadFile(SavePath,RichTextBoxStreamType.PlainText);
                this.Text = Path.GetFileNameWithoutExtension(SavePath);
                Saved = true;
            }
        }

        private void ME_Save_Click(object sender, EventArgs e)
        {
            if (SavePath == "")
            {
                if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                    SavePath = saveFileDialog1.FileName;
                else return;
            }
            Prog.SaveFile(SavePath,RichTextBoxStreamType.PlainText); Saved = true;
            this.Text = Path.GetFileNameWithoutExtension(SavePath);
        }

        private void ME_MakeIt_Click(object sender, EventArgs e)
        {
            int itr = 0;
            Abort = false;
            if(RunAlrt.Visible==true) return;
            if (HLP.ERR != null) HLP.ERR.Abort = false;
            Watcher.Rows.Clear();
            RunAlrt.Visible = true;
            if (HLP.ERR != null && HLP.ERR.IsDisposed == false) HLP.ERR.ErrorsList.Rows.Clear();
            Application.DoEvents();
            Position pos = new Position(0, 0);
            dir = new Direction(0);
            color = Color.FromArgb(255, 0, 0, 0);
            layer = new Hashtable();
            HLP.par = new Hashtable();
            Loop = new Hashtable();
            WatchPar = new Hashtable();
            CMap = new Hashtable();
            CurrentLayer = "";
            GR = null;
            string[] CMD = Prog.Lines;
            for (int I = 0; I < CMD.Length; I++,itr++)
            {
                if ((itr % 1000) == 0) Application.DoEvents();
                if (Abort == true) break;
                if (this.IsDisposed == true) return;
                if (HLP.ERR != null && HLP.ERR.Abort == true) { RunAlrt.Visible = false; return; }
                HLP.GLine = I;
                string[] Lin = CMD[I].Replace("\t", "").Split(' ');
                try
                {
                    #region Basis
                    if (Lin[0] == "S") // Seek
                    {
                        if (Lin.Length == 2) { pos.x += dir.x * System.Convert.ToDouble(HLP.MT(Lin[1])); pos.y += dir.y * System.Convert.ToDouble(HLP.MT(Lin[1])); }
                        else if (Lin.Length == 3) { pos.x += System.Convert.ToDouble(HLP.MT(Lin[1])); pos.y += System.Convert.ToDouble(HLP.MT(Lin[2])); }
                        else if (Lin.Length == 4 && Lin[1] == ">") { pos.x = System.Convert.ToDouble(HLP.MT(Lin[2])); pos.y = System.Convert.ToDouble(HLP.MT(Lin[3])); }
                        else { HLP.Report(I, "Command parameters count illegal!"); RunAlrt.Visible = false; return; }
                    }
                    else if (Lin[0] == "D") // Line to
                    {
                        if (CurrentLayer == "") { HLP.Report(I, "No layer defined!"); RunAlrt.Visible = false; return; }
                        if (Lin.Length == 2) { GR.DrawLine(new Pen(color,width), pos.ToPoint(), pos.Shift(Lin[1], dir)); }
                        else if (Lin.Length == 3) { GR.DrawLine(new Pen(color,width), pos.ToPoint(), pos.Shift(Lin[1], Lin[2])); }
                        else if (Lin.Length == 4 && Lin[1] == ">") { GR.DrawLine(new Pen(color,width), pos.ToPoint(), pos.Set(Lin[2], Lin[3])); }
                        else { HLP.Report(I, "Command parameters count illegal!"); RunAlrt.Visible = false; return; }
                    }
                    else if (Lin[0] == "R") // rotate
                    {
                        if (Lin.Length != 2) { HLP.Report(I, "Angle is missing!"); RunAlrt.Visible = false; return; }
                        dir.Shift(System.Convert.ToDouble(HLP.MT(Lin[1])));
                    }
                    else if (Lin[0] == "C") // Set color
                    {
                        if (Lin.Length == 5)
                            color = Color.FromArgb(System.Convert.ToInt32(HLP.MT(Lin[1])), System.Convert.ToInt32(HLP.MT(Lin[2])), System.Convert.ToInt32(HLP.MT(Lin[3])), System.Convert.ToInt32(HLP.MT(Lin[4])));
                        else if (Lin.Length == 2)
                        {
                            if (HLP.par.ContainsKey(Lin[1]) == false) { HLP.Report(I, "No such color in memory!"); RunAlrt.Visible = false; return; }
                            if (typeof(Color) == HLP.par[Lin[1]].GetType()) color = (Color)HLP.par[Lin[1]];
                            else
                            {
                                HLP.Report(I, "Parameter does not have a color value!"); RunAlrt.Visible = false; return;
                            }
                        }
                        else
                        {
                            HLP.Report(I, "Color to be A R G B!"); RunAlrt.Visible = false; return;
                        }
                    }
                    else if (Lin[0] == "P") // Set parameter
                    {
                        ARR A = null;
                        if (Lin.Length < 4)
                        {
                            HLP.Report(I, "Parameters shall be: Name, type value"); RunAlrt.Visible = false; return;
                        }
                        if (Lin[2] == "S")
                        {
                            string Res = "";
                            string[] SP = Lin[3].Split('+');
                            for (int kk = 0; kk < SP.Length; kk++)
                                if (SP[kk][0] != '*' || HLP.par.ContainsKey(SP[kk].Substring(1)) == false) Res += SP[kk];
                                else Res += GetRes(HLP.par[SP[kk].Substring(1)]);
                            Lin[3] = Res;
                        }
                        if (Lin[2] == "L")
                        {
                            A = new ARR();
                            for (int i = 3; i < Lin.Length; i++)
                            {
                                try
                                {
                                    double D = double.Parse(Lin[i]);
                                    A.S.Add(D);
                                }
                                catch
                                {
                                    string[] C = Lin[i].Split('.');
                                    if (C.Length != 4) A.S.Add(Lin[i]);
                                    else
                                    {
                                        try
                                        {
                                            Color _C = Color.FromArgb(Byte.Parse(C[0]), Byte.Parse(C[1]), Byte.Parse(C[2]), Byte.Parse(C[3]));
                                            A.S.Add(_C);
                                        }
                                        catch { A.S.Add(Lin[i]); }
                                    }
                                }
                            }
                        }
                        if (HLP.par.ContainsKey(Lin[1]) == true) // 如果内存变量已存在
                            if (Lin[2] == "N") HLP.par[Lin[1]] = HLP.MT(Lin[3]);
                            else if (Lin[2] == "C")
                                HLP.par[Lin[1]] = Color.FromArgb(System.Convert.ToInt32(HLP.MT(Lin[3])), System.Convert.ToInt32(HLP.MT(Lin[4])), System.Convert.ToInt32(HLP.MT(Lin[5])), System.Convert.ToInt32(HLP.MT(Lin[6])));
                            else if (Lin[2] == "S") HLP.par[Lin[1]] = Lin[3];
                            else if (Lin[2] == "L") HLP.par[Lin[1]] = A;
                            else
                            {
                                HLP.Report(I, "Type shall be N = number, C = color, S = string, L = List!");
                                RunAlrt.Visible = false; return;
                            }

                            // 如果内存变量不存在

                        else if (Lin[2] == "N") HLP.par.Add(Lin[1], HLP.MT(Lin[3]));
                        else if (Lin[2] == "C")
                            HLP.par.Add(Lin[1], Color.FromArgb(System.Convert.ToInt32(HLP.MT(Lin[3])), System.Convert.ToInt32(HLP.MT(Lin[4])), System.Convert.ToInt32(HLP.MT(Lin[5])), System.Convert.ToInt32(HLP.MT(Lin[6]))));
                        else if (Lin[2] == "S") HLP.par.Add(Lin[1], Lin[3]);
                        else if (Lin[2] == "L") HLP.par.Add(Lin[1], A);
                        else
                        {
                            HLP.Report(I, "Type shall be N = number, C = color, S = string, L = List!");
                            RunAlrt.Visible = false; return;
                        }
                    }
                    else if (Lin[0] == "PA")
                    {
                        if (Lin.Length < 3)
                        {
                            HLP.Report(I, "Command missing parameters!");
                            RunAlrt.Visible = false; return;
                        }
                        if (HLP.par.ContainsKey(Lin[1]) == false)
                        {
                            HLP.Report(I, "Parameter not exists in mem!");
                            RunAlrt.Visible = false; return;
                        }
                        if (typeof(ARR) != HLP.par[Lin[1]].GetType())
                        {
                            HLP.Report(I, "Parameter is not an array!");
                            RunAlrt.Visible = false; return;
                        }
                        ARR A = (ARR)HLP.par[Lin[1]];
                        try
                        {
                            double.Parse(Lin[2]);
                            A.S.Add(double.Parse(Lin[2]));
                        }
                        catch
                        {
                            string[] X = Lin[2].Split('.');
                            if (X.Length == 4)
                                try
                                {
                                    byte[] C=new byte[4];
                                    for (int i = 0; i < 4; i++) C[i] = Byte.Parse(X[i]);
                                    A.S.Add(Color.FromArgb(C[0], C[1], C[2], C[3]));
                                }
                                catch { A.S.Add(Lin[2]); }
                            else A.S.Add(Lin[2]);
                        }
                    }
                    else if (Lin[0] == "XP") // Remove parameter from mem
                    {
                        if (Lin.Length < 2)
                        {
                            HLP.Report(I, "Missing parameter name!");
                            RunAlrt.Visible = false; return;
                        }
                        if (HLP.par.ContainsKey(Lin[1]) == false)
                        {
                            HLP.Report(I, "Parameter not exists in mem!");
                            RunAlrt.Visible = false; return;
                        }
                        HLP.par.Remove(Lin[1]);
                    }
                    else if (Lin[0] == "[") // for loop
                    {
                        if (Lin.Length != 3)
                        {
                            HLP.Report(I, "Parameters to be: Loop parameter, count");
                            RunAlrt.Visible = false; return;
                        }
                        if (HLP.par.ContainsKey(Lin[1]) == true)
                        {
                            HLP.Report(I, "Already have loop in the same parameter name!");
                            RunAlrt.Visible = false; return;
                        }
                        HLP.par.Add(Lin[1], HLP.MT(Lin[2]));
                        Loop.Add(Lin[1], I);
                    }
                    else if (Lin[0] == "]") // Loop end
                    {
                        if (Lin.Length != 2)
                        {
                            HLP.Report(I, "Missing loop name to end!");
                            RunAlrt.Visible = false; return;
                        }
                        if (HLP.par.ContainsKey(Lin[1]) == false)
                        {
                            HLP.Report(I, "Loop " + Lin[1] + " couldnot be found!");
                            RunAlrt.Visible = false; return;
                        }
                        int V = Convert.ToInt32(HLP.par[Lin[1]]) - 1;
                        if (V > 0) { I = (int)Loop[Lin[1]]; HLP.par[Lin[1]] = V; }
                        else { Loop.Remove(Lin[1]); HLP.par.Remove(Lin[1]); }
                    }
                    else if (Lin[0] == "I") // If statement
                    {
                        if (HLP.Cond(Lin, I) == false)
                            while (I < CMD.Length)
                            {
                                string[] XLin = CMD[I].Replace("\t", "").Split(' ');
                                if (XLin[0] == "E") if (XLin[1] == Lin[1]) break;
                                I++;
                            }
                    }
                    else if (Lin[0] == "->") // Watch!
                    {
                        if (Lin.Length < 2)
                        {
                            HLP.Report(I, "Watch parameter missing!");
                            RunAlrt.Visible = false; return;
                        }
                        if (HLP.par.ContainsKey(Lin[1]) == false)
                        {
                            HLP.Report(I, "Watch parameter not exists in mem!");
                            RunAlrt.Visible = false; return;
                        }
                        try
                        {
                            if (WatchPar.ContainsKey(Lin[1]) == false)
                            {
                                WatchPar.Add(Lin[1], Watcher.Rows.Count);
                                Watcher.Rows.Add(Lin[1], HLP.par[Lin[1]]);
                            }
                            else
                            {
                                Watcher.Rows[(int)WatchPar[Lin[1]]].Cells[1].Value = HLP.par[Lin[1]];
                            }
                        }
                        catch { }
                        Application.DoEvents();
                    }
                    else if (Lin[0] == "J") // Jump!
                    {
                        for (int lix = 0; lix < CMD.Length; lix++)
                            if (CMD[lix].Replace("\t", "") == "L " + Lin[1]) { I = lix; break; }
                    }
                    #endregion
                    #region LayerWork
                    else if (Lin[0] == "F") // Load layer image from file
                    {
                        if (Lin.Length != 3)
                        {
                            HLP.Report(I, "Command parameters count illegal!"); RunAlrt.Visible = false; return;
                        }
                        Lin[1] = Lin[1].Replace("\\_", " ");
                        if (Lin[1].IndexOf('*') == 0) Lin[1] = (string)HLP.par[Lin[1].Substring(1)];
                        if (Lin[2].IndexOf('*') == 0) Lin[2] = (string)HLP.par[Lin[2].Substring(1)];
                        if (Lin[1].IndexOf(".gif") != -1)
                        {
                            GifDecoder GF = new GifDecoder();
                            GF.Read(Lin[1]);
                            int n = GF.GetFrameCount();
                            for (int fr = 0; fr < n; fr++) layer.Add(Lin[2] + fr.ToString(), GF.GetFrame(fr));
                            if (n > 0) CurrentLayer = Lin[2] + "0"; GR = Graphics.FromImage((Image)layer[Lin[2] + "0"]);
                        }
                        else
                        {
                            if (Lin[1][0] == '%')
                                if (SavePath == "") Lin[1] = Path.GetDirectoryName(Application.ExecutablePath) + "\\" + Lin[1].Substring(1);
                                else Lin[1] = Path.GetDirectoryName(SavePath) + "\\" + Lin[1].Substring(1);

                            if (layer.ContainsKey(Lin[2]) == true) layer[Lin[2]] = new Bitmap(Lin[1]);
                            else
                            {
                                try { layer.Add(Lin[2], new Bitmap(Lin[1])); }
                                catch
                                {
                                    HLP.Report(I, "The path " + Lin[1] + " is wrong!"); RunAlrt.Visible = false; return;
                                }
                            }
                            CurrentLayer = Lin[2]; GR = Graphics.FromImage((Image)layer[Lin[2]]);
                        }
                    }
                    else if (Lin[0] == "SL") // Set active layer
                    {
                        if (Lin.Length != 2)
                        {
                            HLP.Report(I, "Command parameters count illegal!"); RunAlrt.Visible = false; return;
                        }
                        if (Lin[1].IndexOf('*') == 0) Lin[1] = (string)HLP.par[Lin[1].Substring(1)];
                        if (layer.ContainsKey(Lin[1]) == false)
                        {
                            HLP.Report(I, "Layer not exists in mem!"); RunAlrt.Visible = false; return;
                        }
                        CurrentLayer = Lin[1]; GR = Graphics.FromImage((Image)layer[Lin[1]]);
                    }
                    else if (Lin[0] == "G") // Get pixel
                    {
                        if (CurrentLayer == "")
                        {
                            HLP.Report(I, "No layer defined! "); RunAlrt.Visible = false; return;
                        }
                        if (Lin.Length != 2)
                        {
                            HLP.Report(I, "Parameter name is missing!"); RunAlrt.Visible = false; return;
                        }
                        try
                        {
                            Bitmap M = (Bitmap)layer[CurrentLayer];
                            if (HLP.par.ContainsKey(Lin[1]) == true) HLP.par[Lin[1]] = M.GetPixel((int)pos.x, (int)pos.y);
                            else HLP.par.Add(Lin[1], M.GetPixel((int)pos.x, (int)pos.y));
                        }
                        catch (Exception EX) { HLP.Report(I, EX.Message); RunAlrt.Visible = false; return; }
                    }
                    else if (Lin[0] == "GR") // Get region of pixels
                    {
                        if (Lin.Length < 4)
                        {
                            HLP.Report(I, "Parameters missing!");
                            RunAlrt.Visible = false; return;
                        }
                        try
                        {
                            int W = System.Convert.ToInt32(HLP.MT(Lin[1])), H =System.Convert.ToInt32(HLP.MT(Lin[2]));
                            Bitmap M = (Bitmap)layer[CurrentLayer];
                            Color[,] CC = new Color[W, H];
                            for (int y = 0; y < H; y++)
                                for (int x = 0; x < W; x++)
                                    CC[x, y] = M.GetPixel((int)pos.x + x, (int)pos.y + y);
                            if (Lin[3][0] == '*') Lin[3] = HLP.par[Lin[3].Substring(1)].ToString();
                            HLP.par[Lin[3]] = CC;
                        }
                        catch (Exception EX) { HLP.Report(I, EX.Message); RunAlrt.Visible = false; return; }
                    }
                    else if (Lin[0] == "PR") // Put region of pixels
                    {
                        if (Lin.Length < 2)
                        {
                            HLP.Report(I, "Parameter name is missing!"); RunAlrt.Visible = false; return;
                        }

                        if (Lin[1][0] == '*')
                        {
                            if (HLP.par.ContainsKey(Lin[1].Substring(1)) == false)
                            {
                                HLP.Report(I, "Parameter not exists in memory!"); RunAlrt.Visible = false; return;
                            }
                            Lin[1] = HLP.par[Lin[1].Substring(1)].ToString();
                        }
                        if (HLP.par.ContainsKey(Lin[1]) == false)
                        {
                            HLP.Report(I, "Parameter not exists in memory!"); RunAlrt.Visible = false; return;
                        }
                        if (typeof(Color[,]) == HLP.par[Lin[1]].GetType())
                        {
                            try
                            {
                                Bitmap M = (Bitmap)layer[CurrentLayer];
                                Color[,] CC = (Color[,])HLP.par[Lin[1]];
                                int H = CC.GetLength(1), W = CC.GetLength(0);
                                for (int y = 0; y < H && y + pos.y < M.Height; y++)
                                {
                                    if (pos.y + y < 0) y = 0 - (int)pos.y;
                                    for (int x = 0; x < W && x + pos.x < M.Width; x++)
                                    {
                                        if (pos.x + x < 0) x = 0 - (int)pos.x;
                                        Color RC = CC[x, y];
                                        if (RC.A < 255)
                                        {
                                            Color CP = M.GetPixel((int)pos.x + x, (int)pos.y + y);
                                            if (Lin.Length > 2 && Lin[2] == "T")
                                                if (CP.R == color.R && CP.G == color.G && CP.B == color.B && CP.A == color.A) continue;
                                            int R = ((RC.R - CP.R) * (RC.A) / 255) + CP.R;
                                            int G = ((RC.G - CP.G) * (RC.A) / 255) + CP.G;
                                            int B = ((RC.B - CP.B) * (RC.A) / 255) + CP.B;
                                            RC = Color.FromArgb(CP.A, (byte)R, (byte)G, (byte)B);
                                        }
                                        if (Lin.Length > 2) { }
                                        M.SetPixel((int)pos.x + x, (int)pos.y + y, RC);
                                    }
                                }
                            }
                            catch (Exception EX) { HLP.Report(I, EX.Message); RunAlrt.Visible = false; return; }
                        }
                        else
                        {
                            HLP.Report(I, "Variable not match operation!"); RunAlrt.Visible = false; return;
                        }
                    }
                    else if (Lin[0] == "NL") // New layer
                    {
                        if (Lin.Length != 4)
                        {
                            HLP.Report(I, "Parameters shall be: Name, W and H"); RunAlrt.Visible = false; return;
                        }
                        if (Lin[1].IndexOf('*') == 0) Lin[1] = (string)HLP.par[Lin[1].Substring(1)];
                        if (layer.ContainsKey(Lin[1]) == true) layer[Lin[1]] = new Bitmap(System.Convert.ToInt32(HLP.MT(Lin[2])), System.Convert.ToInt32(HLP.MT(Lin[3])));
                        else layer.Add(Lin[1], new Bitmap(System.Convert.ToInt32(HLP.MT(Lin[2])), System.Convert.ToInt32(HLP.MT(Lin[3]))));
                        CurrentLayer = Lin[1]; GR = Graphics.FromImage((Image)layer[Lin[1]]);
                    }
                    else if (Lin[0] == "XL")
                    {
                        if (Lin.Length < 2)
                        {
                            HLP.Report(I, "Layer name is missing!"); RunAlrt.Visible = false; return;
                        }
                        if (Lin[1].IndexOf('*') == 0) Lin[1] = (string)HLP.par[Lin[1].Substring(1)];
                        if (layer.ContainsKey(Lin[1]) == false)
                        {
                            HLP.Report(I, "Layer not exists in memory!"); RunAlrt.Visible = false; return;
                        }
                        layer.Remove(Lin[1]);
                    }
                    else if (Lin[0] == "RS") // Resize layer!
                    {
                        if (Lin.Length < 4)
                        {
                            HLP.Report(I, "Missing some parameters in RS command!");
                            RunAlrt.Visible = false; return;
                        }
                        if (CurrentLayer == "")
                        {
                            HLP.Report(I, "No active layer found!");
                            RunAlrt.Visible = false; return;
                        }
                        int W = System.Convert.ToInt32(HLP.MT(Lin[1])), H = System.Convert.ToInt32(HLP.MT(Lin[2]));
                        if (W <= 0 || H <= 0)
                        {
                            HLP.Report(I, "Size parameters are incorrect!");
                            RunAlrt.Visible = false; return;
                        }
                        Bitmap NL = new Bitmap(W, H);
                        Graphics TG = Graphics.FromImage(NL);
                        TG.DrawImage((Bitmap)layer[CurrentLayer], 0, 0, W, H);
                        Color[,] CC = new Color[W, H];
                        for (int y = 0; y < H; y++)
                            for (int x = 0; x < W; x++)
                                CC[x, y] = NL.GetPixel(x, y);
                        HLP.par[Lin[3]] = CC;
                    }
                    else if (Lin[0] == "LW") // Layer width
                    {
                        if (CurrentLayer == "")
                        {
                            HLP.Report(I, "No active layer found!");
                            RunAlrt.Visible = false; return;
                        }
                        if (Lin.Length < 2)
                        {
                            HLP.Report(I, "Missing parameter name to store width!");
                            RunAlrt.Visible = false; return;
                        }
                        HLP.par[Lin[1]] = ((Bitmap)layer[CurrentLayer]).Width;
                    }
                    else if (Lin[0] == "LH") // Layer height
                    {
                        if (CurrentLayer == "")
                        {
                            HLP.Report(I, "No active layer found!");
                            RunAlrt.Visible = false; return;
                        }
                        if (Lin.Length < 2)
                        {
                            HLP.Report(I, "Missing parameter name to store height!");
                            RunAlrt.Visible = false; return;
                        }
                        HLP.par[Lin[1]] = ((Bitmap)layer[CurrentLayer]).Height;
                    }
                    #endregion
                    #region CanvasOp
                    else if (Lin[0] == "SP") // Set pixel
                    {
                        if (CurrentLayer == "")
                        {
                            HLP.Report(I, "No layer defined! "); RunAlrt.Visible = false; return;
                        }
                        if (Lin.Length < 2)
                        {
                            HLP.Report(I, "Missing color parameter or color values!");
                            RunAlrt.Visible = false; return;
                        }
                        Bitmap BM = (Bitmap)layer[CurrentLayer];
                        if (HLP.par.ContainsKey(Lin[1]) == false || typeof(Color) != HLP.par[Lin[1]].GetType())
                        {
                            if (Lin.Length < 5)
                            {
                                HLP.Report(I, "Missing color values - to be A R G B!");
                                RunAlrt.Visible = false; return;
                            }
                            try
                            {
                                BM.SetPixel((int)pos.x, (int)pos.y, Color.FromArgb(System.Convert.ToInt32(HLP.MT(Lin[1])), System.Convert.ToInt32(HLP.MT(Lin[2])), System.Convert.ToInt32(HLP.MT(Lin[3])), System.Convert.ToInt32(HLP.MT(Lin[4]))));
                            }
                            catch (Exception Ex)
                            {
                                HLP.Report(I, Ex.Message);
                                RunAlrt.Visible = false; return;
                            }
                        }
                        else
                        {
                            BM.SetPixel((int)pos.x, (int)pos.y, (Color)HLP.par[Lin[1]]);
                        }
                    }
                    else if (Lin[0] == "BCT") // Bucket fill
                    {
                        if (CurrentLayer == "")
                        {
                            HLP.Report(I, "No layer defined! "); RunAlrt.Visible = false; return;
                        }
                        Bitmap BMP = (Bitmap)layer[CurrentLayer];
                        int Tol = 0;
                        List<Color> Grp = new List<Color>();
                        Grp.Add(BMP.GetPixel((int)pos.x, (int)pos.y));
                        if (Lin.Length > 1) Tol = System.Convert.ToInt32(HLP.MT(Lin[1]));
                        for (int i = 2; i < Lin.Length; i++)
                            if (HLP.par.ContainsKey(Lin[i]) == true && typeof(Color) == HLP.par[Lin[2]].GetType()) Grp.Add((Color)HLP.par[Lin[2]]);
                        List<Point> DB_Pos = new List<Point>();
                        Hashtable DB_XP = new Hashtable();
                        DB_Pos.Add(new Point((int)pos.x, (int)pos.y));
                        DB_XP.Add(pos.x.ToString() + " " + pos.y.ToString(), new Point((int)pos.x, (int)pos.y));
                        while (DB_Pos.Count > 0)
                        {
                            Point E = DB_Pos[0];
                            BMP.SetPixel(E.X, E.Y, color);
                            if (E.X < BMP.Width - 1 && DB_XP.ContainsKey((E.X + 1).ToString() + " " + E.Y.ToString()) == false)
                            {
                                Color c = BMP.GetPixel(E.X + 1, E.Y);
                                if (c.R != color.R || c.G != color.G || c.B != color.B || c.A != color.A)
                                    for (int i = 0; i < Grp.Count; i++)
                                        if (Math.Abs(c.R - Grp[i].R) <= Tol &&
                                            Math.Abs(c.G - Grp[i].G) <= Tol &&
                                            Math.Abs(c.B - Grp[i].B) <= Tol)
                                        {
                                            DB_Pos.Add(new Point(E.X + 1, E.Y));
                                            DB_XP.Add((E.X + 1).ToString() + " " + E.Y.ToString(), new Point(E.X + 1, E.Y));
                                            break;
                                        }
                            }
                            if (E.X > 0 && DB_XP.ContainsKey((E.X - 1).ToString() + " " + E.Y.ToString()) == false)
                            {
                                Color c = BMP.GetPixel(E.X - 1, E.Y);
                                if (c.R != color.R || c.G != color.G || c.B != color.B || c.A != color.A)
                                    for (int i = 0; i < Grp.Count; i++)
                                        if (Math.Abs(c.R - Grp[i].R) <= Tol &&
                                            Math.Abs(c.G - Grp[i].G) <= Tol &&
                                            Math.Abs(c.B - Grp[i].B) <= Tol)
                                        {
                                            DB_Pos.Add(new Point(E.X - 1, E.Y));
                                            DB_XP.Add((E.X - 1).ToString() + " " + E.Y.ToString(), new Point(E.X - 1, E.Y));
                                            break;
                                        }
                            }
                            if (E.Y < BMP.Height - 1 && DB_XP.ContainsKey(E.X.ToString() + " " + (E.Y + 1).ToString()) == false)
                            {
                                Color c = BMP.GetPixel(E.X, E.Y + 1);
                                if (c.R != color.R || c.G != color.G || c.B != color.B || c.A != color.A)
                                    for (int i = 0; i < Grp.Count; i++)
                                        if (Math.Abs(c.R - Grp[i].R) <= Tol &&
                                            Math.Abs(c.G - Grp[i].G) <= Tol &&
                                            Math.Abs(c.B - Grp[i].B) <= Tol)
                                        {
                                            DB_Pos.Add(new Point(E.X, E.Y + 1));
                                            DB_XP.Add(E.X.ToString() + " " + (E.Y + 1).ToString(), new Point(E.X, E.Y + 1));
                                            break;
                                        }
                            }
                            if (E.Y > 0 && DB_XP.ContainsKey(E.X.ToString() + " " + (E.Y - 1).ToString()) == false)
                            {
                                Color c = BMP.GetPixel(E.X, E.Y - 1);
                                if (c.R != color.R || c.G != color.G || c.B != color.B || c.A != color.A)
                                    for (int i = 0; i < Grp.Count; i++)
                                        if (Math.Abs(c.R - Grp[i].R) <= Tol &&
                                            Math.Abs(c.G - Grp[i].G) <= Tol &&
                                            Math.Abs(c.B - Grp[i].B) <= Tol)
                                        {
                                            DB_Pos.Add(new Point(E.X, E.Y - 1));
                                            DB_XP.Add(E.X.ToString() + " " + (E.Y - 1).ToString(), new Point(E.X, E.Y - 1));
                                            break;
                                        }
                            }
                            DB_XP.Remove(E.X.ToString() + " " + E.Y.ToString());
                            DB_Pos.RemoveAt(0);
                        }
                    }
                    else if (Lin[0] == "TX") // Print text
                    {
                        if (Lin.Length < 4)
                        {
                            HLP.Report(I, "Missing some parameters in TX command!");
                            RunAlrt.Visible = false; return;
                        }
                        if (CurrentLayer == "")
                        {
                            HLP.Report(I, "No active layer found!");
                            RunAlrt.Visible = false; return;
                        }
                        FontStyle FS = FontStyle.Regular;
                        if (Lin.Length > 4)
                        {
                            if (Lin[4] == "B") FS = FontStyle.Bold;
                            else if (Lin[4] == "I") FS = FontStyle.Italic;
                            else if (Lin[4] == "X") FS = FontStyle.Strikeout;
                            else if (Lin[4] == "U") FS = FontStyle.Underline;
                        }
                        Font F = new Font(Lin[1].Replace("\\_", " "), float.Parse(Lin[2]), FS);
                        if (Lin[3][0] == ';') Lin[3] = HLP.MT(Lin[3].Substring(1)).ToString();
                        GR.DrawString(Lin[3].Replace("\\_", " "), F, new SolidBrush(color), new PointF((float)pos.x, (float)pos.y));
                    }
                    else if (Lin[0] == "ColorMap") // Color map current layer
                    {
                        ColorMap CM = new ColorMap();
                        CM.Text = CurrentLayer;
                        Bitmap BM = (Bitmap)layer[CurrentLayer];
                        Hashtable CTree = new Hashtable();
                        int CC = 0, MAX = 10000;
                        for (int y = 0; y < BM.Height; y++)
                            for (int x = 0; x < BM.Width; x++)
                            {
                                Color P = BM.GetPixel(x, y);
                                if (CTree.ContainsKey(P.A) == true)
                                    if (((Hashtable)CTree[P.A]).ContainsKey(P.R) == true)
                                        if (((Hashtable)((Hashtable)CTree[P.A])[P.R]).ContainsKey(P.G) == true)
                                            if (((Hashtable)((Hashtable)((Hashtable)CTree[P.A])[P.R])[P.G]).ContainsKey(P.B) == true)
                                                continue;
                                            else
                                            {
                                                ((Hashtable)((Hashtable)((Hashtable)CTree[P.A])[P.R])[P.G]).Add(P.B, P.B);
                                                CC++; if (CC == MAX) goto EXL;
                                            }
                                        else
                                        {
                                            ((Hashtable)((Hashtable)CTree[P.A])[P.R]).Add(P.G, new Hashtable());
                                            ((Hashtable)((Hashtable)((Hashtable)CTree[P.A])[P.R])[P.G]).Add(P.B, P.B);
                                            CC++; if (CC == MAX) goto EXL;
                                        }
                                    else
                                    {
                                        ((Hashtable)CTree[P.A]).Add(P.R, new Hashtable());
                                        ((Hashtable)((Hashtable)CTree[P.A])[P.R]).Add(P.G, new Hashtable());
                                        ((Hashtable)((Hashtable)((Hashtable)CTree[P.A])[P.R])[P.G]).Add(P.B, P.B);
                                        CC++; if (CC == MAX) goto EXL;
                                    }
                                else
                                {
                                    CTree.Add(P.A, new Hashtable());
                                    ((Hashtable)CTree[P.A]).Add(P.R, new Hashtable());
                                    ((Hashtable)((Hashtable)CTree[P.A])[P.R]).Add(P.G, new Hashtable());
                                    ((Hashtable)((Hashtable)((Hashtable)CTree[P.A])[P.R])[P.G]).Add(P.B, P.B);
                                    CC++; if (CC == MAX) goto EXL;
                                }
                            }
                    EXL:
                        foreach (DictionaryEntry A in CTree)
                            foreach (DictionaryEntry R in (Hashtable)A.Value)
                                foreach (DictionaryEntry G in (Hashtable)R.Value)
                                    foreach (DictionaryEntry B in (Hashtable)G.Value)
                                    {
                                        CM.ColorList.Rows.Add("", A.Key, R.Key, G.Key, B.Key);
                                        CM.ColorList.Rows[CM.ColorList.Rows.Count - 1].Cells[0].Style.BackColor = Color.FromArgb((byte)A.Key, (byte)R.Key, (byte)G.Key, (byte)B.Key);
                                    }
                        if (CC == MAX) CM.ColorList.Rows.Add(">>>", "", "", "", "");
                        CMap.Add(CurrentLayer, CM);
                        CM.Show();
                    }
                    else if (Lin[0] == "Rect") // Rectangle
                    {
                        if (Lin.Length < 3) { HLP.Report(I, "Missing parameters!"); RunAlrt.Visible = false; return; }
                        int w = System.Convert.ToInt32(HLP.MT(Lin[1])), h = System.Convert.ToInt32(HLP.MT(Lin[2]));
                        GR.DrawRectangle(new Pen(color, width), (int)pos.x, (int)pos.y, w, h);
                    }
                    else if (Lin[0] == "W") // set pen width
                    {
                        if (Lin.Length < 2) { HLP.Report(I, "Missing parameters!"); RunAlrt.Visible = false; return; }
                        width = System.Convert.ToSingle(HLP.MT(Lin[1]));
                    }
                    else if (Lin[0] == "Arc") // draw arc
                    {
                        if (CurrentLayer == "")
                        {
                            HLP.Report(I, "No active layer found!");
                            RunAlrt.Visible = false; return;
                        }
                        if (Lin.Length < 3) { HLP.Report(I, "Missing parameters!"); RunAlrt.Visible = false; return; }
                        int w = System.Convert.ToInt32(HLP.MT(Lin[1]));
                        int h = System.Convert.ToInt32(HLP.MT(Lin[2]));
                        float a = 0, m = 360;
                        if (Lin.Length == 5)
                        {
                            a = System.Convert.ToSingle(HLP.MT(Lin[3]));
                            m = System.Convert.ToSingle(HLP.MT(Lin[4]));
                        }
                        if (a == 0 && m == 360) GR.DrawEllipse(new Pen(color, width), new Rectangle((int)pos.x, (int)pos.y, w, h));
                        else GR.DrawArc(new Pen(color, width), new Rectangle((int)pos.x, (int)pos.y, w, h), a, m);
                    }
                    else if (Lin[0] == "MR") // Mirror
                    {
                        if (CurrentLayer == "")
                        {
                            HLP.Report(I, "No active layer found!");
                            RunAlrt.Visible = false; return;
                        }
                        if (Lin.Length < 4)
                        {
                            HLP.Report(I, "Missing some parameters in MR command!");
                            RunAlrt.Visible = false; return;
                        }
                        int W, H;
                        try { W = System.Convert.ToInt32(HLP.MT(Lin[1])); H = System.Convert.ToInt32(HLP.MT(Lin[2])); }
                        catch
                        {
                            HLP.Report(I, "Dimensions have wrong value!");
                            RunAlrt.Visible = false; return;
                        }
                        Bitmap Ly = (Bitmap)layer[CurrentLayer];
                        for (int y = 0; y < H; y++)
                            for (int x = 0; x < W; x++)
                            {
                                if (x + pos.x >= Ly.Width || x + pos.x < 0 || y + pos.y >= Ly.Height || y + pos.y < 0) continue;
                                Color C = Ly.GetPixel(x + (int)pos.x, y + (int)pos.y);

                                try
                                {
                                    if (Lin[3].IndexOf("L") != -1)
                                    {
                                        Ly.SetPixel((int)pos.x - x - 1, (int)pos.y + y, C);
                                        if (Lin[3].IndexOf("U") != -1) Ly.SetPixel((int)pos.x - x - 1, (int)pos.y - y - 1, C);
                                        else if (Lin[3].IndexOf("D") != -1) Ly.SetPixel((int)pos.x - x - 1, (int)pos.y + (2 * H) - y - 1, C);
                                    }
                                    else if (Lin[3].IndexOf("R") != -1)
                                    {
                                        Ly.SetPixel((int)pos.x + (2 * W) - x - 1, (int)pos.y + y, C);
                                        if (Lin[3].IndexOf("U") != -1) Ly.SetPixel((int)pos.x + (2 * W) - x - 1, (int)pos.y - y - 1, C);
                                        else if (Lin[3].IndexOf("D") != -1) Ly.SetPixel((int)pos.x + (2 * W) - x - 1, (int)pos.y + (2 * H) - y - 1, C);
                                    }
                                    if (Lin[3].IndexOf("U") != -1) Ly.SetPixel((int)pos.x + x, (int)pos.y - y - 1, C);
                                    else if (Lin[3].IndexOf("D") != -1) Ly.SetPixel((int)pos.x + x, (int)pos.y + (2 * H) - y - 1, C);
                                }
                                catch { }
                            }
                    }
                    else if (Lin[0] == "Rot") // rotate image
                    {
                        if (CurrentLayer == "")
                        {
                            HLP.Report(I, "No active layer found!");
                            RunAlrt.Visible = false; return;
                        }
                        if (Lin.Length < 3)
                        {
                            HLP.Report(I, "Missing some parameters in MR command!");
                            RunAlrt.Visible = false; return;
                        }
                        if (Lin[1][0] == '*')
                        {
                            if (HLP.par.ContainsKey(Lin[1].Substring(1)) == false)
                            {
                                HLP.Report(I, "Given parameter not exists!");
                                RunAlrt.Visible = false; return;
                            }
                            Lin[1] = HLP.par[Lin[1].Substring(1)].ToString();
                        }
                        if (HLP.par.ContainsKey(Lin[1]) == false)
                        {
                            HLP.Report(I, "Given parameter not exists!");
                            RunAlrt.Visible = false; return;
                        }
                        if (typeof(Color[,]) != HLP.par[Lin[1]].GetType())
                        {
                            HLP.Report(I, "Given parameter is not of color matrix type!");
                            RunAlrt.Visible = false; return;
                        }
                        Color[,] C = (Color[,])HLP.par[Lin[1]];
                        int W = C.GetLength(0), H = C.GetLength(1), d, Cx, Cy;
                        try
                        {
                            d = System.Convert.ToInt32(HLP.MT(Lin[2]));
                            if (Lin.Length >= 5) { Cx =System.Convert.ToInt32(HLP.MT(Lin[3])); Cy = System.Convert.ToInt32(HLP.MT(Lin[4])); }
                            else { Cx = (int)pos.x + (W / 2); Cy = (int)pos.y + (H / 2); }
                        }
                        catch
                        {
                            HLP.Report(I, "Dimensions and / or degrees rotation have wrong value!");
                            RunAlrt.Visible = false; return;
                        }
                        Bitmap Ly = (Bitmap)layer[CurrentLayer];

                        // Rotate image vertices:
                        Position[] P = new Position[4];
                        P[0] = new Position(pos.x, pos.y);
                        P[1] = new Position(pos.x + W, pos.y);
                        P[2] = new Position(pos.x + W, pos.y + H);
                        P[3] = new Position(pos.x, pos.y + H);
                        for (int q = 0; q < 4; q++)
                        {
                            double R, D;
                            R = HLP.Len(new Position(Cx, Cy), P[q]);
                            D = HLP.DEG(Math.Acos((P[q].x - Cx) / R));
                            if ((P[q].y - Cy) < 0) D *= -1; D += d;
                            P[q] = new Position(Cx + R * Math.Cos(D * Math.PI / 180), Cy + R * Math.Sin(D * Math.PI / 180));
                        }

                        // Image Mapping - finalizing:
                        int B, M1, M2, E;
                        if (d < 90) { B = 0; E = 2; M1 = 1; M2 = 3; }
                        else if (d < 180) { B = 3; E = 1; M1 = 0; M2 = 2; }
                        else if (d < 270) { B = 2; E = 0; M1 = 3; M2 = 1; }
                        else { B = 1; E = 3; M1 = 2; M2 = 0; }

                        int Lc = (int)(P[E].y - P[B].y);
                        for (int hy = 0; hy < Lc; hy++)
                        {
                            int lb, le;
                            Position uvb, uve;
                            int T1 = (int)(P[M2].y - P[B].y);
                            int T2u = (int)(P[M1].y - P[B].y);
                            int T2d = (int)(P[E].y - P[M1].y);
                            int T3 = (int)(P[E].y - P[M2].y);
                            try
                            {
                                if (hy < T1)
                                {
                                    lb = (int)(P[B].x + hy * (P[M2].x - P[B].x) / T1);
                                    if (B == 0) uvb = new Position(0, ((H - 1) * hy) / T1);
                                    else if (B == 1) uvb = new Position((W - 1) * (T1 - hy) / T1, 0);
                                    else if (B == 2) uvb = new Position(W - 1, ((H - 1) * (T1 - hy)) / T1);
                                    else uvb = new Position((W - 1) * hy / T1, H - 1);
                                }
                                else
                                {
                                    lb = (int)(P[M2].x + (hy - T1) * (P[E].x - P[M2].x) / T3);
                                    if (B == 0) uvb = new Position(((W - 1) * (hy - T1)) / T3, H - 1);
                                    else if (B == 1) uvb = new Position(0, ((H - 1) * (hy - T1)) / T3);
                                    else if (B == 2) uvb = new Position(((W - 1) * (T3 - (hy - T1))) / T3, 0);
                                    else uvb = new Position(W - 1, ((H - 1) * (T3 - (hy - T1))) / T3);
                                }

                                if (hy < T2u)
                                {
                                    le = (int)(P[B].x + hy * (P[M1].x - P[B].x) / T2u);
                                    if (B == 0) uve = new Position((W - 1) * hy / T2u, 0);
                                    else if (B == 1) uve = new Position(W - 1, ((H - 1) * hy) / T2u);
                                    else if (B == 2) uve = new Position((W - 1) * (T2u - hy) / T2u, H - 1);
                                    else uve = new Position(0, (H - 1) * (T2u - hy) / T2u);
                                }
                                else
                                {
                                    le = (int)(P[M1].x + (hy - T2u) * (P[E].x - P[M1].x) / T2d);
                                    if (B == 0) uve = new Position(W - 1, (H - 1) * (hy - T2u) / T2d);
                                    else if (B == 1) uve = new Position((W - 1) * (T2d - (hy - T2u)) / T2d, H - 1);
                                    else if (B == 2) uve = new Position(0, ((H - 1) * (T2d - (hy - T2u))) / T2d);
                                    else uve = new Position((W - 1) * (hy - T2u) / T2d, 0);
                                }
                            }
                            catch { continue; }

                            int ll = le - lb;
                            for (int hx = 0; hx < ll; hx++)
                            {
                                if (lb + hx < 0 || lb + hx >= Ly.Width || (int)P[B].y + hy < 0 || (int)P[B].y + hy >= Ly.Height) continue;
                                try
                                {
                                    Color CC = C[(int)(uvb.x + (uve.x - uvb.x) * hx / ll), (int)(uvb.y + (uve.y - uvb.y) * hx / ll)];
                                    if (Lin.Length == 6 || Lin.Length == 4)
                                    {
                                        string cmd = (Lin.Length == 6) ? Lin[5] : Lin[3];
                                        if (cmd == "T" && CC.R == color.R && CC.G == color.G && CC.B == color.B) continue;
                                    }
                                    Ly.SetPixel(lb + hx, (int)P[B].y + hy, CC);
                                }
                                catch { }
                            }
                        }
                    }
                    else if (Lin[0] == "Curve")
                    {
                        //
                    }
                    #endregion
                    #region Advanced
                    else if (Lin[0] == "S64")
                    {
                        if (CurrentLayer == "")
                        {
                            HLP.Report(I, "No active layer found!");
                            RunAlrt.Visible = false; return;
                        }
                        if (Lin.Length<2)
                        {
                            HLP.Report(I, "No destination path selected!");
                            RunAlrt.Visible = false; return;
                        }
                        Bitmap BMP = (Bitmap)layer[CurrentLayer];
                        string S = "",M="0123456789_abcdefghijklmnopqrstuvwxyz-ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                        int C = 0, Q = 0;
                        Hashtable CI = new Hashtable();
                        for(int y=0,h=1 ; y<BMP.Height ; y++)
                            for (int x = 0; x < BMP.Width; x++,h--)
                            {
                                Color D = BMP.GetPixel(x, y);
                                if (!CI.ContainsKey(D.Name))
                                    if (C < 8) CI.Add(D.Name, C++);
                                    else
                                    {
                                        HLP.Report(I, "Too much colors in image for this operation!");
                                        RunAlrt.Visible = false; return;
                                    }
                                Q += ((h==0)?1:8) * (int)CI[D.Name];
                                if (h == 0) { S += M[Q]; h = 2; Q = 0; }
                            }
                        File.WriteAllText(Lin[1].Replace("\\_", " "), S);
                    }
                    else if (Lin[0] == "ColScl")
                    {
                        if (CurrentLayer == "")
                        {
                            HLP.Report(I, "No active layer found!");
                            RunAlrt.Visible = false; return;
                        }
                        if (Lin.Length < 8)
                        {
                            HLP.Report(I, "Command parameters count illegal!"); RunAlrt.Visible = false; return;
                        }
                        Bitmap CR = (Bitmap)layer[CurrentLayer];
                        Bitmap BL = null;
                        if (Lin[1].IndexOf('*') == 0) Lin[1] = (string)HLP.par[Lin[1].Substring(1)];
                        if (layer.ContainsKey(Lin[1]) == true) layer[Lin[1]] = new Bitmap(CR.Width, CR.Height);
                        else layer.Add(Lin[1], new Bitmap(CR.Width, CR.Height));
                        Bitmap NR = (Bitmap)layer[Lin[1]];
                        if (Lin[2] != "-")
                        {
                            if (layer.ContainsKey(Lin[2]) == false)
                            {
                                HLP.Report(I, "Regional layer not exists!");
                                RunAlrt.Visible = false; return;
                            }
                            BL = (Bitmap)layer[Lin[2]];
                            if (BL.Width != CR.Width || BL.Height != CR.Height)
                            {
                                HLP.Report(I, "Regional layer must be in the same size!");
                                RunAlrt.Visible = false; return;
                            }
                        }
                        double R = 1; if (Lin.Length > 8) R = System.Convert.ToDouble(HLP.MT(Lin[8])); if (R < 0) R = 0;
                        int[] TC = new int[4];
                        for (int i = 0; i < 4; i++)
                        {
                            try { TC[i] = Int32.Parse(Lin[i + 4]); }
                            catch { TC[i] = -1; }
                        }
                        for (int Y = 0; Y < CR.Height; Y++)
                            for (int X = 0; X < CR.Width; X++)
                            {
                                if (BL != null)
                                {
                                    Color PC = BL.GetPixel(X, Y);
                                    if (PC.A == 0 || (PC.R == 255 && PC.G == 255 && PC.B == 255))
                                    {
                                        NR.SetPixel(X, Y, CR.GetPixel(X, Y));
                                        continue;
                                    }
                                }
                                Color PS = CR.GetPixel(X, Y);
                                int[] BC = new int[4];
                                for (int i = 0; i < 4; i++)
                                {
                                    BC[i] = TC[i];
                                    int V = PS.A;
                                    if (i == 1) V = PS.R;
                                    else if (i == 2) V = PS.G;
                                    else if (i == 3) V = PS.B;
                                    if (BC[i] == -1)
                                    {
                                        if (Lin[i + 4] == "X") BC[i] = V;
                                        else if (Lin[i + 4] == "V") BC[i] = 255 - V;
                                        else if (Lin[i + 4] == "R") BC[i] = PS.R;
                                        else if (Lin[i + 4] == "G") BC[i] = PS.G;
                                        else if (Lin[i + 4] == "B") BC[i] = PS.B;
                                        else if (Lin[i + 4] == "A") BC[i] = PS.A;
                                        else if (Lin[i + 4] == "W") BC[i] = (PS.R + PS.G + PS.B) / 3;
                                        else if (Lin[i + 4] == "RG") BC[i] = (PS.R + PS.G) / 2;
                                        else if (Lin[i + 4] == "RB") BC[i] = (PS.R + PS.B) / 2;
                                        else if (Lin[i + 4] == "GB") BC[i] = (PS.G + PS.B) / 2;
                                        else if (Lin[i + 4] == "WA") BC[i] = (PS.R + PS.G + PS.B + PS.A) / 4;
                                        else
                                        {
                                            HLP.Report(I, "Unknown channel value at channel " + i);
                                            RunAlrt.Visible = false; return;
                                        }
                                    }
                                    BC[i] = (int)((double)BC[i] * R);
                                    if (BC[i] < 0) BC[i] = 0;
                                    else if (BC[i] > 255) BC[i] = 255;
                                }

                                int re = (PS.R + PS.G + PS.B) / 3;
                                if (Lin[3].IndexOf("A") != -1) re = (PS.A + PS.R + PS.G + PS.B) / 4;
                                for (int i = 0; i < 4; i++)
                                {
                                    if (i == 0 && Lin[3].IndexOf("A") == -1) i++;
                                    if (Lin[3].IndexOf("R") == -1)
                                        if (Lin[3].IndexOf("0") != -1) BC[i] = (BC[i] * re) / 255;
                                        else if (Lin[3].IndexOf("F") != -1) BC[i] += ((255 - BC[i]) * re) / 255;
                                        else if (Lin[3].IndexOf("H") != -1)
                                            if (re < 128) BC[i] = (BC[i] * re) / 128;
                                            else BC[i] += ((255 - BC[i]) * (re - 128)) / 128;
                                        else
                                        {
                                            HLP.Report(I, "Unknown scaling option!");
                                            RunAlrt.Visible = false; return;
                                        }
                                }
                                NR.SetPixel(X, Y, Color.FromArgb(BC[0], BC[1], BC[2], BC[3]));
                            }
                        CurrentLayer = Lin[1]; GR = Graphics.FromImage((Image)layer[Lin[1]]);
                    }
                    else if (Lin[0] == "ColReg")
                    {
                        if (CurrentLayer == "")
                        {
                            HLP.Report(I, "No active layer found!");
                            RunAlrt.Visible = false; return;
                        }
                        if (Lin.Length < 4)
                        {
                            HLP.Report(I, "Command missing parameters!");
                            RunAlrt.Visible = false; return;
                        }
                        Bitmap CR = (Bitmap)layer[CurrentLayer];
                        Bitmap BL = null;
                        if (layer.ContainsKey(Lin[1]) == true) layer[Lin[1]] = new Bitmap(CR.Width, CR.Height);
                        else layer.Add(Lin[1], new Bitmap(CR.Width, CR.Height));
                        Bitmap NR = (Bitmap)layer[Lin[1]];
                        if (Lin[2] != "-")
                        {
                            if (layer.ContainsKey(Lin[2]) == false)
                            {
                                HLP.Report(I, "Regional layer not exists!");
                                RunAlrt.Visible = false; return;
                            }
                            BL = (Bitmap)layer[Lin[2]];
                            if (BL.Width != CR.Width || BL.Height != CR.Height)
                            {
                                HLP.Report(I, "Regional layer must be in the same size!");
                                RunAlrt.Visible = false; return;
                            }
                        }
                        for (int Y = 0; Y < CR.Height; Y++)
                            for (int X = 0; X < CR.Width; X++)
                            {
                                if (BL != null)
                                {
                                    Color PC = BL.GetPixel(X, Y);
                                    if (PC.R == 255 && PC.G == 255 && PC.B == 255)
                                    {
                                        NR.SetPixel(X, Y, Color.Transparent);
                                        continue;
                                    }
                                }
                                Color PS = CR.GetPixel(X, Y);
                                int[] K = new int[3]; K[0] = PS.R; K[1] = PS.G; K[2] = PS.B;
                                for (int i = 0; i < 3; i++)
                                    if (Lin[3] == "R")
                                        if (K[i] < 85) K[i] = 0;
                                        else if (K[i] < 170) K[i] = 128;
                                        else K[i] = 255;
                                    else if (Lin[3] == "M")
                                        if (K[i] < 64) K[i] = 0;
                                        else if (K[i] < 128) K[i] = 85;
                                        else if (K[i] < 192) K[i] = 170;
                                        else K[i] = 255;
                                    else if (Lin[3] == "E")
                                        if (K[i] < 51) K[i] = 0;
                                        else if (K[i] < 102) K[i] = 64;
                                        else if (K[i] < 153) K[i] = 128;
                                        else if (K[i] < 204) K[i] = 192;
                                        else K[i] = 255;
                                    else if (Lin[3] == "H")
                                        if (K[i] < 42) K[i] = 0;
                                        else if (K[i] < 85) K[i] = 51;
                                        else if (K[i] < 127) K[i] = 102;
                                        else if (K[i] < 170) K[i] = 153;
                                        else if (K[i] < 212) K[i] = 204;
                                        else K[i] = 255;
                                    else if (Lin[3] == "S")
                                        if (K[i] < 28) K[i] = 0;
                                        else if (K[i] < 56) K[i] = 32;
                                        else if (K[i] < 85) K[i] = 64;
                                        else if (K[i] < 113) K[i] = 96;
                                        else if (K[i] < 141) K[i] = 128;
                                        else if (K[i] < 170) K[i] = 160;
                                        else if (K[i] < 198) K[i] = 192;
                                        else if (K[i] < 226) K[i] = 224;
                                        else K[i] = 255;
                                NR.SetPixel(X, Y, Color.FromArgb(255, K[0], K[1], K[2]));
                            }
                        CurrentLayer = Lin[1]; GR = Graphics.FromImage((Image)layer[Lin[1]]);
                    }
                    else if (Lin[0] == "RegOpr")
                    {
                        if (CurrentLayer == "")
                        {
                            HLP.Report(I, "No active layer found!");
                            RunAlrt.Visible = false; return;
                        }
                        if (Lin.Length < 8)
                        {
                            HLP.Report(I, "Command missing parameters!");
                            RunAlrt.Visible = false; return;
                        }
                        Bitmap CR = (Bitmap)layer[CurrentLayer];
                        if (layer.ContainsKey(Lin[1]) == false)
                        {
                            HLP.Report(I, "Regional layer not exists!");
                            RunAlrt.Visible = false; return;
                        }
                        Bitmap BL = (Bitmap)layer[Lin[1]];
                        Color CC = Color.FromArgb(System.Convert.ToInt32(HLP.MT(Lin[2])), System.Convert.ToInt32(HLP.MT(Lin[3])), System.Convert.ToInt32(HLP.MT(Lin[4])), System.Convert.ToInt32(HLP.MT(Lin[5])));
                        for (int Y = 0; Y < CR.Height; Y++)
                            for (int X = 0; X < CR.Width; X++)
                            {
                                // Lin[6] = Based on offset position flag. If 1, then offset is been taken - it helps when there is more than 1 region with the same color. - - - - to be mapped first!

                                Color PS = BL.GetPixel(X, Y);
                                if (PS.A != CC.A || PS.R != CC.R || PS.G != CC.G || PS.B != CC.B) continue;
                                if (Lin[7] == "C") CR.SetPixel(X, Y, color);
                                else
                                {
                                    Color OC = CR.GetPixel(X, Y);
                                    int[] K = new int[4];
                                    K[0] = OC.A; K[1] = OC.R; K[2] = OC.G; K[3] += color.B;
                                    if (Lin[7] == "A") { K[0] += color.A; K[1] += color.R; K[2] += color.G; K[3] += color.B; }
                                    else if (Lin[7] == "S") { K[0] -= color.A; K[1] -= color.R; K[2] -= color.G; K[3] -= color.B; }
                                    else if (Lin[7] == "I") { K[0] = 255 - K[0]; K[1] = 255 - K[1]; K[2] = 255 - K[2]; K[3] = 255 - K[3]; }
                                    for (int q = 0; q < 4; q++) { if (K[q] < 0) K[q] = 0; if (K[q] > 255) K[q] = 255; }
                                    CR.SetPixel(X, Y, Color.FromArgb(K[0], K[1], K[2], K[3]));
                                }
                            }
                    }
                    #endregion
                    #region 3D
                    //
                    #endregion
                }
                catch (Exception Ex) { HLP.Report(I, Ex.Message); RunAlrt.Visible = false; return; }
            }
            if (LV == null || LV.IsDisposed == true) LV = new LayerViewer();
            else LV.LayLst.Rows.Clear();
            foreach (DictionaryEntry k in layer)
            {
                int Idx = LV.LayLst.Rows.Count;
                Bitmap BMP = (Bitmap)k.Value;
                LV.LayLst.Rows.Add();
                LV.LayLst.Rows[Idx].Cells[0].Value = k.Key;
                LV.LayLst.Rows[Idx].Cells[1].Value = k.Value;
                LV.LayLst.Rows[Idx].Cells[2].Value = BMP.Width.ToString() + "," + BMP.Height.ToString();
                if (LV.pk != null && LV.pk.IsDisposed == false && LV.pk.Text == k.Key.ToString())
                    LV.pk.PicBox.Image = (Image)LV.LayLst.Rows[Idx].Cells[1].Value;
                if (LV.LV != null && LV.LV.IsDisposed == false && LV.LV.Text == k.Key.ToString())
                    LV.LV.LV.BackgroundImage = (Image)LV.LayLst.Rows[Idx].Cells[1].Value;
            }
            LV.brtf = Prog; LV.ffref = this;
            LV.Show();
            RunAlrt.Visible = false;
        }

        private string GetRes(object O)
        {
            Type T = O.GetType();
            if (T == typeof(double)) return System.Convert.ToDouble(O).ToString();
            else if (T == typeof(int) || T == typeof(string)) return O.ToString();
            else if (T == typeof(Color))
            {
                Color C = (Color)O;
                return C.A + "." + C.R + "." + C.G + "." + C.B;
            }
            else if (T == typeof(ARR))
            {
                ARR A = (ARR)O; string Res = "";
                foreach (object S in A.S) Res += GetRes(S);
                return Res;
            }
            return "";
        }

        private void ME_Fonts_Click(object sender, EventArgs e)
        {
            if (SFV == null || SFV.IsDisposed == true)
            {
                SFV = new SystemFontsViewer();
                SFV.acref = this;
                SFV.Show();
            }
            else SFV.Focus();
        }

        private void FilePanel_DragDrop(object sender, DragEventArgs e)
        {
             object filename = e.Data.GetData("FileDrop");
                if (filename != null)
                {
                    var list = filename as string[];
                    if (list != null && !string.IsNullOrWhiteSpace(list[0]))
                    {
                        try { Bitmap f = new Bitmap(list[0]); }
                        catch { MessageBox.Show("File must be of Image type!"); return; }
                        Prog.SelectedText = "F " + list[0].Replace(" ", "\\_") + " newlayer\n";
                    }
                }
        }

        private void Prog_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == (Keys.Control | Keys.R))
            {
                e.Handled = true;
                ME_MakeIt_Click(null, null);
            }
            else if (e.KeyData == (Keys.Control | Keys.L))
            {
                e.Handled = true;
                ME_Load_Click(null, null);
            }
            else if (e.KeyData == (Keys.Control | Keys.S))
            {
                e.Handled = true;
                ME_Save_Click(null, null);
            }
            else if (e.KeyData == (Keys.Control | Keys.F))
            {
                e.Handled = true;
                ME_Fonts_Click(null, null);
            }
            else if (e.KeyData == (Keys.Control | Keys.T))
            {
                e.Handled = true;
                ME_Templates_Click(null, null);
            }
            else if (e.KeyCode == Keys.F1)
            {
                ME_IDX_Click(null, null);
            }
        }

        private void ME_SaveAs_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                SavePath = saveFileDialog1.FileName;
                Prog.SaveFile(SavePath,RichTextBoxStreamType.PlainText); Saved = true;
                this.Text = Path.GetFileNameWithoutExtension(SavePath);
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Saved == false && MessageBox.Show("File not saved! Shall save it now?", "ATTENTION!!!!", MessageBoxButtons.OKCancel) == DialogResult.Yes)
            {
                ME_Save_Click(null, null);
            }
        }

        private void ME_Copy_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(Prog.SelectedText);
        }

        private void ME_Cut_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(Prog.SelectedText);
            Prog.SelectedText = "";
        }

        private void ME_Paste_Click(object sender, EventArgs e)
        {
            Prog.SelectedText = Clipboard.GetText();
        }

        private void ME_LoadOld_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                if (Saved == false && MessageBox.Show("File not saved! Shall save it now?", "ATTENTION!!!!", MessageBoxButtons.OKCancel) == DialogResult.Yes)
                {
                    ME_Save_Click(null, null);
                }
                SavePath = openFileDialog1.FileName;
                Prog.LoadFile(SavePath);
                this.Text = Path.GetFileNameWithoutExtension(SavePath);
                Saved = true;
            }
        }

        private void ME_ColScl_Click(object sender, EventArgs e)
        {
            if (CSL == null || CSL.IsDisposed == true) { CSL = new ColorScale(); CSL.rtf = Prog; CSL.Show(); }
            else CSL.Focus();
        }

        private void ME_ColReg_Click(object sender, EventArgs e)
        {
            if (CRG == null || CRG.IsDisposed == true) { CRG = new ColorRegion(); CRG.rtf = Prog; CRG.Show(); }
            else CRG.Focus();
            
        }

        private void ME_Templates_Click(object sender, EventArgs e)
        {
            if (CTT == null || CTT.IsDisposed == true) { CTT = new CodeTemplates(); CTT.rtf = Prog; CTT.Show(); }
            else CTT.Focus();
        }

        private void TB_Loop_Click(object sender, EventArgs e)
        {
            if (floop.ShowDialog() == DialogResult.Yes)
            {
                int L = Prog.GetLineFromCharIndex(Prog.SelectionStart);
                int idt = Prog.SelectionStart - Prog.GetFirstCharIndexFromLine(L);
                string sidt = ""; for (int j = 0; j < idt; j++) sidt += "\t";
                Prog.SelectedText = "[ " + floop.I_Tag.Text + " " + floop.I_QTY.Text + "\n"+sidt+"\t//\n"+sidt+"] " + floop.I_Tag.Text;
            }
        }

        private void TB_Condition_Click(object sender, EventArgs e)
        {
            if (flcond.ShowDialog() == DialogResult.Yes)
            {
                int L = Prog.GetLineFromCharIndex(Prog.SelectionStart);
                int idt = Prog.SelectionStart - Prog.GetFirstCharIndexFromLine(L);
                string sidt = ""; for (int j = 0; j < idt; j++) sidt += "\t";
                Prog.SelectedText = "I " + flcond.I_Tag.Text + " " + flcond.I_Cond.Text + "\n" + sidt + "\t//\n" + sidt + "E " + flcond.I_Tag.Text;
            }
        }

        private void TB_Break_Click(object sender, EventArgs e)
        {
            Hashtable LN = new Hashtable();
            for (int i = 0; i < Prog.Lines.Length && i < Prog.GetLineFromCharIndex(Prog.SelectionStart); i++)
            {
                int fp = Prog.Lines[i].IndexOf("] ");
                if (fp != -1)
                    if (LN.ContainsKey(Prog.Lines[i].Substring(fp + 2)) == false) { 
                        MessageBox.Show("Unrecognized loop end at line "+i.ToString()+"!"); return; 
                    }
                    else LN.Remove(Prog.Lines[i].Substring(fp + 2));
                else
                {
                    fp = Prog.Lines[i].IndexOf("[ ");
                    if (fp == -1) continue;
                    LN.Add(Prog.Lines[i].Substring(fp + 2, Prog.Lines[i].IndexOf(" ", fp + 2) - (fp + 2)), i);
                }
            }
            if (LN.Count==0) { MessageBox.Show("Carret is not in a loop!"); return; }

            int l = -1;
            string r = "";
            foreach (DictionaryEntry d in LN)
                if ((int)d.Value > l) { l = (int)d.Value; r = (string)d.Key; }
            Prog.SelectedText = "X "+r+"\n";
        }

        private void TB_Continue_Click(object sender, EventArgs e)
        {
            Hashtable LN = new Hashtable();
            for (int i = 0; i < Prog.Lines.Length && i < Prog.GetLineFromCharIndex(Prog.SelectionStart); i++)
            {
                int fp = Prog.Lines[i].IndexOf("] ");
                if (fp != -1)
                    if (LN.ContainsKey(Prog.Lines[i].Substring(fp + 2)) == false)
                    {
                        MessageBox.Show("Unrecognized loop end at line " + i.ToString() + "!"); return;
                    }
                    else LN.Remove(Prog.Lines[i].Substring(fp + 2));
                else
                {
                    fp = Prog.Lines[i].IndexOf("[ ");
                    if (fp == -1) continue;
                    LN.Add(Prog.Lines[i].Substring(fp + 2, Prog.Lines[i].IndexOf(" ", fp + 2) - (fp + 2)), i);
                }
            }
            if (LN.Count == 0) { MessageBox.Show("Carret is not in a loop!"); return; }

            int l = -1;
            string r = "";
            foreach (DictionaryEntry d in LN)
                if ((int)d.Value > l) { l = (int)d.Value; r = (string)d.Key; }
            Prog.SelectedText = ">> " + r+"\n";
        }

        private void TB_Label_Click(object sender, EventArgs e)
        {
            Prog.SelectedText = "L LabelName\n";
        }

        private void TB_Jump_Click(object sender, EventArgs e)
        {
            fljump.I_LBL.Items.Clear();
            for (int i = 0; i < Prog.Lines.Length && i < Prog.GetLineFromCharIndex(Prog.SelectionStart); i++)
            {
                string[] CP=Prog.Lines[i].Replace("\t","").Split(' ');
                if (CP.Length > 1 && CP[0] == "L") fljump.I_LBL.Items.Add(CP[1]);
            }
            if (fljump.ShowDialog() == DialogResult.Yes)
                Prog.SelectedText = "J "+fljump.I_LBL.SelectedItem.ToString()+"\n";
        }

        private void TB_Param_Click(object sender, EventArgs e)
        {
            flparam.I_ParLst.Rows.Clear();
            for (int i = 0; i < Prog.Lines.Length && i < Prog.GetLineFromCharIndex(Prog.SelectionStart); i++)
            {
                string[] CP = Prog.Lines[i].Replace("\t", "").Split(' ');
                if (CP[0] == "P" || CP[0]=="[" || CP[0]=="G" || CP[0]=="RS" || CP[0]=="GR" || CP[0]=="LW" || CP[0]=="LH")
                {
                    int k = flparam.I_ParLst.Rows.Count,idx;
                    string pn = CP[1];
                    if (CP[0] == "RS" || CP[0] == "GR") pn = CP[3];
                    for (idx = 0; idx < k; idx++)
                        if (flparam.I_ParLst.Rows[idx].Cells[0].Value.ToString() == pn) break;
                    if(idx==k) flparam.I_ParLst.Rows.Add();
                    flparam.I_ParLst.Rows[idx].Cells[0].Value = pn;
                    if (CP[0] == "P")
                    {
                        flparam.I_ParLst.Rows[idx].Cells[1].Value = CP[2];
                        flparam.I_ParLst.Rows[idx].Cells[2].Value = CP[3];
                        if (CP[2] == "C" && CP.Length>=7)
                            flparam.I_ParLst.Rows[idx].Cells[2].Value += " " + CP[4] + " " + CP[5] + " " + CP[6];
                    }
                    else if(CP[0]=="[")
                    {
                        flparam.I_ParLst.Rows[idx].Cells[1].Value = "Loop";
                        flparam.I_ParLst.Rows[idx].Cells[2].Value = CP[2];
                    }
                    else if (CP[0] == "G")
                    {
                        flparam.I_ParLst.Rows[idx].Cells[1].Value = "C";
                        flparam.I_ParLst.Rows[idx].Cells[2].Value = "<Compile>";
                    }
                    else if (CP[0] == "GR" || CP[0]=="RS")
                    {
                        flparam.I_ParLst.Rows[idx].Cells[1].Value = "C[,]";
                        flparam.I_ParLst.Rows[idx].Cells[2].Value = "<Compile>";
                    }
                    else if (CP[0] == "LH" || CP[0]=="LW")
                    {
                        flparam.I_ParLst.Rows[idx].Cells[1].Value = "N";
                        flparam.I_ParLst.Rows[idx].Cells[2].Value = "<Compile>";
                    }
                    flparam.I_ParLst.Rows[idx].Cells[3].Value = i;
                }
                else if (CP.Length>1 && CP[0] == "XP") {
                    int k = flparam.I_ParLst.Rows.Count, idx;
                    for (idx = 0; idx < k; idx++)
                        if (flparam.I_ParLst.Rows[idx].Cells[0].Value.ToString() == CP[1])
                        {
                            flparam.I_ParLst.Rows.Remove(flparam.I_ParLst.Rows[idx]);
                            break;
                        }
                }
            }
            if (flparam.ShowDialog() == DialogResult.Yes)
                Prog.SelectedText = "P " + flparam.I_Nam.Text+" "+flparam.I_Typ.SelectedItem.ToString().Substring(0,1)+" "+flparam.I_Val.Text + "\n";
        }

        private void TB_RemPar_Click(object sender, EventArgs e)
        {
            flparem.Text = "Select parameter to remove";
            flparem.I_ParLst.Items.Clear();
            for (int i = 0; i < Prog.Lines.Length && i < Prog.GetLineFromCharIndex(Prog.SelectionStart); i++)
            {
                string[] CP = Prog.Lines[i].Replace("\t", "").Split(' ');
                if (CP[0] == "P" || CP[0]=="[" || CP[0]=="G" || CP[0]=="RS" || CP[0]=="GR" || CP[0]=="LW" || CP[0]=="LH")
                {
                    int k = flparem.I_ParLst.Items.Count, idx;
                    string pn = CP[1];
                    if (CP[0] == "RS" || CP[0] == "GR") pn = CP[3];
                    for (idx = 0; idx < k; idx++)
                        if (flparem.I_ParLst.Items[idx].ToString() == pn) break;
                    if (idx == k) flparem.I_ParLst.Items.Add(pn);
                }
                else if (CP.Length>1 && CP[0] == "XP") {
                    int k = flparem.I_ParLst.Items.Count, idx;
                    for (idx = 0; idx < k; idx++)
                        if (flparem.I_ParLst.Items[idx].ToString() == CP[1])
                        {
                            flparem.I_ParLst.Items.RemoveAt(idx);
                            break;
                        }
                }
            }
            if (flparem.ShowDialog() == DialogResult.Yes)
                Prog.SelectedText = "XP " +flparem.I_ParLst.SelectedItem.ToString()+ "\n";
        }

        private void TB_Watch_Click(object sender, EventArgs e)
        {
            flparem.Text = "Select parameter to watch";
            flparem.I_ParLst.Items.Clear();
            for (int i = 0; i < Prog.Lines.Length && i < Prog.GetLineFromCharIndex(Prog.SelectionStart); i++)
            {
                string[] CP = Prog.Lines[i].Replace("\t", "").Split(' ');
                if (CP[0] == "P" || CP[0] == "[" || CP[0] == "G" || CP[0] == "RS" || CP[0] == "GR" || CP[0] == "LW" || CP[0] == "LH")
                {
                    int k = flparem.I_ParLst.Items.Count, idx;
                    string pn = CP[1];
                    if (CP[0] == "RS" || CP[0] == "GR") pn = CP[3];
                    for (idx = 0; idx < k; idx++)
                        if (flparem.I_ParLst.Items[idx].ToString() == pn) break;
                    if (idx == k) flparem.I_ParLst.Items.Add(pn);
                }
                else if (CP.Length > 1 && CP[0] == "XP")
                {
                    int k = flparem.I_ParLst.Items.Count, idx;
                    for (idx = 0; idx < k; idx++)
                        if (flparem.I_ParLst.Items[idx].ToString() == CP[1])
                        {
                            flparem.I_ParLst.Items.RemoveAt(idx);
                            break;
                        }
                }
            }
            if (flparem.ShowDialog() == DialogResult.Yes)
                Prog.SelectedText = "-> " + flparem.I_ParLst.SelectedItem.ToString() + "\n";
        }

        private void TB_InsertLayer_Click(object sender, EventArgs e)
        {
            if (flay.ShowDialog() == DialogResult.Yes)
            {
                if (flay.I_Path.Text == "") Prog.SelectedText = "NL " + flay.I_Nam.Text + " "+flay.I_W.Text + " " + flay.I_H.Text;
                else Prog.SelectedText = "F " + flay.I_Path.Text + " " + flay.I_Nam.Text;
            }
        }

        private void TB_ActiveLayer_Click(object sender, EventArgs e)
        {
            flparem.Text = "Select layer to activate";
            flparem.I_ParLst.Items.Clear();
            for (int i = 0; i < Prog.Lines.Length && i < Prog.GetLineFromCharIndex(Prog.SelectionStart); i++)
            {
                string[] CP = Prog.Lines[i].Replace("\t", "").Split(' ');
                if (CP.Length > 2 && (CP[0] == "F" || CP[0] == "NL" || CP[0]=="ColScl" || CP[0]=="ColReg"))
                {
                    string v = "";
                    if (CP[0] == "NL") v = CP[1];
                    else if (CP[0] == "F") v = CP[2];
                    else if(CP[0]=="ColScl" || CP[0]=="ColReg") v = CP[0];
                    for (int k = 0; k < flparem.I_ParLst.Items.Count; k++)
                        if (flparem.I_ParLst.Items[k].ToString() == v) goto eol;
                    flparem.I_ParLst.Items.Add(v);
                }
                else if (CP.Length > 1 && CP[0] == "XL")
                    for (int k = 0; k < flparem.I_ParLst.Items.Count; k++)
                        if (flparem.I_ParLst.Items[k].ToString() == CP[1])
                        {
                            flparem.I_ParLst.Items.RemoveAt(k);
                            break;
                        }
            eol: { };
            }
            if (flparem.ShowDialog() == DialogResult.Yes)
                Prog.SelectedText = "SL " + flparem.I_ParLst.SelectedItem.ToString() + "\n";
        }

        private void TB_SetColor_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                Prog.SelectedText = "C " + colorDialog1.Color.A.ToString() + " " + colorDialog1.Color.R.ToString() + " " + colorDialog1.Color.G.ToString() + " " + colorDialog1.Color.B.ToString();
            }
        }
        
        private void TB_LineTo_Click(object sender, EventArgs e)
        {
            fldraw.I_Cmd.Items.Clear();
            Size S = new Size(0, 0);
            string C = "";
            for (int i = 0; i < Prog.Lines.Length && i < Prog.GetLineFromCharIndex(Prog.SelectionStart); i++)
            {
                string[] CP = Prog.Lines[i].Replace("\t", "").Split(' ');
                if (CP.Length > 2 && (CP[0]=="SL" || CP[0] == "F" || CP[0] == "NL" || CP[0] == "ColScl" || CP[0] == "ColReg"))
                {
                    if (CP[0] == "SL") C = CP[1];
                    else if (CP[0] == "NL") { C = CP[1]; S = new Size(System.Convert.ToInt32(HLP.MT(CP[2])), System.Convert.ToInt32(HLP.MT(CP[3]))); }
                    else if (CP[0] == "F")
                    {
                        C = CP[2];
                        Bitmap B = new Bitmap(CP[1]);
                        S = B.Size;
                    }
                    else if (CP[0]=="ColScl" || CP[0]=="ColReg") C = CP[1];
                }
                else if (CP.Length > 1 && CP[0] == "XL")
                    if (CP[1] == C) { C = ""; Size = new Size(0,0); }
            }
            if (C == "" || Size.Width==0) { MessageBox.Show("No layer is active in current point!"); return; }
            fldraw.PIC.Image = new Bitmap(S.Width, S.Height);
            if (fldraw.ShowDialog() == DialogResult.Yes)
            {
                int L = Prog.GetLineFromCharIndex(Prog.SelectionStart);
                int idt = Prog.SelectionStart - Prog.GetFirstCharIndexFromLine(L);
                string sidt = "",xx=""; for (int j = 0; j < idt; j++) sidt += "\t";
                for (int i = 0; i < fldraw.I_Cmd.Items.Count; i++)
                    xx += ((i>0)?sidt:"")+fldraw.I_Cmd.Items[i].ToString() + "\n";
                Prog.SelectedText=xx;
            }
        }

        private void TB_RegFill_Click(object sender, EventArgs e)
        {
            if (flregf.ShowDialog() == DialogResult.Yes)
                Prog.SelectedText = "BCT " + flregf.I_Tol.Text + "\n";
        }

        private void TB_Text_Click(object sender, EventArgs e)
        {
            if (fltext.ShowDialog() == DialogResult.Yes)
                Prog.SelectedText = "TX " + fltext.FF.Text + " " + fltext.FS.Text + " " + fltext.TX.Text.Replace(" ", "%_") + " " + fltext.FM.Text + "\n";
        }

        private void TB_GetPixel_Click(object sender, EventArgs e)
        {
            //
        }

        private void TB_SetPixel_Click(object sender, EventArgs e)
        {
            //
        }

        private void TB_PixelRegion_Click(object sender, EventArgs e)
        {
            //
        }

        private void TB_PutPixelRegion_Click(object sender, EventArgs e)
        {
            //
        }

        private void TB_ResizeLayer_Click(object sender, EventArgs e)
        {
            //
        }

        private void TB_UseLayerSize_Click(object sender, EventArgs e)
        {
            //
        }

        private void TB_ColorMap_Click(object sender, EventArgs e)
        {
            //
        }

        private void TB_DelLayer_Click(object sender, EventArgs e)
        {
            //
        }

        private void BRK_Click(object sender, EventArgs e)
        {
            Abort = true;
        }

        private void FilePanel_TextChanged(object sender, EventArgs e)
        {
            FilePanel.Text = "Drag and drop file here";
        }

        private void ME_IDX_Click(object sender, EventArgs e)
        {
            if (hlp == null || hlp.IsDisposed == true) { hlp = new HelpMe(); hlp.Show(); }
            else hlp.Focus();
        }

        private void ME_About_Click(object sender, EventArgs e)
        {
             abt.ShowDialog();
        }

        private void ME_MegPaint_Click(object sender, EventArgs e)
        {
            // Mega paint is a paint program that also allow to use commands. This is a great tool to create fast layers.
            // The commands of that layer with the bitmap layer will be saved in separate table, from the code here will be reference to that layer. 
            // Purpose of saving is for future editing. 
            // When saving to file, the external layers will be saved to the same *.ci file after the main program code, when each begins with a line "~"+layer name.
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] K = Environment.GetCommandLineArgs();
            if (K.Length > 1)
            {
                if (Path.GetExtension(K[1]) != ".ci") { MessageBox.Show("Must be *.ci file!"); return; }
                Prog.Clear();
                Prog.LoadFile(K[1], RichTextBoxStreamType.PlainText);
                this.Text = Path.GetFileNameWithoutExtension(K[1]);
                SavePath = K[1]; Saved = true;
            }
        }
    }

    // Multilingual support: https://msdn.microsoft.com/en-us/library/y99d1cd3(v=vs.100).aspx

    public static class HLP
    {
        public static Random rnd = new Random();
        public static Hashtable par = new Hashtable();
        public static ErrorReporter ERR = null;
        public static int GLine = 0;
        public static string[] CleanMath(string S) {
            char[] C = S.ToCharArray(),H="()+-*/%.,".ToCharArray();
            string X = "",E="";
            bool F = false;
            string[] M = "pow,asin,acos,atan,rand,round,ceil,floor,sin,cos,tan,PI".Split(',');
            for (int I = 0; I < C.Length; I++)
            {
                if (C[I] >= '0' && C[I] <= '9')
                {
                    if (E != "" && F == false) X += E;
                    else F = false;
                    E = ""; X += " "; continue;
                }
                for (int j = 0; j < H.Length; j++) if (C[I] == H[j])
                    {
                        if (E != "" && F == false) X += E;
                        else F = false;
                        E = ""; X += " "; goto EXT;
                    }
                E += C[I];
                for (int j = 0; j < M.Length; j++)
                {
                    if (M[j].IndexOf(E) == 0)
                    {
                        if (E == M[j]) F = true;
                        goto EXT;
                    }
                }
                if (E != "") { X += E; E = ""; }
                if (F == true) F = false;
            EXT: { }
            }
            if (E != "" && F==false) X += E;
            return X.Split(' ');
        }
        public static object MT(string EXP)
        {
            string Rev = EXP;
            string[] P = CleanMath(EXP);
            for (int I = 0; I < P.Length; I++)
            {
                if (P[I] == "") continue;
                string[] CC = P[I].Split('~');
                string[] XC = CC[0].Split('@');
                object PR = null;
                if (XC.Length == 2)
                {
                    if (par.ContainsKey(XC[0]) == false)
                    {
                        Report(GLine, "Array " + XC[0] + " not exists in mem!"); return 0;
                    }
                    if (typeof(ARR) != par[XC[0]].GetType())
                    {
                        Report(GLine, "Parameter " + XC[0] + " is not array, but is been used as array!"); return 0;
                    }
                    ARR A = (ARR)par[XC[0]];
                    int idx = 0;
                    try { Int32.Parse(XC[1]); }
                    catch { idx = System.Convert.ToInt32(MT(XC[1])); }
                    if (A.S.Count <= idx)
                    {
                        Report(GLine, "Index out of range at array " + XC[0] + ": It's length is " + A.S.Count); return 0;
                    }
                    PR = A.S[idx];
                }
                else if (par.ContainsKey(CC[0]) == false)
                {
                    Report(GLine, "Parameter " + CC[0] + " not exists in mem!"); return 0;
                }
                else PR = par[CC[0]];
                if (typeof(string) == PR.GetType() && PR.ToString()[0] == '*') PR = par[PR.ToString().Substring(1)];
                if (typeof(string) == PR.GetType()) return PR;
                if (typeof(double) == PR.GetType())
                    EXP = Regex.Replace(EXP, "\\b" + P[I] + "\\b", ((double)PR).ToString());
                else if (typeof(int) == PR.GetType())
                    EXP = Regex.Replace(EXP, "\\b" + P[I] + "\\b", ((int)PR).ToString());
                else if (typeof(Color) == PR.GetType())
                {
                    if (CC.Length == 1) {
                        Report(GLine,"Parameter " + P[I] + " color unit shall be A, R, G or B or list pointer!"); return 0;
                    }
                    if (CC[1] == "A") EXP = Regex.Replace(EXP, "\\b" + P[I] + "\\b", ((Color)PR).A.ToString());
                    else if (CC[1] == "R") EXP = Regex.Replace(EXP, "\\b" + P[I] + "\\b", ((Color)PR).R.ToString());
                    else if (CC[1] == "G") EXP = Regex.Replace(EXP, "\\b" + P[I] + "\\b", ((Color)PR).G.ToString());
                    else if (CC[1] == "B") EXP = Regex.Replace(EXP, "\\b" + P[I] + "\\b", ((Color)PR).B.ToString());
                    else {
                        Report(GLine,"Parameter " + CC[1] + " color unit shall be A, R, G or B!"); return 0;
                    }
                }
                else if (typeof(Color[,]) == PR.GetType())
                {
                    if (CC.Length < 4) { Report(GLine, "Parameter " + P[I] + " is color matrix and shall be in a form of \"name~X~Y~Cval\"!"); return 0; }
                    try
                    {
                        int Y = System.Convert.ToInt32(MT(CC[2])),X = System.Convert.ToInt32(MT(CC[1]));
                        Color C = ((Color[,])PR)[X, Y];
                        if (CC[3] == "A") EXP = Regex.Replace(EXP, "\\b" + P[I] + "\\b", C.A.ToString());
                        else if (CC[3] == "R") EXP = Regex.Replace(EXP, "\\b" + P[I] + "\\b", C.R.ToString());
                        else if (CC[3] == "G") EXP = Regex.Replace(EXP, "\\b" + P[I] + "\\b",C.G.ToString());
                        else if (CC[3] == "B") EXP = Regex.Replace(EXP, "\\b" + P[I] + "\\b", C.B.ToString());
                        else
                        {
                            Report(GLine, "Parameter " + CC[3] + " color unit shall be A, R, G or B!"); return 0;
                        }
                    }
                    catch { Report(GLine, "X/Y Parameters shall be numeric!"); return 0; }
                }
            }
            string[] M = "pow,asin,acos,atan,round,ceil,sin,cos,tan,floor,PI".Split(',');
            P = ("Pow,Asin,Acos,Atan,Round,Ceil,Sin,Cos,Tan,Floor," + Math.PI.ToString()).Split(',');
            for (var I = 0; I < M.Length; I++) EXP = EXP.Replace(M[I], P[I]); // Regex.Replace(EXP, "\\b" + M[I] + "\\b", P[I]);
            int b = EXP.IndexOf("rand(");
            if (b != -1)
            {
                int f = EXP.IndexOf(")", b);
                string s = EXP.Substring(b + 5, f - b - 5);
                StringBuilder S = new StringBuilder(EXP);
                S.Remove(b, f - b + 1);
                S.Insert(b, rnd.Next(Int32.Parse(s)));
                EXP = S.ToString();
            }
            Expression e = new Expression(EXP);
            return Double.Parse(e.Evaluate().ToString());
        }
        public static bool Cond(string[] EXP, int I)
        {
            List<bool> res=new List<bool>();
			for(var i=2 ; i<EXP.Length ; i+=2) {
				string[] m=">=,<=,>,<,=,!".Split(',');
                 string op="";
				for(int j=0 ; j<m.Length ; j++)
					if(EXP[i].IndexOf(m[j])!=-1) { op=m[j]; break; }
				if(op=="") return false;
				string[] b=EXP[i].Split(op.ToCharArray());
                if (b.Length > 2 && b[1] == "") b[1] = b[2];
                if (op == "=")
                {
                    object A = MT(b[0]), B = MT(b[1]);
                    if (A.GetType() == typeof(double) && B.GetType() == typeof(double))
                        if (System.Convert.ToDouble(A) == System.Convert.ToDouble(B)) res.Add(true);
                        else res.Add(false);
                    else if (A.ToString() == B.ToString()) res.Add(true);
                    else res.Add(false);
                }
                else if (op == "!")
                {
                    object A = MT(b[0]), B = MT(b[1]);
                    if (A.GetType() == typeof(double) && B.GetType() == typeof(double))
                        if (System.Convert.ToDouble(A) != System.Convert.ToDouble(B)) res.Add(true);
                        else res.Add(false);
                    else if (A.ToString() != B.ToString()) res.Add(true);
                    else res.Add(false);
                }
                else
                {
                    double A = System.Convert.ToDouble(MT(b[0])), B = System.Convert.ToDouble(MT(b[1]));
                    if (op == ">") res.Add((A > B) ? true : false);
                    else if (op == "<") res.Add((A< B) ? true : false);
                    else if (op == ">=") res.Add((A >= B) ? true : false);
                    else if (op == "<=") res.Add((A <= B) ? true : false);
                }
			}
			bool s=res[0];
			for(int i=3 ; i<EXP.Length ; i+=2) {
				if(EXP[i]=="&") s=(s && res[(i-1)/2])?true:false;
                else if (EXP[i] == "|") s = (s || res[(i - 1) / 2]) ? true : false;
			}
			return s;
        }
        public static bool Comp(string EXP, int LL)
        {
            string[] L = ">,<,=,<=,>=,!".Split(','), E = "0 0".Split(' ');
            string M = "";
            for (int I = 0; I < 6; I++) if (EXP.IndexOf(L[I]) > -1) { E = EXP.Split(L[I].ToCharArray()); M = L[I]; break; }
            if (E.Length != 2) { Report(GLine,"Left value required!"); }


            if (M == "=")
            {
                object A = MT(E[0]), B = MT(E[1]);
                if (A.GetType() == typeof(double) && B.GetType() == typeof(double))
                    if (System.Convert.ToDouble(A) == System.Convert.ToDouble(B)) return true;
                    else return false;
                else if (A.ToString() == B.ToString()) return true;
                else return false;
            }
            else if (M == "!")
            {
                object A = MT(E[0]), B = MT(E[1]);
                if (A.GetType() == typeof(double) && B.GetType() == typeof(double))
                    if (System.Convert.ToDouble(A) != System.Convert.ToDouble(B)) return true;
                    else return false;
                else if (A.ToString() != B.ToString()) return true;
                else return false;
            }
            else
            {
                double A = System.Convert.ToDouble(MT(E[0])), B = System.Convert.ToDouble(MT(E[1]));
                if (M == ">" && A > B) return true;
                else if (M == "<" && A < B) return true;
                else if (M == ">=" && A >= B) return true;
                else if (M == "<=" && A <= B) return true;
            }
            if (M == "") Report(GLine,"Missing conditional operation > < >= <= = !");
            return false;
        }
        public static void Report(int L, string S)
        {
            if (ERR == null || ERR.IsDisposed == true) ERR = new ErrorReporter();
            if (ERR.Visible == false) ERR.Show();
            int R = ERR.ErrorsList.Rows.Count;
            ERR.ErrorsList.Rows.Add();
            ERR.ErrorsList.Rows[R].Cells[0].Value = L.ToString();
            ERR.ErrorsList.Rows[R].Cells[1].Value = S;
            Application.DoEvents();
        }
        public static double Len(Position A, Position B)
        {
            return Math.Sqrt(Math.Pow(A.x - B.x, 2) + Math.Pow((double)A.y - B.y, 2));
        }
        public static double DEG(double RAD) { return RAD * 180 / Math.PI; }
    }

    public class Position
    {
        public double x;
        public double y;
        public Position(double nx, double ny)
        {
            x = nx; y = ny;
        }
        public Point ToPoint()
        {
            return new Point((int)Math.Round(x), (int)Math.Round(y));
        }
        public Point Shift(string scalar, Direction dir)
        {

            x += dir.x * System.Convert.ToDouble(HLP.MT(scalar));
            y += dir.y * System.Convert.ToDouble(HLP.MT(scalar));
            return new Point((int)Math.Round(x), (int)Math.Round(y));
        }
        public Point Shift(string vx, string vy)
        {
            x += System.Convert.ToDouble(HLP.MT(vx));
            y += System.Convert.ToDouble(HLP.MT(vy));
            return new Point((int)Math.Round(x), (int)Math.Round(y));
        }
        public Point Set(string vx, string vy)
        {
            x = System.Convert.ToDouble(HLP.MT(vx));
            y = System.Convert.ToDouble(HLP.MT(vy));
            return new Point((int)Math.Round(x), (int)Math.Round(y));
        }
    }

    public class Direction
    {
        public double x;
        public double y;
        public double a;
        public Direction(double nx, double ny)
        {
            x = nx; y = ny;
            a = Math.Asin(Math.Pow(x, 2) / (Math.Pow(x, 2) + Math.Pow(y, 2)));
            if (y < 0) a += (a > 0) ? Math.PI / 2 : (-Math.PI / 2);
            a = a * Math.PI / 180; CalcCords();
        }
        public Direction(double na)
        {
            a = na;
            CalcCords();
        }
        public void Shift(double angle)
        {
            a += angle;
            CalcCords();
        }
        void CalcCords()
        {
            double ra = a / 180 * Math.PI;
            x = Math.Sin(ra); y = Math.Cos(ra);
        }
    }

    public class ARR
    {
        public List<object> S = new List<object>();
    }
}
