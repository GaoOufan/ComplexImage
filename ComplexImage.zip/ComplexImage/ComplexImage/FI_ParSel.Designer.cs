﻿namespace ComplexImage
{
    partial class FI_ParSel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FI_ParSel));
            this.I_ParLst = new System.Windows.Forms.ListBox();
            this.OK = new System.Windows.Forms.Button();
            this.Cancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // I_ParLst
            // 
            this.I_ParLst.FormattingEnabled = true;
            this.I_ParLst.ItemHeight = 12;
            this.I_ParLst.Location = new System.Drawing.Point(12, 13);
            this.I_ParLst.Name = "I_ParLst";
            this.I_ParLst.Size = new System.Drawing.Size(173, 196);
            this.I_ParLst.TabIndex = 0;
            // 
            // OK
            // 
            this.OK.Location = new System.Drawing.Point(12, 219);
            this.OK.Name = "OK";
            this.OK.Size = new System.Drawing.Size(82, 29);
            this.OK.TabIndex = 1;
            this.OK.Text = "OK";
            this.OK.UseVisualStyleBackColor = true;
            this.OK.Click += new System.EventHandler(this.OK_Click);
            // 
            // Cancel
            // 
            this.Cancel.Location = new System.Drawing.Point(103, 219);
            this.Cancel.Name = "Cancel";
            this.Cancel.Size = new System.Drawing.Size(82, 29);
            this.Cancel.TabIndex = 2;
            this.Cancel.Text = "Cancel";
            this.Cancel.UseVisualStyleBackColor = true;
            this.Cancel.Click += new System.EventHandler(this.Cancel_Click);
            // 
            // FI_ParSel
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(196, 261);
            this.ControlBox = false;
            this.Controls.Add(this.Cancel);
            this.Controls.Add(this.OK);
            this.Controls.Add(this.I_ParLst);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FI_ParSel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Select parameter to remove";
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.ListBox I_ParLst;
        private System.Windows.Forms.Button OK;
        private System.Windows.Forms.Button Cancel;
    }
}