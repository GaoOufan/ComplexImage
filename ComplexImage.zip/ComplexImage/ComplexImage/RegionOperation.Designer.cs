﻿namespace ComplexImage
{
    partial class RegionOperation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RegionOperation));
            this.OK = new System.Windows.Forms.Button();
            this.NO = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.RegLayN = new System.Windows.Forms.TextBox();
            this.RegLay = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // OK
            // 
            this.OK.Location = new System.Drawing.Point(419, 146);
            this.OK.Name = "OK";
            this.OK.Size = new System.Drawing.Size(139, 28);
            this.OK.TabIndex = 36;
            this.OK.Text = "OK";
            this.OK.UseVisualStyleBackColor = true;
            this.OK.Click += new System.EventHandler(this.OK_Click);
            // 
            // NO
            // 
            this.NO.Location = new System.Drawing.Point(419, 180);
            this.NO.Name = "NO";
            this.NO.Size = new System.Drawing.Size(139, 28);
            this.NO.TabIndex = 35;
            this.NO.Text = "Cancel";
            this.NO.UseVisualStyleBackColor = true;
            this.NO.Click += new System.EventHandler(this.NO_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(161, 9);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(71, 12);
            this.label11.TabIndex = 40;
            this.label11.Text = "Layer name:";
            // 
            // RegLayN
            // 
            this.RegLayN.Location = new System.Drawing.Point(161, 24);
            this.RegLayN.MaxLength = 32;
            this.RegLayN.Name = "RegLayN";
            this.RegLayN.Size = new System.Drawing.Size(166, 21);
            this.RegLayN.TabIndex = 39;
            // 
            // RegLay
            // 
            this.RegLay.AllowDrop = true;
            this.RegLay.BackColor = System.Drawing.Color.White;
            this.RegLay.ForeColor = System.Drawing.Color.OrangeRed;
            this.RegLay.Location = new System.Drawing.Point(14, 24);
            this.RegLay.MaxLength = 32;
            this.RegLay.Name = "RegLay";
            this.RegLay.ReadOnly = true;
            this.RegLay.Size = new System.Drawing.Size(141, 21);
            this.RegLay.TabIndex = 38;
            this.RegLay.Text = "<Drop image file here>";
            this.RegLay.DragDrop += new System.Windows.Forms.DragEventHandler(this.RegLay_DragDrop);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(143, 12);
            this.label2.TabIndex = 37;
            this.label2.Text = "Regional dividor layer:";
            // 
            // RegionOperation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(570, 218);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.RegLayN);
            this.Controls.Add(this.RegLay);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.OK);
            this.Controls.Add(this.NO);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "RegionOperation";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Operation on specific region";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button OK;
        private System.Windows.Forms.Button NO;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox RegLayN;
        private System.Windows.Forms.TextBox RegLay;
        private System.Windows.Forms.Label label2;
    }
}