﻿namespace ComplexImage
{
    partial class GIFProp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GIFProp));
            this.Repeat = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Speed = new System.Windows.Forms.TextBox();
            this.OK = new System.Windows.Forms.Button();
            this.Cancel = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.RepeatQTY = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Delay = new System.Windows.Forms.TextBox();
            this.IQual = new System.Windows.Forms.TrackBar();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.IQual)).BeginInit();
            this.SuspendLayout();
            // 
            // Repeat
            // 
            this.Repeat.AutoSize = true;
            this.Repeat.Checked = true;
            this.Repeat.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Repeat.Location = new System.Drawing.Point(180, 65);
            this.Repeat.Name = "Repeat";
            this.Repeat.Size = new System.Drawing.Size(72, 16);
            this.Repeat.TabIndex = 0;
            this.Repeat.Text = "Infinite";
            this.Repeat.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "Frame rate (fps):";
            // 
            // Speed
            // 
            this.Speed.Location = new System.Drawing.Point(124, 7);
            this.Speed.MaxLength = 6;
            this.Speed.Name = "Speed";
            this.Speed.Size = new System.Drawing.Size(50, 21);
            this.Speed.TabIndex = 2;
            this.Speed.Text = "5";
            this.Speed.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // OK
            // 
            this.OK.Location = new System.Drawing.Point(6, 138);
            this.OK.Name = "OK";
            this.OK.Size = new System.Drawing.Size(113, 29);
            this.OK.TabIndex = 3;
            this.OK.Text = "OK";
            this.OK.UseVisualStyleBackColor = true;
            this.OK.Click += new System.EventHandler(this.OK_Click);
            // 
            // Cancel
            // 
            this.Cancel.Location = new System.Drawing.Point(139, 138);
            this.Cancel.Name = "Cancel";
            this.Cancel.Size = new System.Drawing.Size(113, 29);
            this.Cancel.TabIndex = 4;
            this.Cancel.Text = "Cancel";
            this.Cancel.UseVisualStyleBackColor = true;
            this.Cancel.Click += new System.EventHandler(this.Cancel_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 5;
            this.label2.Text = "Repeat";
            // 
            // RepeatQTY
            // 
            this.RepeatQTY.Location = new System.Drawing.Point(59, 63);
            this.RepeatQTY.MaxLength = 6;
            this.RepeatQTY.Name = "RepeatQTY";
            this.RepeatQTY.Size = new System.Drawing.Size(50, 21);
            this.RepeatQTY.TabIndex = 6;
            this.RepeatQTY.Text = "1";
            this.RepeatQTY.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(115, 66);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 12);
            this.label3.TabIndex = 7;
            this.label3.Text = "times, or";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(10, 37);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 12);
            this.label5.TabIndex = 10;
            this.label5.Text = "Delay (ms):";
            // 
            // Delay
            // 
            this.Delay.Location = new System.Drawing.Point(124, 34);
            this.Delay.MaxLength = 6;
            this.Delay.Name = "Delay";
            this.Delay.Size = new System.Drawing.Size(50, 21);
            this.Delay.TabIndex = 11;
            this.Delay.Text = "0";
            this.Delay.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // IQual
            // 
            this.IQual.LargeChange = 1;
            this.IQual.Location = new System.Drawing.Point(71, 90);
            this.IQual.Minimum = 1;
            this.IQual.Name = "IQual";
            this.IQual.Size = new System.Drawing.Size(135, 45);
            this.IQual.TabIndex = 12;
            this.IQual.Value = 10;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 90);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 12);
            this.label6.TabIndex = 13;
            this.label6.Text = "Quality:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Green;
            this.label7.Location = new System.Drawing.Point(34, 111);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 12);
            this.label7.TabIndex = 14;
            this.label7.Text = "Good";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(212, 111);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 12);
            this.label8.TabIndex = 15;
            this.label8.Text = "Soso";
            // 
            // GIFProp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(257, 176);
            this.ControlBox = false;
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.IQual);
            this.Controls.Add(this.Delay);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.RepeatQTY);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Cancel);
            this.Controls.Add(this.OK);
            this.Controls.Add(this.Speed);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Repeat);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "GIFProp";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "GIFProp";
            ((System.ComponentModel.ISupportInitialize)(this.IQual)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.CheckBox Repeat;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.TextBox Speed;
        private System.Windows.Forms.Button OK;
        private System.Windows.Forms.Button Cancel;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.TextBox RepeatQTY;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        public System.Windows.Forms.TextBox Delay;
        public System.Windows.Forms.TrackBar IQual;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
    }
}