﻿namespace ComplexImage
{
    partial class HelpMe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("Command syntax");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("Math operations");
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("Conditional statement");
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("Parameter use");
            System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode("General", new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2,
            treeNode3,
            treeNode4});
            System.Windows.Forms.TreeNode treeNode6 = new System.Windows.Forms.TreeNode("Basic");
            System.Windows.Forms.TreeNode treeNode7 = new System.Windows.Forms.TreeNode("Drawing and layers");
            System.Windows.Forms.TreeNode treeNode8 = new System.Windows.Forms.TreeNode("Extras");
            System.Windows.Forms.TreeNode treeNode9 = new System.Windows.Forms.TreeNode("Advanced");
            System.Windows.Forms.TreeNode treeNode10 = new System.Windows.Forms.TreeNode("3D draw");
            System.Windows.Forms.TreeNode treeNode11 = new System.Windows.Forms.TreeNode("Commands", new System.Windows.Forms.TreeNode[] {
            treeNode6,
            treeNode7,
            treeNode8,
            treeNode9,
            treeNode10});
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HelpMe));
            this.HF = new System.Windows.Forms.RichTextBox();
            this.HT = new System.Windows.Forms.TreeView();
            this.SuspendLayout();
            // 
            // HF
            // 
            this.HF.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.HF.BackColor = System.Drawing.Color.White;
            this.HF.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HF.ForeColor = System.Drawing.Color.Black;
            this.HF.Location = new System.Drawing.Point(242, 10);
            this.HF.Name = "HF";
            this.HF.ReadOnly = true;
            this.HF.Size = new System.Drawing.Size(501, 365);
            this.HF.TabIndex = 0;
            this.HF.Text = "";
            this.HF.WordWrap = false;
            // 
            // HT
            // 
            this.HT.BackColor = System.Drawing.Color.Tan;
            this.HT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HT.ForeColor = System.Drawing.Color.SaddleBrown;
            this.HT.Location = new System.Drawing.Point(12, 11);
            this.HT.Name = "HT";
            treeNode1.Name = "S1E1";
            treeNode1.Text = "Command syntax";
            treeNode2.Name = "S1E2";
            treeNode2.Text = "Math operations";
            treeNode3.Name = "S1E3";
            treeNode3.Text = "Conditional statement";
            treeNode4.Name = "S1E4";
            treeNode4.Text = "Parameter use";
            treeNode5.Name = "S1";
            treeNode5.Text = "General";
            treeNode6.Name = "S2E1";
            treeNode6.Text = "Basic";
            treeNode7.Name = "S2E2";
            treeNode7.Text = "Drawing and layers";
            treeNode8.Name = "S2E3";
            treeNode8.Text = "Extras";
            treeNode9.Name = "S2E4";
            treeNode9.Text = "Advanced";
            treeNode10.Name = "S2E5";
            treeNode10.Text = "3D draw";
            treeNode11.Name = "S2";
            treeNode11.Text = "Commands";
            this.HT.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode5,
            treeNode11});
            this.HT.Size = new System.Drawing.Size(220, 364);
            this.HT.TabIndex = 1;
            this.HT.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.HT_AfterSelect);
            // 
            // HelpMe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(755, 388);
            this.Controls.Add(this.HT);
            this.Controls.Add(this.HF);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "HelpMe";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "General help";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox HF;
        private System.Windows.Forms.TreeView HT;
    }
}