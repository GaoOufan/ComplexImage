﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ComplexImage
{
    public partial class SystemFontsViewer : Form
    {
        public Form1 acref;

        public SystemFontsViewer()
        {
            InitializeComponent();
        }

        private void SystemFontsViewer_Load(object sender, EventArgs e)
        {
            InstalledFontCollection ILF = new InstalledFontCollection();
            FontFamily[] FF = ILF.Families;
            foreach (FontFamily f in FF)
            {
                FontStyle[] FNS = new FontStyle[3];
                FNS[0] = FontStyle.Regular;
                FNS[1] = FontStyle.Bold;
                FNS[2] = FontStyle.Italic;
                for (int v = 0; v < FNS.Length; v++)
                {
                    int i = FL.Rows.Count;
                    try
                    {
                        FL.Rows.Add();
                        FL.Rows[i].Cells[0].Value = f.Name;
                        FL.Rows[i].Cells[1].Value = FNS[v].ToString();
                        FL.Rows[i].Cells[2].Value = "abcdefghijklmnopqrstuvwxyz.\n\rABCDEFGHIJKLMNOPQRSTUVWXYZ;\n\r0123456789 ！我叫高欧凡，早-上~好。";
                        FL.Rows[i].Cells[2].Style.Font = new Font(f, 20, FNS[v]);
                        FL.Rows[i].Height = 30;
                    }
                    catch { }
                }
            }
        }

        private void FL_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (FL.SelectedRows == null || FL.SelectedRows.Count == 0) return;
            acref.Prog.SelectedText = FL.SelectedRows[0].Cells[0].Value.ToString().Replace(" ","\\_");
            this.Close();
        }
    }
}
