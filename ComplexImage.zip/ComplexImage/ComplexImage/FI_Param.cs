﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ComplexImage
{
    public partial class FI_Param : Form
    {
        public FI_Param()
        {
            InitializeComponent();
        }

        private void OK_Click(object sender, EventArgs e)
        {
            if (I_Nam.Text == "") { MessageBox.Show("Parameter name is missing!"); return; }
            if (I_Typ.SelectedItem==null) { MessageBox.Show("Need to select parameter type!"); return; }
            if (I_Val.Text == "") { MessageBox.Show("Parameter must be initialized!"); return; }
            string[] CMD = I_Val.Text.Split(' ');
            string t = I_Typ.SelectedItem.ToString().Substring(0,1);
            if (t == "N" || t=="S") {
                if (CMD.Length != 1) { MessageBox.Show("Value to have one element only!"); return; }
                if(t == "N") HLP.MT(CMD[0]);
            }
            else if (t == "C")
            {
                if (CMD.Length != 4) { MessageBox.Show("Color parameters are A R G B values!"); return; }
                for (int i = 0; i < 4; i++) HLP.MT(CMD[i]);
            }
            DialogResult = DialogResult.Yes;
        }

        private void Cancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.No;
        }
    }
}
